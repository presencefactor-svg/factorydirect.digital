<?php
/**
 * Uninstall cleanup for Marketplace Connector BG for WooCommerce.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

$eur_olx_options = get_option( 'eur_olx_options', array() );
if ( ! is_array( $eur_olx_options ) || empty( $eur_olx_options['cleanup_data'] ) ) {
    return;
}

delete_option( 'eur_olx_options' );
delete_option( 'eur_olx_category_map' );

foreach ( array( '_eur_olx_advert_id', '_eur_olx_status', '_eur_olx_last_error' ) as $eur_olx_meta_key ) {
    delete_post_meta_by_key( $eur_olx_meta_key );
}
