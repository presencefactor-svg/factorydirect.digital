=== Marketplace Connector BG for WooCommerce ===
Contributors: factorydirectmultimedia
Tags: woocommerce, marketplace, product sync, bulgaria, ecommerce
Requires at least: 6.0
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 0.2.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Manual WooCommerce product synchronization with the OLX.bg Partner API v2 for Bulgaria.

== Description ==

Marketplace Connector BG for WooCommerce helps store administrators prepare and manually publish WooCommerce product data to the OLX.bg marketplace through the OLX Partner API v2.

The free plugin is built for controlled manual workflows. Store administrators configure their marketplace API credentials, map WooCommerce product categories to marketplace category IDs, add required attributes such as condition/state, and start synchronization from the product edit screen or the WooCommerce product list.

This plugin is an independent connector and is not affiliated with, endorsed by, or sponsored by OLX Group or WooCommerce.

Features:

* OAuth 2.0 authorization-code connection flow with Bearer token API requests.
* OLX.bg Partner API v2 endpoint support for Bulgaria.
* Client ID and Client Secret settings stored in WordPress options.
* WooCommerce category to marketplace category ID mapping.
* Category notes/path field for administrators.
* Category-level condition/state mapping.
* Extra attribute mapping using simple key=value lines.
* Live marketplace category suggestions when OAuth is connected.
* Manual product sync from the WooCommerce product edit screen.
* Bulk manual sync action from the WooCommerce Products list.
* Update existing marketplace adverts when an advert ID is already saved.
* Local/private image URL filtering to avoid sending non-public image URLs.
* Developer hooks for custom payload attributes, validation and logging.

== External Services ==

This plugin connects to the OLX.bg Partner API to create or update marketplace adverts from WooCommerce products.

When an authorized store administrator clicks manual sync or uses the bulk sync action, this plugin may send the following product and store data to the OLX.bg marketplace: product title, description, price, currency, WooCommerce product URL, category mapping, location identifiers, contact name, contact phone number and public product image URLs.

The plugin also requests OLX.bg category data when the administrator opens the category mapping screen and OAuth is connected, so that category suggestions can be shown in the WordPress admin area.

The plugin uses the OLX.bg API endpoint `https://www.olx.bg/api/partner` with the OLX Partner API v2 `Version: 2.0` header and OAuth bearer authorization.

Service provider: OLX Group
API documentation: https://developer.olx.bg/api/doc
OLX Group privacy statement: https://www.olxgroup.com/privacy-statement/
OLX Group terms of use: https://www.olxgroup.com/terms-of-use-2/

== Privacy ==

No product data is sent automatically by this free version. Product data is sent only when an authorized store administrator starts a manual product sync or bulk sync action. OAuth tokens are stored in WordPress options and are used only for OLX.bg API requests.

== Installation ==

1. Make sure WooCommerce is installed and active.
2. Upload the plugin ZIP through Plugins > Add New > Upload Plugin, or install it from the WordPress.org plugin directory when published.
3. Activate "Marketplace Connector BG for WooCommerce".
4. Open Marketplace BG > Settings.
5. Enter your OLX.bg Partner API Client ID and Client Secret.
6. Save settings, then click "Connect with OLX" to complete OAuth authorization.
7. Open Marketplace BG > Category Mapping and map WooCommerce categories to marketplace category IDs.
8. Edit a WooCommerce product and use the "Marketplace BG Sync" box to start a manual sync.

== Frequently Asked Questions ==

= Does this plugin publish products automatically? =

No. The free version sends product data only when an authorized store administrator starts a manual sync or bulk sync action.

= Do I need an OLX.bg Partner API application? =

Yes. You need valid OLX.bg Partner API credentials and a user-authorized OAuth connection before creating or updating marketplace adverts.

= Why are local product images skipped? =

Marketplace APIs must be able to fetch image URLs over the public internet. Images served from localhost, private IP addresses, `.local` domains or development-only URLs are skipped to prevent API validation errors.

= Can I map custom attributes? =

Yes. The category mapping screen supports extra attributes using one `key=value` pair per line, for example `brand=Samsung` or `model=A54`.

= Is this plugin affiliated with OLX or WooCommerce? =

No. This is an independent connector. OLX and WooCommerce are trademarks of their respective owners.

== Screenshots ==

1. Settings screen for market, OAuth and store contact configuration.
2. Category mapping screen with category ID, category path, condition/state and extra attributes.
3. Product edit screen manual synchronization box.
4. Documentation page for installation and first sync workflow.

== Changelog ==

= 0.2.2 =
* Prepared WordPress.org submission copy and metadata.
* Expanded readme installation, FAQ, screenshots and external services disclosure.
* Updated plugin URI to the public documentation landing page.

= 0.2.1 =
* Added live OLX.bg category suggestions to category mapping when OAuth is connected.

= 0.2.0 =
* Renamed public branding to neutral Marketplace Connector BG for WooCommerce.
* Expanded category mapping with per-category condition and custom attribute fields.

== Upgrade Notice ==

= 0.2.2 =
Submission-ready metadata and documentation update for the first public review package.
