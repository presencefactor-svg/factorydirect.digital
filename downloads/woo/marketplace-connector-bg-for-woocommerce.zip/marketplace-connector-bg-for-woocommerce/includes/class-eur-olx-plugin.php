<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class EUR_OLX_Plugin {
    private static $eur_olx_instance = null;

    private $eur_olx_settings;
    private $eur_olx_category_map;
    private $eur_olx_product_sync;

    public static function eur_olx_instance() {
        if ( null === self::$eur_olx_instance ) {
            self::$eur_olx_instance = new self();
        }
        return self::$eur_olx_instance;
    }

    private function __construct() {
        $this->eur_olx_settings     = new EUR_OLX_Settings();
        $this->eur_olx_category_map = new EUR_OLX_Category_Map();
        $this->eur_olx_product_sync = new EUR_OLX_Product_Sync( $this->eur_olx_settings, $this->eur_olx_category_map );

        add_action( 'admin_menu', array( $this, 'eur_olx_admin_menu' ) );
        add_action( 'admin_init', array( $this->eur_olx_settings, 'eur_olx_register_settings' ) );
        add_action( 'admin_init', array( $this->eur_olx_category_map, 'eur_olx_handle_category_map_save' ) );
        add_action( 'admin_post_eur_olx_oauth_start', array( $this->eur_olx_settings, 'eur_olx_handle_oauth_start' ) );
        add_action( 'admin_post_eur_olx_oauth_callback', array( $this->eur_olx_settings, 'eur_olx_handle_oauth_callback' ) );

        $this->eur_olx_product_sync->eur_olx_register_hooks();

        /**
         * Extension hook: keep this free plugin manual-only; add automation in add-ons if needed.
         */
        do_action( 'eur_olx_lite_loaded', $this );
    }

    public function eur_olx_admin_menu() {
        add_menu_page(
            esc_html__( 'Marketplace Connector BG for WooCommerce', 'marketplace-connector-bg-for-woocommerce' ),
            esc_html__( 'Marketplace Connector BG for WooCommerce', 'marketplace-connector-bg-for-woocommerce' ),
            'manage_woocommerce',
            'eur-olx-lite',
            array( $this->eur_olx_settings, 'eur_olx_render_settings_page' ),
            'dashicons-store',
            56
        );

        add_submenu_page(
            'eur-olx-lite',
            esc_html__( 'Category Mapping', 'marketplace-connector-bg-for-woocommerce' ),
            esc_html__( 'Category Mapping', 'marketplace-connector-bg-for-woocommerce' ),
            'manage_woocommerce',
            'eur-olx-category-map',
            array( $this->eur_olx_category_map, 'eur_olx_render_category_map_page' )
        );
    }
}
