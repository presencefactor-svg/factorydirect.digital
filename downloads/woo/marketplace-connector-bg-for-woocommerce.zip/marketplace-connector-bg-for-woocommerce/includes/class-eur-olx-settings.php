<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class EUR_OLX_Settings {
    const EUR_OLX_OPTION = 'eur_olx_options';
    const EUR_OLX_NONCE_ACTION = 'eur_olx_settings_nonce_action';
    const EUR_OLX_OAUTH_STATE_TRANSIENT_PREFIX = 'eur_olx_oauth_state_';

    public function eur_olx_get_defaults() {
        return array(
            'market'           => 'bg',
            'client_id'        => '',
            'client_secret'    => '',
            'access_token'     => '',
            'refresh_token'    => '',
            'token_expires_at' => '',
            'currency'         => '',
            'advertiser_type'  => 'business',
            'contact_name'     => '',
            'contact_phone'    => '',
            'city_id'          => '',
            'district_id'      => '',
            'cleanup_data'     => '0',
        );
    }

    public function eur_olx_get_options() {
        $eur_olx_options = get_option( self::EUR_OLX_OPTION, array() );
        return wp_parse_args( is_array( $eur_olx_options ) ? $eur_olx_options : array(), $this->eur_olx_get_defaults() );
    }

    public function eur_olx_register_settings() {
        register_setting(
            'eur_olx_settings_group',
            self::EUR_OLX_OPTION,
            array(
                'type'              => 'array',
                'sanitize_callback' => array( $this, 'eur_olx_sanitize_options' ),
                'default'           => $this->eur_olx_get_defaults(),
            )
        );
    }

    public function eur_olx_sanitize_options( $eur_olx_input ) {
        $eur_olx_old = $this->eur_olx_get_options();
        if ( ! isset( $_POST['eur_olx_settings_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['eur_olx_settings_nonce'] ) ), self::EUR_OLX_NONCE_ACTION ) ) {
            add_settings_error( 'eur_olx_settings', 'eur_olx_settings_nonce_failed', esc_html__( 'Security check failed. Settings were not saved.', 'marketplace-connector-bg-for-woocommerce' ), 'error' );
            return $eur_olx_old;
        }

        $eur_olx_input = is_array( $eur_olx_input ) ? wp_unslash( $eur_olx_input ) : array();
        $eur_olx_allowed_markets = array( 'bg' );
        $eur_olx_market = isset( $eur_olx_input['market'] ) ? sanitize_key( $eur_olx_input['market'] ) : 'pl';

        return array(
            'market'           => in_array( $eur_olx_market, $eur_olx_allowed_markets, true ) ? $eur_olx_market : 'pl',
            'client_id'        => isset( $eur_olx_input['client_id'] ) ? sanitize_text_field( $eur_olx_input['client_id'] ) : '',
            'client_secret'    => isset( $eur_olx_input['client_secret'] ) && '' !== $eur_olx_input['client_secret'] ? sanitize_text_field( $eur_olx_input['client_secret'] ) : $eur_olx_old['client_secret'],
            'access_token'     => isset( $eur_olx_input['access_token'] ) && '' !== $eur_olx_input['access_token'] ? sanitize_textarea_field( $eur_olx_input['access_token'] ) : $eur_olx_old['access_token'],
            'refresh_token'    => isset( $eur_olx_input['refresh_token'] ) && '' !== $eur_olx_input['refresh_token'] ? sanitize_textarea_field( $eur_olx_input['refresh_token'] ) : $eur_olx_old['refresh_token'],
            'token_expires_at' => isset( $eur_olx_input['token_expires_at'] ) ? absint( $eur_olx_input['token_expires_at'] ) : absint( $eur_olx_old['token_expires_at'] ),
            'currency'         => isset( $eur_olx_input['currency'] ) ? strtoupper( sanitize_text_field( $eur_olx_input['currency'] ) ) : '',
            'advertiser_type'  => isset( $eur_olx_input['advertiser_type'] ) && in_array( $eur_olx_input['advertiser_type'], array( 'private', 'business' ), true ) ? sanitize_key( $eur_olx_input['advertiser_type'] ) : 'business',
            'contact_name'     => isset( $eur_olx_input['contact_name'] ) ? sanitize_text_field( $eur_olx_input['contact_name'] ) : '',
            'contact_phone'    => isset( $eur_olx_input['contact_phone'] ) ? sanitize_text_field( $eur_olx_input['contact_phone'] ) : '',
            'city_id'          => isset( $eur_olx_input['city_id'] ) ? absint( $eur_olx_input['city_id'] ) : '',
            'district_id'      => isset( $eur_olx_input['district_id'] ) ? absint( $eur_olx_input['district_id'] ) : '',
            'cleanup_data'     => ! empty( $eur_olx_input['cleanup_data'] ) ? '1' : '0',
        );
    }

    public function eur_olx_get_market_config( $eur_olx_market = '' ) {
        $eur_olx_market = $eur_olx_market ? sanitize_key( $eur_olx_market ) : $this->eur_olx_get_options()['market'];
        $eur_olx_markets = array(
            'pl' => array( 'label' => 'Poland',   'base_url' => 'https://www.olx.pl/api/partner', 'oauth_url' => 'https://www.olx.pl/oauth/authorize', 'token_url' => 'https://www.olx.pl/api/open/oauth/token', 'currency' => 'PLN' ),
            'ro' => array( 'label' => 'Romania',  'base_url' => 'https://www.olx.ro/api/partner', 'oauth_url' => 'https://www.olx.ro/oauth/authorize', 'token_url' => 'https://www.olx.ro/api/open/oauth/token', 'currency' => 'RON' ),
            'bg' => array( 'label' => 'Bulgaria', 'base_url' => 'https://www.olx.bg/api/partner', 'oauth_url' => 'https://www.olx.bg/oauth/authorize', 'token_url' => 'https://www.olx.bg/api/open/oauth/token', 'currency' => 'BGN' ),
            'pt' => array( 'label' => 'Portugal', 'base_url' => 'https://www.olx.pt/api/partner', 'oauth_url' => 'https://www.olx.pt/oauth/authorize', 'token_url' => 'https://www.olx.pt/api/open/oauth/token', 'currency' => 'EUR' ),
            'ua' => array( 'label' => 'Ukraine',  'base_url' => 'https://www.olx.ua/api/partner', 'oauth_url' => 'https://www.olx.ua/oauth/authorize', 'token_url' => 'https://www.olx.ua/api/open/oauth/token', 'currency' => 'UAH' ),
        );
        $eur_olx_markets = apply_filters( 'eur_olx_market_configs', $eur_olx_markets );
        return isset( $eur_olx_markets[ $eur_olx_market ] ) ? $eur_olx_markets[ $eur_olx_market ] : $eur_olx_markets['bg'];
    }

    public function eur_olx_get_oauth_redirect_uri() {
        return admin_url( 'admin-post.php?action=eur_olx_oauth_callback' );
    }

    public function eur_olx_handle_oauth_start() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to connect OLX.', 'marketplace-connector-bg-for-woocommerce' ) );
        }
        check_admin_referer( 'eur_olx_oauth_start' );
        $eur_olx_options = $this->eur_olx_get_options();
        if ( empty( $eur_olx_options['client_id'] ) ) {
            wp_safe_redirect( add_query_arg( 'eur_olx_oauth_error', rawurlencode( __( 'Client ID is required before connecting.', 'marketplace-connector-bg-for-woocommerce' ) ), admin_url( 'admin.php?page=eur-olx-lite' ) ) );
            exit;
        }
        $eur_olx_market = $this->eur_olx_get_market_config( $eur_olx_options['market'] );
        $eur_olx_state = wp_generate_password( 32, false, false );
        set_transient( self::EUR_OLX_OAUTH_STATE_TRANSIENT_PREFIX . $eur_olx_state, get_current_user_id(), 10 * MINUTE_IN_SECONDS );
        $eur_olx_scopes = apply_filters( 'eur_olx_oauth_scopes', array( 'v2', 'read', 'write' ) );
        $eur_olx_auth_query = http_build_query(
            array(
                'response_type' => 'code',
                'client_id'     => $eur_olx_options['client_id'],
                'redirect_uri'  => $this->eur_olx_get_oauth_redirect_uri(),
                'scope'         => implode( ' ', array_map( 'sanitize_key', (array) $eur_olx_scopes ) ),
                'state'         => $eur_olx_state,
            ),
            '',
            '&',
            PHP_QUERY_RFC3986
        );
        $eur_olx_auth_url = $eur_olx_market['oauth_url'] . '?' . $eur_olx_auth_query;
        update_option( 'eur_olx_last_oauth_debug', array( 'phase' => 'start', 'redirect_uri' => $this->eur_olx_get_oauth_redirect_uri(), 'auth_host' => wp_parse_url( $eur_olx_market['oauth_url'], PHP_URL_HOST ), 'time' => time() ), false );
        wp_redirect( esc_url_raw( $eur_olx_auth_url ) ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- External OAuth authorization URL is built from fixed OLX market configuration.
        exit;
    }

    public function eur_olx_handle_oauth_callback() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to connect OLX.', 'marketplace-connector-bg-for-woocommerce' ) );
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- OAuth callbacks are validated via the provider state parameter.
        $eur_olx_state = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- OAuth callbacks are validated via the provider state parameter.
        $eur_olx_code  = isset( $_GET['code'] ) ? sanitize_text_field( wp_unslash( $_GET['code'] ) ) : '';
        $eur_olx_saved = $eur_olx_state ? get_transient( self::EUR_OLX_OAUTH_STATE_TRANSIENT_PREFIX . $eur_olx_state ) : false;
        update_option( 'eur_olx_last_oauth_debug', array( 'phase' => 'callback_received', 'has_code' => $eur_olx_code ? 'yes' : 'no', 'has_state' => $eur_olx_state ? 'yes' : 'no', 'state_valid' => false === $eur_olx_saved ? 'no' : 'yes', 'time' => time() ), false );
        if ( ! $eur_olx_state || ! $eur_olx_code || false === $eur_olx_saved ) {
            wp_safe_redirect( add_query_arg( 'eur_olx_oauth_error', rawurlencode( __( 'OAuth callback validation failed. The callback did not include a valid code/state pair.', 'marketplace-connector-bg-for-woocommerce' ) ), admin_url( 'admin.php?page=eur-olx-lite' ) ) );
            exit;
        }
        delete_transient( self::EUR_OLX_OAUTH_STATE_TRANSIENT_PREFIX . $eur_olx_state );
        $eur_olx_result = $this->eur_olx_exchange_code_for_tokens( $eur_olx_code );
        if ( ! is_wp_error( $eur_olx_result ) ) {
            $eur_olx_after_save = $this->eur_olx_get_options();
            if ( empty( $eur_olx_after_save['access_token'] ) ) {
                $eur_olx_result = new WP_Error( 'eur_olx_oauth_token_not_saved', esc_html__( 'OAuth completed but the access token was not saved. Re-save Client Secret and connect again.', 'marketplace-connector-bg-for-woocommerce' ) );
            }
        }
        $eur_olx_arg = is_wp_error( $eur_olx_result ) ? array( 'eur_olx_oauth_error' => rawurlencode( $eur_olx_result->get_error_message() ) ) : array( 'eur_olx_oauth_connected' => '1' );
        wp_safe_redirect( add_query_arg( $eur_olx_arg, admin_url( 'admin.php?page=eur-olx-lite' ) ) );
        exit;
    }

    private function eur_olx_exchange_code_for_tokens( $eur_olx_code ) {
        $eur_olx_options = $this->eur_olx_get_options();
        $eur_olx_market = $this->eur_olx_get_market_config( $eur_olx_options['market'] );
        if ( empty( $eur_olx_options['client_id'] ) || empty( $eur_olx_options['client_secret'] ) ) {
            return new WP_Error( 'eur_olx_oauth_missing_client', esc_html__( 'Client ID and Client Secret are required.', 'marketplace-connector-bg-for-woocommerce' ) );
        }
        $eur_olx_response = wp_remote_post(
            esc_url_raw( $eur_olx_market['token_url'] ),
            array(
                'timeout' => 45,
                'headers' => array( 'Accept' => 'application/json' ),
                'body'    => array(
                    'grant_type'    => 'authorization_code',
                    'client_id'     => $eur_olx_options['client_id'],
                    'client_secret' => $eur_olx_options['client_secret'],
                    'redirect_uri'  => $this->eur_olx_get_oauth_redirect_uri(),
                    'code'          => $eur_olx_code,
                ),
            )
        );
        if ( is_wp_error( $eur_olx_response ) ) {
            return $eur_olx_response;
        }
        $eur_olx_code_http = (int) wp_remote_retrieve_response_code( $eur_olx_response );
        $eur_olx_raw = (string) wp_remote_retrieve_body( $eur_olx_response );
        $eur_olx_json = json_decode( $eur_olx_raw, true );
        $eur_olx_debug_body = $eur_olx_raw;
        $eur_olx_debug_body = preg_replace( '/"access_token"\s*:\s*"[^"]+"/', '"access_token":"[REDACTED]"', $eur_olx_debug_body );
        $eur_olx_debug_body = preg_replace( '/"refresh_token"\s*:\s*"[^"]+"/', '"refresh_token":"[REDACTED]"', $eur_olx_debug_body );
        update_option( 'eur_olx_last_oauth_debug', array( 'phase' => 'token_response', 'http' => $eur_olx_code_http, 'json' => is_array( $eur_olx_json ) ? 'yes' : 'no', 'has_access_token' => is_array( $eur_olx_json ) && ! empty( $eur_olx_json['access_token'] ) ? 'yes' : 'no', 'has_refresh_token' => is_array( $eur_olx_json ) && ! empty( $eur_olx_json['refresh_token'] ) ? 'yes' : 'no', 'body' => substr( sanitize_textarea_field( $eur_olx_debug_body ), 0, 800 ), 'time' => time() ), false );
        if ( $eur_olx_code_http < 200 || $eur_olx_code_http >= 300 || ! is_array( $eur_olx_json ) ) {
            /* translators: %s: Redacted response body returned by the OAuth token endpoint. */
            return new WP_Error( 'eur_olx_oauth_token_error', sprintf( esc_html__( 'OAuth token exchange failed: %s', 'marketplace-connector-bg-for-woocommerce' ), $eur_olx_raw ) );
        }
        if ( empty( $eur_olx_json['access_token'] ) ) {
            return new WP_Error( 'eur_olx_oauth_missing_access_token', esc_html__( 'OAuth token exchange completed but OLX did not return an access token. Check the callback URI and application approval.', 'marketplace-connector-bg-for-woocommerce' ) );
        }
        $this->eur_olx_save_tokens_from_response( $eur_olx_json );
        return $eur_olx_json;
    }

    public function eur_olx_save_tokens_from_response( array $eur_olx_response ) {
        $eur_olx_options = $this->eur_olx_get_options();
        if ( ! empty( $eur_olx_response['access_token'] ) ) {
            $eur_olx_options['access_token'] = sanitize_textarea_field( $eur_olx_response['access_token'] );
        }
        if ( ! empty( $eur_olx_response['refresh_token'] ) ) {
            $eur_olx_options['refresh_token'] = sanitize_textarea_field( $eur_olx_response['refresh_token'] );
        }
        if ( ! empty( $eur_olx_response['expires_in'] ) ) {
            $eur_olx_options['token_expires_at'] = time() + absint( $eur_olx_response['expires_in'] );
        }
        // OAuth callback is an internal trusted write; bypass the settings-form nonce sanitizer for this update.
        remove_filter( 'sanitize_option_' . self::EUR_OLX_OPTION, array( $this, 'eur_olx_sanitize_options' ), 10 );
        update_option( self::EUR_OLX_OPTION, $eur_olx_options, false );
        add_filter( 'sanitize_option_' . self::EUR_OLX_OPTION, array( $this, 'eur_olx_sanitize_options' ), 10, 1 );
        $eur_olx_persisted = $this->eur_olx_get_options();
        update_option( 'eur_olx_last_oauth_debug', array( 'phase' => 'tokens_saved', 'access_len' => ! empty( $eur_olx_persisted['access_token'] ) ? strlen( $eur_olx_persisted['access_token'] ) : 0, 'refresh_len' => ! empty( $eur_olx_persisted['refresh_token'] ) ? strlen( $eur_olx_persisted['refresh_token'] ) : 0, 'expires_at' => ! empty( $eur_olx_persisted['token_expires_at'] ) ? absint( $eur_olx_persisted['token_expires_at'] ) : 0, 'time' => time() ), false );
    }

    public function eur_olx_render_settings_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'marketplace-connector-bg-for-woocommerce' ) );
        }
        $eur_olx_options = $this->eur_olx_get_options();
        $eur_olx_market_config = $this->eur_olx_get_market_config( $eur_olx_options['market'] );
        $eur_olx_connect_url = wp_nonce_url( admin_url( 'admin-post.php?action=eur_olx_oauth_start' ), 'eur_olx_oauth_start' );
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Marketplace Connector BG for WooCommerce', 'marketplace-connector-bg-for-woocommerce' ); ?></h1>
            <p><?php echo esc_html__( 'Manual WooCommerce product synchronization for the OLX.bg marketplace. This plugin is not affiliated with, endorsed by, or sponsored by OLX Group.', 'marketplace-connector-bg-for-woocommerce' ); ?></p>
            <?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Admin notice flag after OAuth redirect. ?>
            <?php if ( isset( $_GET['eur_olx_oauth_connected'] ) && ! empty( $eur_olx_options['access_token'] ) ) : ?>
                <div class="notice notice-success"><p><?php echo esc_html__( 'OLX OAuth connection completed and token saved.', 'marketplace-connector-bg-for-woocommerce' ); ?></p></div>
            <?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Admin notice flag after OAuth redirect. ?>
            <?php elseif ( isset( $_GET['eur_olx_oauth_connected'] ) ) : ?>
                <div class="notice notice-warning"><p><?php echo esc_html__( 'OLX returned to this page, but no access token is saved yet. Please use the exact callback URI and complete the Connect with OLX flow again.', 'marketplace-connector-bg-for-woocommerce' ); ?></p></div>
            <?php endif; ?>
            <?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Admin notice flag after OAuth redirect. ?>
            <?php if ( isset( $_GET['eur_olx_oauth_error'] ) ) : ?>
                <?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Admin notice flag after OAuth redirect. ?>
                <div class="notice notice-error"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['eur_olx_oauth_error'] ) ) ); ?></p></div>
            <?php endif; ?>
            <?php $eur_olx_oauth_debug = get_option( 'eur_olx_last_oauth_debug', array() ); ?>
            <?php if ( ! empty( $eur_olx_oauth_debug ) && is_array( $eur_olx_oauth_debug ) ) : ?>
                <div class="notice notice-info"><p><strong><?php echo esc_html__( 'Last OAuth debug:', 'marketplace-connector-bg-for-woocommerce' ); ?></strong> <?php echo esc_html( wp_json_encode( $eur_olx_oauth_debug ) ); ?></p></div>
            <?php endif; ?>
            <form method="post" action="options.php">
                <?php settings_fields( 'eur_olx_settings_group' ); ?>
                <?php wp_nonce_field( self::EUR_OLX_NONCE_ACTION, 'eur_olx_settings_nonce' ); ?>
                <table class="form-table" role="presentation">
                    <tr><th scope="row"><label for="eur_olx_market"><?php echo esc_html__( 'Market', 'marketplace-connector-bg-for-woocommerce' ); ?></label></th><td><select id="eur_olx_market" name="<?php echo esc_attr( self::EUR_OLX_OPTION ); ?>[market]"><?php foreach ( array( 'bg' => 'Bulgaria' ) as $eur_olx_key => $eur_olx_label ) : ?><option value="<?php echo esc_attr( $eur_olx_key ); ?>" <?php selected( $eur_olx_options['market'], $eur_olx_key ); ?>><?php echo esc_html( $eur_olx_label ); ?></option><?php endforeach; ?></select><p class="description"><?php echo esc_html( sprintf( 'Current API base: %s', $eur_olx_market_config['base_url'] ) ); ?></p></td></tr>
                    <tr><th scope="row"><label for="eur_olx_client_id">Client ID</label></th><td><input id="eur_olx_client_id" class="regular-text" name="<?php echo esc_attr( self::EUR_OLX_OPTION ); ?>[client_id]" value="<?php echo esc_attr( $eur_olx_options['client_id'] ); ?>"></td></tr>
                    <tr><th scope="row"><label for="eur_olx_client_secret">Client Secret</label></th><td><input id="eur_olx_client_secret" type="password" class="regular-text" name="<?php echo esc_attr( self::EUR_OLX_OPTION ); ?>[client_secret]" value="" placeholder="<?php echo esc_attr__( 'Leave empty to keep saved value', 'marketplace-connector-bg-for-woocommerce' ); ?>"></td></tr>
                    <tr><th scope="row"><?php echo esc_html__( 'OAuth connection', 'marketplace-connector-bg-for-woocommerce' ); ?></th><td><a class="button" href="<?php echo esc_url( $eur_olx_connect_url ); ?>"><?php echo esc_html__( 'Connect with OLX', 'marketplace-connector-bg-for-woocommerce' ); ?></a><p class="description"><?php echo esc_html__( 'Save Client ID and Client Secret first, then connect. Manual token fields below remain available for advanced troubleshooting.', 'marketplace-connector-bg-for-woocommerce' ); ?></p></td></tr>
                    <tr><th scope="row"><label for="eur_olx_access_token">Access Token</label></th><td><textarea id="eur_olx_access_token" class="large-text" rows="3" name="<?php echo esc_attr( self::EUR_OLX_OPTION ); ?>[access_token]" placeholder="<?php echo esc_attr__( 'Leave empty to keep saved value', 'marketplace-connector-bg-for-woocommerce' ); ?>"></textarea></td></tr>
                    <tr><th scope="row"><label for="eur_olx_refresh_token">Refresh Token</label></th><td><textarea id="eur_olx_refresh_token" class="large-text" rows="3" name="<?php echo esc_attr( self::EUR_OLX_OPTION ); ?>[refresh_token]" placeholder="<?php echo esc_attr__( 'Leave empty to keep saved value', 'marketplace-connector-bg-for-woocommerce' ); ?>"></textarea></td></tr>
                    <tr><th scope="row"><label for="eur_olx_currency">Currency</label></th><td><input id="eur_olx_currency" name="<?php echo esc_attr( self::EUR_OLX_OPTION ); ?>[currency]" value="<?php echo esc_attr( $eur_olx_options['currency'] ); ?>" placeholder="<?php echo esc_attr( $eur_olx_market_config['currency'] ); ?>"></td></tr>
                    <tr><th scope="row">Advertiser type</th><td><select name="<?php echo esc_attr( self::EUR_OLX_OPTION ); ?>[advertiser_type]"><option value="business" <?php selected( $eur_olx_options['advertiser_type'], 'business' ); ?>>business</option><option value="private" <?php selected( $eur_olx_options['advertiser_type'], 'private' ); ?>>private</option></select></td></tr>
                    <tr><th scope="row"><label for="eur_olx_contact_name">Contact name</label></th><td><input id="eur_olx_contact_name" class="regular-text" name="<?php echo esc_attr( self::EUR_OLX_OPTION ); ?>[contact_name]" value="<?php echo esc_attr( $eur_olx_options['contact_name'] ); ?>"></td></tr>
                    <tr><th scope="row"><label for="eur_olx_contact_phone">Contact phone</label></th><td><input id="eur_olx_contact_phone" class="regular-text" name="<?php echo esc_attr( self::EUR_OLX_OPTION ); ?>[contact_phone]" value="<?php echo esc_attr( $eur_olx_options['contact_phone'] ); ?>"></td></tr>
                    <tr><th scope="row"><label for="eur_olx_city_id">Default city ID</label></th><td><input id="eur_olx_city_id" type="number" name="<?php echo esc_attr( self::EUR_OLX_OPTION ); ?>[city_id]" value="<?php echo esc_attr( $eur_olx_options['city_id'] ); ?>"></td></tr>
                    <tr><th scope="row"><label for="eur_olx_district_id">Default district ID</label></th><td><input id="eur_olx_district_id" type="number" name="<?php echo esc_attr( self::EUR_OLX_OPTION ); ?>[district_id]" value="<?php echo esc_attr( $eur_olx_options['district_id'] ); ?>"></td></tr>
                    <tr><th scope="row"><?php echo esc_html__( 'Uninstall cleanup', 'marketplace-connector-bg-for-woocommerce' ); ?></th><td><label><input type="checkbox" name="<?php echo esc_attr( self::EUR_OLX_OPTION ); ?>[cleanup_data]" value="1" <?php checked( $eur_olx_options['cleanup_data'], '1' ); ?>> <?php echo esc_html__( 'Remove plugin options, category mappings and OLX advert meta on uninstall.', 'marketplace-connector-bg-for-woocommerce' ); ?></label></td></tr>
                </table>
                <?php submit_button( esc_html__( 'Save settings', 'marketplace-connector-bg-for-woocommerce' ) ); ?>
            </form>
        </div>
        <?php
    }
}
