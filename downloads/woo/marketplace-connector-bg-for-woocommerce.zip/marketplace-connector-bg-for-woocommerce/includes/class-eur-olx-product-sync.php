<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class EUR_OLX_Product_Sync {
    const EUR_OLX_ADVERT_ID_META = '_eur_olx_advert_id';
    const EUR_OLX_STATUS_META    = '_eur_olx_status';
    const EUR_OLX_LAST_ERROR_META= '_eur_olx_last_error';
    const EUR_OLX_SYNC_NONCE     = 'eur_olx_sync_product_nonce_action';

    private $eur_olx_settings;
    private $eur_olx_category_map;
    private $eur_olx_api_client;

    public function __construct( EUR_OLX_Settings $eur_olx_settings, EUR_OLX_Category_Map $eur_olx_category_map ) {
        $this->eur_olx_settings     = $eur_olx_settings;
        $this->eur_olx_category_map = $eur_olx_category_map;
        $this->eur_olx_api_client   = new EUR_OLX_API_Client( $eur_olx_settings );
    }

    public function eur_olx_register_hooks() {
        add_action( 'add_meta_boxes_product', array( $this, 'eur_olx_add_product_metabox' ) );
        add_action( 'admin_post_eur_olx_sync_product', array( $this, 'eur_olx_handle_manual_sync' ) );
        add_filter( 'bulk_actions-edit-product', array( $this, 'eur_olx_register_bulk_actions' ) );
        add_filter( 'handle_bulk_actions-edit-product', array( $this, 'eur_olx_handle_bulk_actions' ), 10, 3 );

    }

    public function eur_olx_add_product_metabox() {
        add_meta_box(
            'eur_olx_product_sync',
            esc_html__( 'Marketplace BG Sync', 'marketplace-connector-bg-for-woocommerce' ),
            array( $this, 'eur_olx_render_product_metabox' ),
            'product',
            'side',
            'default'
        );
    }

    public function eur_olx_render_product_metabox( $eur_olx_post ) {
        if ( ! current_user_can( 'edit_product', $eur_olx_post->ID ) ) {
            return;
        }
        $eur_olx_advert_id = get_post_meta( $eur_olx_post->ID, self::EUR_OLX_ADVERT_ID_META, true );
        $eur_olx_status    = get_post_meta( $eur_olx_post->ID, self::EUR_OLX_STATUS_META, true );
        $eur_olx_error     = get_post_meta( $eur_olx_post->ID, self::EUR_OLX_LAST_ERROR_META, true );
        $eur_olx_url       = wp_nonce_url(
            admin_url( 'admin-post.php?action=eur_olx_sync_product&product_id=' . absint( $eur_olx_post->ID ) ),
            self::EUR_OLX_SYNC_NONCE,
            'eur_olx_nonce'
        );
        echo '<p><strong>' . esc_html__( 'Advert ID:', 'marketplace-connector-bg-for-woocommerce' ) . '</strong> ' . esc_html( $eur_olx_advert_id ? $eur_olx_advert_id : '-' ) . '</p>';
        echo '<p><strong>' . esc_html__( 'Status:', 'marketplace-connector-bg-for-woocommerce' ) . '</strong> ' . esc_html( $eur_olx_status ? $eur_olx_status : '-' ) . '</p>';
        if ( $eur_olx_error ) {
            echo '<p class="description" style="color:#b32d2e;">' . esc_html( $eur_olx_error ) . '</p>';
        }
        echo '<p><a class="button button-primary" href="' . esc_url( $eur_olx_url ) . '">' . esc_html__( 'Sync to OLX', 'marketplace-connector-bg-for-woocommerce' ) . '</a></p>';
    }

    public function eur_olx_handle_manual_sync() {
        $eur_olx_product_id = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0;
        if ( ! $eur_olx_product_id || ! current_user_can( 'edit_product', $eur_olx_product_id ) ) {
            wp_die( esc_html__( 'You do not have permission to sync this product.', 'marketplace-connector-bg-for-woocommerce' ) );
        }
        check_admin_referer( self::EUR_OLX_SYNC_NONCE, 'eur_olx_nonce' );

        $eur_olx_result = $this->eur_olx_sync_product( $eur_olx_product_id );
        $eur_olx_args   = is_wp_error( $eur_olx_result )
            ? array( 'eur_olx_error' => rawurlencode( $eur_olx_result->get_error_message() ) )
            : array( 'eur_olx_message' => rawurlencode( esc_html__( 'Product synced to OLX.bg.', 'marketplace-connector-bg-for-woocommerce' ) ) );

        wp_safe_redirect( add_query_arg( $eur_olx_args, get_edit_post_link( $eur_olx_product_id, 'url' ) ) );
        exit;
    }

    public function eur_olx_register_bulk_actions( $eur_olx_actions ) {
        $eur_olx_actions['eur_olx_bulk_sync'] = esc_html__( 'Sync to Marketplace BG', 'marketplace-connector-bg-for-woocommerce' );
        return $eur_olx_actions;
    }

    public function eur_olx_handle_bulk_actions( $eur_olx_redirect, $eur_olx_action, $eur_olx_product_ids ) {
        if ( 'eur_olx_bulk_sync' !== $eur_olx_action ) {
            return $eur_olx_redirect;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return $eur_olx_redirect;
        }
        // WordPress core verifies the bulk action nonce before this filter is called.
        $eur_olx_success = 0;
        $eur_olx_failed  = 0;
        foreach ( array_map( 'absint', (array) $eur_olx_product_ids ) as $eur_olx_product_id ) {
            $eur_olx_result = $this->eur_olx_sync_product( $eur_olx_product_id );
            is_wp_error( $eur_olx_result ) ? $eur_olx_failed++ : $eur_olx_success++;
        }
        return add_query_arg( array( 'eur_olx_success' => $eur_olx_success, 'eur_olx_failed' => $eur_olx_failed ), $eur_olx_redirect );
    }

    public function eur_olx_sync_product( $eur_olx_product_id ) {
        if ( ! function_exists( 'wc_get_product' ) ) {
            return new WP_Error( 'eur_olx_missing_wc', esc_html__( 'WooCommerce is not active.', 'marketplace-connector-bg-for-woocommerce' ) );
        }

        $eur_olx_product = wc_get_product( absint( $eur_olx_product_id ) );
        if ( ! $eur_olx_product ) {
            return new WP_Error( 'eur_olx_missing_product', esc_html__( 'Product not found.', 'marketplace-connector-bg-for-woocommerce' ) );
        }

        $eur_olx_payload = $this->eur_olx_build_advert_payload( $eur_olx_product );
        if ( is_wp_error( $eur_olx_payload ) ) {
            return $eur_olx_payload;
        }

        /** Hook for PRO/custom payload changes: variations, custom attributes, GPS, delivery, safety regulations. */
        $eur_olx_payload = apply_filters( 'eur_olx_advert_payload', $eur_olx_payload, $eur_olx_product );
        do_action( 'eur_olx_before_manual_sync', $eur_olx_product->get_id(), $eur_olx_payload );

        $eur_olx_existing_advert_id = get_post_meta( $eur_olx_product->get_id(), self::EUR_OLX_ADVERT_ID_META, true );
        $eur_olx_response = $eur_olx_existing_advert_id ? $this->eur_olx_api_client->eur_olx_update_v2_advert( $eur_olx_existing_advert_id, $eur_olx_payload ) : $this->eur_olx_api_client->eur_olx_post_v2_advert( $eur_olx_payload );
        if ( is_wp_error( $eur_olx_response ) ) {
            update_post_meta( $eur_olx_product->get_id(), self::EUR_OLX_LAST_ERROR_META, sanitize_text_field( $eur_olx_response->get_error_message() ) );
            return $eur_olx_response;
        }

        if ( isset( $eur_olx_response['id'] ) ) {
            update_post_meta( $eur_olx_product->get_id(), self::EUR_OLX_ADVERT_ID_META, absint( $eur_olx_response['id'] ) );
        }
        if ( isset( $eur_olx_response['status'] ) ) {
            update_post_meta( $eur_olx_product->get_id(), self::EUR_OLX_STATUS_META, sanitize_text_field( $eur_olx_response['status'] ) );
        }
        delete_post_meta( $eur_olx_product->get_id(), self::EUR_OLX_LAST_ERROR_META );
        do_action( 'eur_olx_after_manual_sync', $eur_olx_product->get_id(), $eur_olx_response );

        return $eur_olx_response;
    }

    private function eur_olx_build_advert_payload( WC_Product $eur_olx_product ) {
        $eur_olx_options     = $this->eur_olx_settings->eur_olx_get_options();
        $eur_olx_market      = $this->eur_olx_settings->eur_olx_get_market_config( $eur_olx_options['market'] );
        $eur_olx_category_id = $this->eur_olx_category_map->eur_olx_get_olx_category_id_for_product( $eur_olx_product->get_id() );

        if ( ! $eur_olx_category_id ) {
            return new WP_Error( 'eur_olx_missing_category', esc_html__( 'Missing OLX category mapping for this product.', 'marketplace-connector-bg-for-woocommerce' ) );
        }
        if ( empty( $eur_olx_options['city_id'] ) || empty( $eur_olx_options['contact_name'] ) ) {
            return new WP_Error( 'eur_olx_missing_required_settings', esc_html__( 'Missing default city ID or contact name in Marketplace BG settings.', 'marketplace-connector-bg-for-woocommerce' ) );
        }

        $eur_olx_title = sanitize_text_field( wp_strip_all_tags( $eur_olx_product->get_name() ) );
        $eur_olx_desc  = wp_kses_post( $eur_olx_product->get_description() ? $eur_olx_product->get_description() : $eur_olx_product->get_short_description() );
        $eur_olx_price = (float) wc_get_price_to_display( $eur_olx_product );
        $eur_olx_currency = $eur_olx_options['currency'] ? $eur_olx_options['currency'] : $eur_olx_market['currency'];

        $eur_olx_images = array();
        $eur_olx_image_ids = array_filter( array_unique( array_merge( array( $eur_olx_product->get_image_id() ), $eur_olx_product->get_gallery_image_ids() ) ) );
        foreach ( array_slice( $eur_olx_image_ids, 0, 8 ) as $eur_olx_image_id ) {
            $eur_olx_image_url = wp_get_attachment_url( absint( $eur_olx_image_id ) );
            if ( $eur_olx_image_url && $this->eur_olx_is_public_image_url( $eur_olx_image_url ) ) {
                $eur_olx_images[] = array( 'url' => esc_url_raw( $eur_olx_image_url ) );
            }
        }

        $eur_olx_payload = array(
            'title'           => $eur_olx_title,
            'description'     => $eur_olx_desc,
            'category_id'     => absint( $eur_olx_category_id ),
            'advertiser_type' => sanitize_text_field( $eur_olx_options['advertiser_type'] ),
            'external_id'     => (string) $eur_olx_product->get_id(),
            'contact'         => array(
                'name'  => sanitize_text_field( $eur_olx_options['contact_name'] ),
                'phone' => sanitize_text_field( $eur_olx_options['contact_phone'] ),
            ),
            'location'        => array_filter(
                array(
                    'city_id'     => absint( $eur_olx_options['city_id'] ),
                    'district_id' => ! empty( $eur_olx_options['district_id'] ) ? absint( $eur_olx_options['district_id'] ) : null,
                )
            ),
            'images'          => $eur_olx_images,
            'price'           => array(
                'value'      => $eur_olx_price,
                'currency'   => sanitize_text_field( $eur_olx_currency ),
                'negotiable' => false,
                'trade'      => false,
                'budget'     => false,
            ),
            'attributes'      => $this->eur_olx_category_map->eur_olx_get_attributes_for_product( $eur_olx_product->get_id() ),
        );

        return $eur_olx_payload;
    }

    private function eur_olx_is_public_image_url( $eur_olx_image_url ) {
        $eur_olx_host = wp_parse_url( $eur_olx_image_url, PHP_URL_HOST );
        if ( ! $eur_olx_host ) {
            return false;
        }
        $eur_olx_host = strtolower( $eur_olx_host );
        if ( 'localhost' === $eur_olx_host || '.local' === substr( $eur_olx_host, -6 ) || '.test' === substr( $eur_olx_host, -5 ) ) {
            return false;
        }
        if ( filter_var( $eur_olx_host, FILTER_VALIDATE_IP ) ) {
            return ! preg_match( '/^(127\.|10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[0-1])\.)/', $eur_olx_host );
        }
        return true;
    }
}
