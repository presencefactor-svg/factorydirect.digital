<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class EUR_OLX_API_Client {
    private $eur_olx_settings;

    public function __construct( EUR_OLX_Settings $eur_olx_settings ) {
        $this->eur_olx_settings = $eur_olx_settings;
    }

    public function eur_olx_request( $eur_olx_method, $eur_olx_path, $eur_olx_body = null ) {
        $eur_olx_options = $this->eur_olx_settings->eur_olx_get_options();
        if ( ( empty( $eur_olx_options['access_token'] ) && ! empty( $eur_olx_options['refresh_token'] ) ) || ( ! empty( $eur_olx_options['token_expires_at'] ) && absint( $eur_olx_options['token_expires_at'] ) < time() + 120 ) ) {
            $eur_olx_refreshed = $this->eur_olx_refresh_access_token();
            if ( ! is_wp_error( $eur_olx_refreshed ) ) {
                $eur_olx_options = $this->eur_olx_settings->eur_olx_get_options();
            }
        }

        $eur_olx_market = $this->eur_olx_settings->eur_olx_get_market_config( $eur_olx_options['market'] );
        $eur_olx_token  = trim( (string) $eur_olx_options['access_token'] );

        if ( '' === $eur_olx_token ) {
            return new WP_Error( 'eur_olx_missing_token', esc_html__( 'Missing OAuth access token.', 'marketplace-connector-bg-for-woocommerce' ) );
        }

        $eur_olx_url = trailingslashit( $eur_olx_market['base_url'] ) . ltrim( $eur_olx_path, '/' );
        $eur_olx_args = array(
            'method'  => strtoupper( sanitize_key( $eur_olx_method ) ),
            'timeout' => 45,
            'headers' => array(
                'Accept'        => 'application/json',
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $eur_olx_token,
                'Version'       => '2.0',
            ),
        );

        if ( null !== $eur_olx_body ) {
            $eur_olx_args['body'] = wp_json_encode( $eur_olx_body );
        }

        $eur_olx_args = apply_filters( 'eur_olx_api_request_args', $eur_olx_args, $eur_olx_path, $eur_olx_body );
        $eur_olx_response = wp_remote_request( esc_url_raw( $eur_olx_url ), $eur_olx_args );
        return $this->eur_olx_parse_response( $eur_olx_response );
    }

    public function eur_olx_post_v2_advert( array $eur_olx_payload ) {
        return $this->eur_olx_request( 'POST', '/adverts', $eur_olx_payload );
    }

    public function eur_olx_update_v2_advert( $eur_olx_advert_id, array $eur_olx_payload ) {
        return $this->eur_olx_request( 'PUT', '/adverts/' . absint( $eur_olx_advert_id ), $eur_olx_payload );
    }

    public function eur_olx_refresh_access_token() {
        $eur_olx_options = $this->eur_olx_settings->eur_olx_get_options();
        if ( empty( $eur_olx_options['client_id'] ) || empty( $eur_olx_options['client_secret'] ) || empty( $eur_olx_options['refresh_token'] ) ) {
            return new WP_Error( 'eur_olx_refresh_missing_credentials', esc_html__( 'Missing OAuth refresh credentials.', 'marketplace-connector-bg-for-woocommerce' ) );
        }

        $eur_olx_market = $this->eur_olx_settings->eur_olx_get_market_config( $eur_olx_options['market'] );
        $eur_olx_response = wp_remote_post(
            esc_url_raw( $eur_olx_market['token_url'] ),
            array(
                'timeout' => 45,
                'headers' => array( 'Accept' => 'application/json' ),
                'body'    => array(
                    'grant_type'    => 'refresh_token',
                    'client_id'     => $eur_olx_options['client_id'],
                    'client_secret' => $eur_olx_options['client_secret'],
                    'refresh_token' => $eur_olx_options['refresh_token'],
                ),
            )
        );

        $eur_olx_json = $this->eur_olx_parse_response( $eur_olx_response );
        if ( is_wp_error( $eur_olx_json ) ) {
            return $eur_olx_json;
        }
        $this->eur_olx_settings->eur_olx_save_tokens_from_response( $eur_olx_json );
        return $eur_olx_json;
    }

    private function eur_olx_parse_response( $eur_olx_response ) {
        if ( is_wp_error( $eur_olx_response ) ) {
            return $eur_olx_response;
        }
        $eur_olx_code = (int) wp_remote_retrieve_response_code( $eur_olx_response );
        $eur_olx_raw  = (string) wp_remote_retrieve_body( $eur_olx_response );
        $eur_olx_json = json_decode( $eur_olx_raw, true );
        if ( $eur_olx_code < 200 || $eur_olx_code >= 300 ) {
            return new WP_Error(
                'eur_olx_api_error',
                sprintf(
                    /* translators: 1: HTTP status code, 2: response body */
                    esc_html__( 'OLX API error %1$d: %2$s', 'marketplace-connector-bg-for-woocommerce' ),
                    $eur_olx_code,
                    is_array( $eur_olx_json ) ? wp_json_encode( $eur_olx_json ) : $eur_olx_raw
                )
            );
        }
        if ( is_array( $eur_olx_json ) && array_key_exists( 'data', $eur_olx_json ) ) {
            return is_array( $eur_olx_json['data'] ) ? $eur_olx_json['data'] : array( 'data' => $eur_olx_json['data'] );
        }
        return is_array( $eur_olx_json ) ? $eur_olx_json : array( 'raw' => $eur_olx_raw );
    }
}
