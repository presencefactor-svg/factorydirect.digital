<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class EUR_OLX_Category_Map {
    const EUR_OLX_CATEGORY_MAP_OPTION = 'eur_olx_category_map';
    const EUR_OLX_CATEGORY_MAP_NONCE = 'eur_olx_category_map_nonce_action';

    public function eur_olx_get_map() {
        $eur_olx_map = get_option( self::EUR_OLX_CATEGORY_MAP_OPTION, array() );
        return is_array( $eur_olx_map ) ? $eur_olx_map : array();
    }

    public function eur_olx_get_mapping_for_product( $eur_olx_product_id ) {
        $eur_olx_map   = $this->eur_olx_get_map();
        $eur_olx_terms = wp_get_post_terms( absint( $eur_olx_product_id ), 'product_cat' );
        if ( is_wp_error( $eur_olx_terms ) ) {
            return array();
        }
        foreach ( $eur_olx_terms as $eur_olx_term ) {
            $eur_olx_term_id = (string) absint( $eur_olx_term->term_id );
            if ( empty( $eur_olx_map[ $eur_olx_term_id ] ) ) {
                continue;
            }
            if ( is_array( $eur_olx_map[ $eur_olx_term_id ] ) ) {
                return $eur_olx_map[ $eur_olx_term_id ];
            }
            return array( 'category_id' => absint( $eur_olx_map[ $eur_olx_term_id ] ) );
        }
        return array();
    }

    public function eur_olx_get_olx_category_id_for_product( $eur_olx_product_id ) {
        $eur_olx_mapping = $this->eur_olx_get_mapping_for_product( $eur_olx_product_id );
        return ! empty( $eur_olx_mapping['category_id'] ) ? absint( $eur_olx_mapping['category_id'] ) : '';
    }

    public function eur_olx_get_attributes_for_product( $eur_olx_product_id ) {
        $eur_olx_mapping    = $this->eur_olx_get_mapping_for_product( $eur_olx_product_id );
        $eur_olx_attributes = array();
        $eur_olx_state      = ! empty( $eur_olx_mapping['state'] ) ? sanitize_key( $eur_olx_mapping['state'] ) : 'new';
        if ( $eur_olx_state ) {
            $eur_olx_attributes[] = array( 'code' => 'state', 'value' => $eur_olx_state );
        }
        if ( ! empty( $eur_olx_mapping['attributes'] ) && is_array( $eur_olx_mapping['attributes'] ) ) {
            foreach ( $eur_olx_mapping['attributes'] as $eur_olx_attribute ) {
                if ( empty( $eur_olx_attribute['code'] ) || ! isset( $eur_olx_attribute['value'] ) ) {
                    continue;
                }
                $eur_olx_code  = sanitize_key( $eur_olx_attribute['code'] );
                $eur_olx_value = sanitize_text_field( (string) $eur_olx_attribute['value'] );
                if ( $eur_olx_code && '' !== $eur_olx_value ) {
                    $eur_olx_attributes[] = array( 'code' => $eur_olx_code, 'value' => $eur_olx_value );
                }
            }
        }
        return $this->eur_olx_dedupe_attributes( $eur_olx_attributes );
    }

    public function eur_olx_handle_category_map_save() {
        if ( empty( $_POST['eur_olx_category_map_submit'] ) ) {
            return;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to save category mapping.', 'marketplace-connector-bg-for-woocommerce' ) );
        }
        check_admin_referer( self::EUR_OLX_CATEGORY_MAP_NONCE, 'eur_olx_category_map_nonce' );

        $eur_olx_raw_map = isset( $_POST['eur_olx_category_map'] ) && is_array( $_POST['eur_olx_category_map'] ) ? map_deep( wp_unslash( $_POST['eur_olx_category_map'] ), 'sanitize_text_field' ) : array();
        $eur_olx_clean   = array();
        foreach ( $eur_olx_raw_map as $eur_olx_woo_cat_id => $eur_olx_row ) {
            $eur_olx_woo_cat_id = absint( $eur_olx_woo_cat_id );
            if ( ! $eur_olx_woo_cat_id || ! is_array( $eur_olx_row ) ) {
                continue;
            }
            $eur_olx_olx_cat_id = ! empty( $eur_olx_row['category_id'] ) ? absint( $eur_olx_row['category_id'] ) : 0;
            if ( ! $eur_olx_olx_cat_id ) {
                continue;
            }
            $eur_olx_clean[ (string) $eur_olx_woo_cat_id ] = array(
                'category_id'   => $eur_olx_olx_cat_id,
                'category_path' => isset( $eur_olx_row['category_path'] ) ? sanitize_text_field( $eur_olx_row['category_path'] ) : '',
                'state'         => isset( $eur_olx_row['state'] ) ? sanitize_key( $eur_olx_row['state'] ) : 'new',
                'attributes'    => $this->eur_olx_parse_attribute_lines( isset( $eur_olx_row['attributes'] ) ? (string) $eur_olx_row['attributes'] : '' ),
            );
        }
        update_option( self::EUR_OLX_CATEGORY_MAP_OPTION, $eur_olx_clean, false );
        add_settings_error( 'eur_olx_category_map', 'eur_olx_category_map_saved', esc_html__( 'Category mapping saved.', 'marketplace-connector-bg-for-woocommerce' ), 'updated' );
    }

    public function eur_olx_render_category_map_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'marketplace-connector-bg-for-woocommerce' ) );
        }
        $eur_olx_map        = $this->eur_olx_get_map();
        $eur_olx_categories = $this->eur_olx_get_bg_category_suggestions();
        $eur_olx_terms      = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Marketplace BG Category Mapping', 'marketplace-connector-bg-for-woocommerce' ); ?></h1>
            <p class="description"><?php echo esc_html__( 'Map WooCommerce categories to OLX.bg category IDs and define required category attributes such as condition/state. Category ID fields include live OLX.bg API suggestions when OAuth is connected. Additional attributes use one code=value pair per line, for example brand=Samsung.', 'marketplace-connector-bg-for-woocommerce' ); ?></p>
            <?php if ( ! empty( $eur_olx_categories ) ) : ?>
                <datalist id="eur_olx_bg_categories">
                    <?php foreach ( $eur_olx_categories as $eur_olx_category ) : ?>
                        <option value="<?php echo esc_attr( $eur_olx_category['id'] ); ?>" label="<?php echo esc_attr( $eur_olx_category['name'] ); ?>"></option>
                    <?php endforeach; ?>
                </datalist>
            <?php endif; ?>
            <?php settings_errors( 'eur_olx_category_map' ); ?>
            <form method="post">
                <?php wp_nonce_field( self::EUR_OLX_CATEGORY_MAP_NONCE, 'eur_olx_category_map_nonce' ); ?>
                <input type="hidden" name="eur_olx_category_map_submit" value="1">
                <table class="widefat striped">
                    <thead><tr><th><?php echo esc_html__( 'WooCommerce category', 'marketplace-connector-bg-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'OLX.bg category ID', 'marketplace-connector-bg-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Category note/path', 'marketplace-connector-bg-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Condition', 'marketplace-connector-bg-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Extra attributes', 'marketplace-connector-bg-for-woocommerce' ); ?></th></tr></thead>
                    <tbody>
                    <?php if ( ! is_wp_error( $eur_olx_terms ) ) : ?>
                        <?php foreach ( $eur_olx_terms as $eur_olx_term ) : ?>
                            <?php
                            $eur_olx_row = isset( $eur_olx_map[ (string) $eur_olx_term->term_id ] ) ? $eur_olx_map[ (string) $eur_olx_term->term_id ] : array();
                            if ( ! is_array( $eur_olx_row ) ) {
                                $eur_olx_row = array( 'category_id' => absint( $eur_olx_row ) );
                            }
                            $eur_olx_value = ! empty( $eur_olx_row['category_id'] ) ? absint( $eur_olx_row['category_id'] ) : '';
                            $eur_olx_state = ! empty( $eur_olx_row['state'] ) ? sanitize_key( $eur_olx_row['state'] ) : 'new';
                            ?>
                            <tr>
                                <td><?php echo esc_html( $eur_olx_term->name ); ?></td>
                                <td><input type="number" min="1" list="eur_olx_bg_categories" name="eur_olx_category_map[<?php echo esc_attr( $eur_olx_term->term_id ); ?>][category_id]" value="<?php echo esc_attr( $eur_olx_value ); ?>" class="small-text"></td>
                                <td><input type="text" name="eur_olx_category_map[<?php echo esc_attr( $eur_olx_term->term_id ); ?>][category_path]" value="<?php echo esc_attr( isset( $eur_olx_row['category_path'] ) ? $eur_olx_row['category_path'] : '' ); ?>" class="regular-text" placeholder="<?php echo esc_attr__( 'e.g. Home / Lighting', 'marketplace-connector-bg-for-woocommerce' ); ?>"></td>
                                <td><select name="eur_olx_category_map[<?php echo esc_attr( $eur_olx_term->term_id ); ?>][state]"><option value="new" <?php selected( $eur_olx_state, 'new' ); ?>><?php echo esc_html__( 'New', 'marketplace-connector-bg-for-woocommerce' ); ?></option><option value="used" <?php selected( $eur_olx_state, 'used' ); ?>><?php echo esc_html__( 'Used', 'marketplace-connector-bg-for-woocommerce' ); ?></option></select></td>
                                <td><textarea rows="3" cols="32" name="eur_olx_category_map[<?php echo esc_attr( $eur_olx_term->term_id ); ?>][attributes]" placeholder="brand=Samsung&#10;model=A54"><?php echo esc_textarea( $this->eur_olx_format_attribute_lines( isset( $eur_olx_row['attributes'] ) && is_array( $eur_olx_row['attributes'] ) ? $eur_olx_row['attributes'] : array() ) ); ?></textarea></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
                <?php submit_button( esc_html__( 'Save mapping', 'marketplace-connector-bg-for-woocommerce' ) ); ?>
            </form>
        </div>
        <?php
    }


    private function eur_olx_get_bg_category_suggestions() {
        $eur_olx_cached = get_transient( 'eur_olx_bg_category_suggestions' );
        if ( is_array( $eur_olx_cached ) ) {
            return $eur_olx_cached;
        }
        $eur_olx_options = get_option( 'eur_olx_options', array() );
        if ( empty( $eur_olx_options['access_token'] ) ) {
            return array();
        }
        $eur_olx_response = wp_remote_get(
            'https://www.olx.bg/api/partner/categories?limit=1000',
            array(
                'timeout' => 20,
                'headers' => array(
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer ' . $eur_olx_options['access_token'],
                    'Version'       => '2.0',
                ),
            )
        );
        if ( is_wp_error( $eur_olx_response ) || 200 !== (int) wp_remote_retrieve_response_code( $eur_olx_response ) ) {
            return array();
        }
        $eur_olx_json = json_decode( (string) wp_remote_retrieve_body( $eur_olx_response ), true );
        $eur_olx_rows = isset( $eur_olx_json['data'] ) && is_array( $eur_olx_json['data'] ) ? $eur_olx_json['data'] : array();
        $eur_olx_categories = array();
        foreach ( $eur_olx_rows as $eur_olx_row ) {
            if ( empty( $eur_olx_row['id'] ) || empty( $eur_olx_row['name'] ) ) {
                continue;
            }
            $eur_olx_categories[] = array(
                'id'   => absint( $eur_olx_row['id'] ),
                'name' => sanitize_text_field( (string) $eur_olx_row['name'] ),
            );
        }
        set_transient( 'eur_olx_bg_category_suggestions', $eur_olx_categories, DAY_IN_SECONDS );
        return $eur_olx_categories;
    }

    private function eur_olx_parse_attribute_lines( $eur_olx_raw ) {
        $eur_olx_attributes = array();
        foreach ( preg_split( '/\r\n|\r|\n/', (string) $eur_olx_raw ) as $eur_olx_line ) {
            $eur_olx_line = trim( $eur_olx_line );
            if ( '' === $eur_olx_line || false === strpos( $eur_olx_line, '=' ) ) {
                continue;
            }
            list( $eur_olx_code, $eur_olx_value ) = array_map( 'trim', explode( '=', $eur_olx_line, 2 ) );
            $eur_olx_code  = sanitize_key( $eur_olx_code );
            $eur_olx_value = sanitize_text_field( $eur_olx_value );
            if ( $eur_olx_code && '' !== $eur_olx_value ) {
                $eur_olx_attributes[] = array( 'code' => $eur_olx_code, 'value' => $eur_olx_value );
            }
        }
        return $this->eur_olx_dedupe_attributes( $eur_olx_attributes );
    }

    private function eur_olx_format_attribute_lines( array $eur_olx_attributes ) {
        $eur_olx_lines = array();
        foreach ( $eur_olx_attributes as $eur_olx_attribute ) {
            if ( ! empty( $eur_olx_attribute['code'] ) && isset( $eur_olx_attribute['value'] ) ) {
                $eur_olx_lines[] = sanitize_key( $eur_olx_attribute['code'] ) . '=' . sanitize_text_field( (string) $eur_olx_attribute['value'] );
            }
        }
        return implode( "\n", $eur_olx_lines );
    }

    private function eur_olx_dedupe_attributes( array $eur_olx_attributes ) {
        $eur_olx_seen = array();
        $eur_olx_clean = array();
        foreach ( $eur_olx_attributes as $eur_olx_attribute ) {
            if ( empty( $eur_olx_attribute['code'] ) || ! isset( $eur_olx_attribute['value'] ) ) {
                continue;
            }
            $eur_olx_code = sanitize_key( $eur_olx_attribute['code'] );
            if ( ! $eur_olx_code || isset( $eur_olx_seen[ $eur_olx_code ] ) ) {
                continue;
            }
            $eur_olx_seen[ $eur_olx_code ] = true;
            $eur_olx_clean[] = array( 'code' => $eur_olx_code, 'value' => sanitize_text_field( (string) $eur_olx_attribute['value'] ) );
        }
        return $eur_olx_clean;
    }
}
