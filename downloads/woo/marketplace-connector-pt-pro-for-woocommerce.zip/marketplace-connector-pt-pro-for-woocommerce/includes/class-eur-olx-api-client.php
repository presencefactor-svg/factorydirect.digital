<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCPTP_OLX_API_Client {
    private $mcptp_olx_settings;

    public function __construct( MCPTP_OLX_Settings $mcptp_olx_settings ) {
        $this->mcptp_olx_settings = $mcptp_olx_settings;
    }

    public function mcptp_olx_request( $mcptp_olx_method, $mcptp_olx_path, $mcptp_olx_body = null ) {
        $mcptp_olx_options = $this->mcptp_olx_settings->mcptp_olx_get_options();
        if ( ( empty( $mcptp_olx_options['access_token'] ) && ! empty( $mcptp_olx_options['refresh_token'] ) ) || ( ! empty( $mcptp_olx_options['token_expires_at'] ) && absint( $mcptp_olx_options['token_expires_at'] ) < time() + 120 ) ) {
            $mcptp_olx_refreshed = $this->mcptp_olx_refresh_access_token();
            if ( ! is_wp_error( $mcptp_olx_refreshed ) ) {
                $mcptp_olx_options = $this->mcptp_olx_settings->mcptp_olx_get_options();
            }
        }

        $mcptp_olx_market = $this->mcptp_olx_settings->mcptp_olx_get_market_config( $mcptp_olx_options['market'] );
        $mcptp_olx_token  = trim( (string) $mcptp_olx_options['access_token'] );

        if ( '' === $mcptp_olx_token ) {
            return new WP_Error( 'mcptp_olx_missing_token', esc_html__( 'Missing OAuth access token.', 'marketplace-connector-pt-pro-for-woocommerce' ) );
        }

        $mcptp_olx_url = trailingslashit( $mcptp_olx_market['base_url'] ) . ltrim( $mcptp_olx_path, '/' );
        $mcptp_olx_args = array(
            'method'  => strtoupper( sanitize_key( $mcptp_olx_method ) ),
            'timeout' => 45,
            'headers' => array(
                'Accept'        => 'application/json',
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $mcptp_olx_token,
                'Version'       => '2.0',
            ),
        );

        if ( null !== $mcptp_olx_body ) {
            $mcptp_olx_args['body'] = wp_json_encode( $mcptp_olx_body );
        }

        $mcptp_olx_args = apply_filters( 'mcptp_olx_api_request_args', $mcptp_olx_args, $mcptp_olx_path, $mcptp_olx_body );
        $mcptp_olx_response = wp_remote_request( esc_url_raw( $mcptp_olx_url ), $mcptp_olx_args );
        return $this->mcptp_olx_parse_response( $mcptp_olx_response );
    }

    public function mcptp_olx_post_v2_advert( array $mcptp_olx_payload ) {
        return $this->mcptp_olx_request( 'POST', '/adverts', $mcptp_olx_payload );
    }

    public function mcptp_olx_update_v2_advert( $mcptp_olx_advert_id, array $mcptp_olx_payload ) {
        return $this->mcptp_olx_request( 'PUT', '/adverts/' . absint( $mcptp_olx_advert_id ), $mcptp_olx_payload );
    }

    public function mcptp_olx_refresh_access_token() {
        $mcptp_olx_options = $this->mcptp_olx_settings->mcptp_olx_get_options();
        if ( empty( $mcptp_olx_options['client_id'] ) || empty( $mcptp_olx_options['client_secret'] ) || empty( $mcptp_olx_options['refresh_token'] ) ) {
            return new WP_Error( 'mcptp_olx_refresh_missing_credentials', esc_html__( 'Missing OAuth refresh credentials.', 'marketplace-connector-pt-pro-for-woocommerce' ) );
        }

        $mcptp_olx_market = $this->mcptp_olx_settings->mcptp_olx_get_market_config( $mcptp_olx_options['market'] );
        $mcptp_olx_response = wp_remote_post(
            esc_url_raw( $mcptp_olx_market['token_url'] ),
            array(
                'timeout' => 45,
                'headers' => array( 'Accept' => 'application/json' ),
                'body'    => array(
                    'grant_type'    => 'refresh_token',
                    'client_id'     => $mcptp_olx_options['client_id'],
                    'client_secret' => $mcptp_olx_options['client_secret'],
                    'refresh_token' => $mcptp_olx_options['refresh_token'],
                ),
            )
        );

        $mcptp_olx_json = $this->mcptp_olx_parse_response( $mcptp_olx_response );
        if ( is_wp_error( $mcptp_olx_json ) ) {
            return $mcptp_olx_json;
        }
        $this->mcptp_olx_settings->mcptp_olx_save_tokens_from_response( $mcptp_olx_json );
        return $mcptp_olx_json;
    }

    private function mcptp_olx_parse_response( $mcptp_olx_response ) {
        if ( is_wp_error( $mcptp_olx_response ) ) {
            return $mcptp_olx_response;
        }
        $mcptp_olx_code = (int) wp_remote_retrieve_response_code( $mcptp_olx_response );
        $mcptp_olx_raw  = (string) wp_remote_retrieve_body( $mcptp_olx_response );
        $mcptp_olx_json = json_decode( $mcptp_olx_raw, true );
        if ( $mcptp_olx_code < 200 || $mcptp_olx_code >= 300 ) {
            return new WP_Error(
                'mcptp_olx_api_error',
                sprintf(
                    /* translators: 1: HTTP status code, 2: response body */
                    esc_html__( 'OLX API error %1$d: %2$s', 'marketplace-connector-pt-pro-for-woocommerce' ),
                    $mcptp_olx_code,
                    is_array( $mcptp_olx_json ) ? wp_json_encode( $mcptp_olx_json ) : $mcptp_olx_raw
                )
            );
        }
        if ( is_array( $mcptp_olx_json ) && array_key_exists( 'data', $mcptp_olx_json ) ) {
            return is_array( $mcptp_olx_json['data'] ) ? $mcptp_olx_json['data'] : array( 'data' => $mcptp_olx_json['data'] );
        }
        return is_array( $mcptp_olx_json ) ? $mcptp_olx_json : array( 'raw' => $mcptp_olx_raw );
    }
}
