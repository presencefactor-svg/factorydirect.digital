<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class MCPTP_OLX_Plugin {
    private static $mcptp_olx_instance = null;

    private $mcptp_olx_settings;
    private $mcptp_olx_category_map;
    private $mcptp_olx_product_sync;

    public static function mcptp_olx_instance() {
        if ( null === self::$mcptp_olx_instance ) {
            self::$mcptp_olx_instance = new self();
        }
        return self::$mcptp_olx_instance;
    }

    private function __construct() {
        $this->mcptp_olx_settings     = new MCPTP_OLX_Settings();
        $this->mcptp_olx_category_map = new MCPTP_OLX_Category_Map();
        $this->mcptp_olx_product_sync = new MCPTP_OLX_Product_Sync( $this->mcptp_olx_settings, $this->mcptp_olx_category_map );

        add_action( 'admin_menu', array( $this, 'mcptp_olx_admin_menu' ) );
        add_action( 'admin_init', array( $this->mcptp_olx_settings, 'mcptp_olx_register_settings' ) );
        add_action( 'admin_init', array( $this->mcptp_olx_category_map, 'mcptp_olx_handle_category_map_save' ) );
        add_action( 'admin_post_mcptp_olx_oauth_start', array( $this->mcptp_olx_settings, 'mcptp_olx_handle_oauth_start' ) );
        add_action( 'admin_post_mcptp_olx_oauth_callback', array( $this->mcptp_olx_settings, 'mcptp_olx_handle_oauth_callback' ) );

        $this->mcptp_olx_product_sync->mcptp_olx_register_hooks();

        /**
         * Extension hook: keep this PRO plugin automation-ready; add automation in add-ons if needed.
         */
        do_action( 'mcptp_olx_lite_loaded', $this );
        new MCPTP_OLX_Pro_Automation( $this->mcptp_olx_settings, $this->mcptp_olx_product_sync );
    }

    public function mcptp_olx_admin_menu() {
        add_menu_page(
            esc_html__( 'Marketplace Connector PT PRO for WooCommerce', 'marketplace-connector-pt-pro-for-woocommerce' ),
            esc_html__( 'Marketplace Connector PT PRO for WooCommerce', 'marketplace-connector-pt-pro-for-woocommerce' ),
            'manage_woocommerce',
            'mcptp_olx-settings',
            array( $this->mcptp_olx_settings, 'mcptp_olx_render_settings_page' ),
            'dashicons-store',
            56
        );

        add_submenu_page(
            'mcptp_olx-settings',
            esc_html__( 'Category Mapping', 'marketplace-connector-pt-pro-for-woocommerce' ),
            esc_html__( 'Category Mapping', 'marketplace-connector-pt-pro-for-woocommerce' ),
            'manage_woocommerce',
            'mcptp_olx-category-map',
            array( $this->mcptp_olx_category_map, 'mcptp_olx_render_category_map_page' )
        );
    }

    public function mcptp_olx_get_product_sync() {
        return $this->mcptp_olx_product_sync;
    }

}
