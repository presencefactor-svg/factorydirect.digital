<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCPTP_OLX_Category_Map {
    const MCPTP_OLX_CATEGORY_MAP_OPTION = 'mcptp_olx_category_map';
    const MCPTP_OLX_CATEGORY_MAP_NONCE = 'mcptp_olx_category_map_nonce_action';

    public function mcptp_olx_get_map() {
        $mcptp_olx_map = get_option( self::MCPTP_OLX_CATEGORY_MAP_OPTION, array() );
        return is_array( $mcptp_olx_map ) ? $mcptp_olx_map : array();
    }

    public function mcptp_olx_get_mapping_for_product( $mcptp_olx_product_id ) {
        $mcptp_olx_map   = $this->mcptp_olx_get_map();
        $mcptp_olx_terms = wp_get_post_terms( absint( $mcptp_olx_product_id ), 'product_cat' );
        if ( is_wp_error( $mcptp_olx_terms ) ) {
            return array();
        }
        foreach ( $mcptp_olx_terms as $mcptp_olx_term ) {
            $mcptp_olx_term_id = (string) absint( $mcptp_olx_term->term_id );
            if ( empty( $mcptp_olx_map[ $mcptp_olx_term_id ] ) ) {
                continue;
            }
            if ( is_array( $mcptp_olx_map[ $mcptp_olx_term_id ] ) ) {
                return $mcptp_olx_map[ $mcptp_olx_term_id ];
            }
            return array( 'category_id' => absint( $mcptp_olx_map[ $mcptp_olx_term_id ] ) );
        }
        return array();
    }

    public function mcptp_olx_get_olx_category_id_for_product( $mcptp_olx_product_id ) {
        $mcptp_olx_mapping = $this->mcptp_olx_get_mapping_for_product( $mcptp_olx_product_id );
        return ! empty( $mcptp_olx_mapping['category_id'] ) ? absint( $mcptp_olx_mapping['category_id'] ) : '';
    }

    public function mcptp_olx_get_attributes_for_product( $mcptp_olx_product_id ) {
        $mcptp_olx_mapping    = $this->mcptp_olx_get_mapping_for_product( $mcptp_olx_product_id );
        $mcptp_olx_attributes = array();
        $mcptp_olx_state      = ! empty( $mcptp_olx_mapping['state'] ) ? sanitize_key( $mcptp_olx_mapping['state'] ) : 'new';
        if ( $mcptp_olx_state ) {
            $mcptp_olx_attributes[] = array( 'code' => 'state', 'value' => $mcptp_olx_state );
        }
        if ( ! empty( $mcptp_olx_mapping['attributes'] ) && is_array( $mcptp_olx_mapping['attributes'] ) ) {
            foreach ( $mcptp_olx_mapping['attributes'] as $mcptp_olx_attribute ) {
                if ( empty( $mcptp_olx_attribute['code'] ) || ! isset( $mcptp_olx_attribute['value'] ) ) {
                    continue;
                }
                $mcptp_olx_code  = sanitize_key( $mcptp_olx_attribute['code'] );
                $mcptp_olx_value = sanitize_text_field( (string) $mcptp_olx_attribute['value'] );
                if ( $mcptp_olx_code && '' !== $mcptp_olx_value ) {
                    $mcptp_olx_attributes[] = array( 'code' => $mcptp_olx_code, 'value' => $mcptp_olx_value );
                }
            }
        }
        return $this->mcptp_olx_dedupe_attributes( $mcptp_olx_attributes );
    }

    public function mcptp_olx_handle_category_map_save() {
        if ( empty( $_POST['mcptp_olx_category_map_submit'] ) ) {
            return;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to save category mapping.', 'marketplace-connector-pt-pro-for-woocommerce' ) );
        }
        check_admin_referer( self::MCPTP_OLX_CATEGORY_MAP_NONCE, 'mcptp_olx_category_map_nonce' );

        $mcptp_olx_raw_map = isset( $_POST['mcptp_olx_category_map'] ) && is_array( $_POST['mcptp_olx_category_map'] ) ? map_deep( wp_unslash( $_POST['mcptp_olx_category_map'] ), 'sanitize_text_field' ) : array();
        $mcptp_olx_clean   = array();
        foreach ( $mcptp_olx_raw_map as $mcptp_olx_woo_cat_id => $mcptp_olx_row ) {
            $mcptp_olx_woo_cat_id = absint( $mcptp_olx_woo_cat_id );
            if ( ! $mcptp_olx_woo_cat_id || ! is_array( $mcptp_olx_row ) ) {
                continue;
            }
            $mcptp_olx_olx_cat_id = ! empty( $mcptp_olx_row['category_id'] ) ? absint( $mcptp_olx_row['category_id'] ) : 0;
            if ( ! $mcptp_olx_olx_cat_id ) {
                continue;
            }
            $mcptp_olx_clean[ (string) $mcptp_olx_woo_cat_id ] = array(
                'category_id'   => $mcptp_olx_olx_cat_id,
                'category_path' => isset( $mcptp_olx_row['category_path'] ) ? sanitize_text_field( $mcptp_olx_row['category_path'] ) : '',
                'state'         => isset( $mcptp_olx_row['state'] ) ? sanitize_key( $mcptp_olx_row['state'] ) : 'new',
                'attributes'    => $this->mcptp_olx_parse_attribute_lines( isset( $mcptp_olx_row['attributes'] ) ? (string) $mcptp_olx_row['attributes'] : '' ),
            );
        }
        update_option( self::MCPTP_OLX_CATEGORY_MAP_OPTION, $mcptp_olx_clean, false );
        add_settings_error( 'mcptp_olx_category_map', 'mcptp_olx_category_map_saved', esc_html__( 'Category mapping saved.', 'marketplace-connector-pt-pro-for-woocommerce' ), 'updated' );
    }

    public function mcptp_olx_render_category_map_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'marketplace-connector-pt-pro-for-woocommerce' ) );
        }
        $mcptp_olx_map        = $this->mcptp_olx_get_map();
        $mcptp_olx_categories = $this->mcptp_olx_get_pt_category_suggestions();
        $mcptp_olx_terms      = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Marketplace Connector PT PRO Category Mapping', 'marketplace-connector-pt-pro-for-woocommerce' ); ?></h1>
            <p class="description"><?php echo esc_html__( 'Map WooCommerce categories to OLX.pt category IDs and define required category attributes such as condition/state. Category ID fields include live OLX.pt API suggestions when OAuth is connected. Additional attributes use one code=value pair per line, for example brand=Samsung.', 'marketplace-connector-pt-pro-for-woocommerce' ); ?></p>
            <?php if ( ! empty( $mcptp_olx_categories ) ) : ?>
                <datalist id="mcptp_olx_pt_categories">
                    <?php foreach ( $mcptp_olx_categories as $mcptp_olx_category ) : ?>
                        <option value="<?php echo esc_attr( $mcptp_olx_category['id'] ); ?>" label="<?php echo esc_attr( $mcptp_olx_category['name'] ); ?>"></option>
                    <?php endforeach; ?>
                </datalist>
            <?php endif; ?>
            <?php settings_errors( 'mcptp_olx_category_map' ); ?>
            <form method="post">
                <?php wp_nonce_field( self::MCPTP_OLX_CATEGORY_MAP_NONCE, 'mcptp_olx_category_map_nonce' ); ?>
                <input type="hidden" name="mcptp_olx_category_map_submit" value="1">
                <table class="widefat striped">
                    <thead><tr><th><?php echo esc_html__( 'WooCommerce category', 'marketplace-connector-pt-pro-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'OLX.pt category ID', 'marketplace-connector-pt-pro-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Category note/path', 'marketplace-connector-pt-pro-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Condition', 'marketplace-connector-pt-pro-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Extra attributes', 'marketplace-connector-pt-pro-for-woocommerce' ); ?></th></tr></thead>
                    <tbody>
                    <?php if ( ! is_wp_error( $mcptp_olx_terms ) ) : ?>
                        <?php foreach ( $mcptp_olx_terms as $mcptp_olx_term ) : ?>
                            <?php
                            $mcptp_olx_row = isset( $mcptp_olx_map[ (string) $mcptp_olx_term->term_id ] ) ? $mcptp_olx_map[ (string) $mcptp_olx_term->term_id ] : array();
                            if ( ! is_array( $mcptp_olx_row ) ) {
                                $mcptp_olx_row = array( 'category_id' => absint( $mcptp_olx_row ) );
                            }
                            $mcptp_olx_value = ! empty( $mcptp_olx_row['category_id'] ) ? absint( $mcptp_olx_row['category_id'] ) : '';
                            $mcptp_olx_state = ! empty( $mcptp_olx_row['state'] ) ? sanitize_key( $mcptp_olx_row['state'] ) : 'new';
                            ?>
                            <tr>
                                <td><?php echo esc_html( $mcptp_olx_term->name ); ?></td>
                                <td><input type="number" min="1" list="mcptp_olx_pt_categories" name="mcptp_olx_category_map[<?php echo esc_attr( $mcptp_olx_term->term_id ); ?>][category_id]" value="<?php echo esc_attr( $mcptp_olx_value ); ?>" class="small-text"></td>
                                <td><input type="text" name="mcptp_olx_category_map[<?php echo esc_attr( $mcptp_olx_term->term_id ); ?>][category_path]" value="<?php echo esc_attr( isset( $mcptp_olx_row['category_path'] ) ? $mcptp_olx_row['category_path'] : '' ); ?>" class="regular-text" placeholder="<?php echo esc_attr__( 'e.g. Home / Lighting', 'marketplace-connector-pt-pro-for-woocommerce' ); ?>"></td>
                                <td><select name="mcptp_olx_category_map[<?php echo esc_attr( $mcptp_olx_term->term_id ); ?>][state]"><option value="new" <?php selected( $mcptp_olx_state, 'new' ); ?>><?php echo esc_html__( 'New', 'marketplace-connector-pt-pro-for-woocommerce' ); ?></option><option value="used" <?php selected( $mcptp_olx_state, 'used' ); ?>><?php echo esc_html__( 'Used', 'marketplace-connector-pt-pro-for-woocommerce' ); ?></option></select></td>
                                <td><textarea rows="3" cols="32" name="mcptp_olx_category_map[<?php echo esc_attr( $mcptp_olx_term->term_id ); ?>][attributes]" placeholder="brand=Samsung&#10;model=A54"><?php echo esc_textarea( $this->mcptp_olx_format_attribute_lines( isset( $mcptp_olx_row['attributes'] ) && is_array( $mcptp_olx_row['attributes'] ) ? $mcptp_olx_row['attributes'] : array() ) ); ?></textarea></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
                <?php submit_button( esc_html__( 'Save mapping', 'marketplace-connector-pt-pro-for-woocommerce' ) ); ?>
            </form>
        </div>
        <?php
    }


    private function mcptp_olx_get_pt_category_suggestions() {
        $mcptp_olx_cached = get_transient( 'mcptp_olx_pt_category_suggestions' );
        if ( is_array( $mcptp_olx_cached ) ) {
            return $mcptp_olx_cached;
        }
        $mcptp_olx_options = get_option( 'mcptp_olx_options', array() );
        if ( empty( $mcptp_olx_options['access_token'] ) ) {
            return array();
        }
        $mcptp_olx_response = wp_remote_get(
            'https://www.olx.pt/api/partner/categories?limit=1000',
            array(
                'timeout' => 20,
                'headers' => array(
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer ' . $mcptp_olx_options['access_token'],
                    'Version'       => '2.0',
                ),
            )
        );
        if ( is_wp_error( $mcptp_olx_response ) || 200 !== (int) wp_remote_retrieve_response_code( $mcptp_olx_response ) ) {
            return array();
        }
        $mcptp_olx_json = json_decode( (string) wp_remote_retrieve_body( $mcptp_olx_response ), true );
        $mcptp_olx_rows = isset( $mcptp_olx_json['data'] ) && is_array( $mcptp_olx_json['data'] ) ? $mcptp_olx_json['data'] : array();
        $mcptp_olx_categories = array();
        foreach ( $mcptp_olx_rows as $mcptp_olx_row ) {
            if ( empty( $mcptp_olx_row['id'] ) || empty( $mcptp_olx_row['name'] ) ) {
                continue;
            }
            $mcptp_olx_categories[] = array(
                'id'   => absint( $mcptp_olx_row['id'] ),
                'name' => sanitize_text_field( (string) $mcptp_olx_row['name'] ),
            );
        }
        set_transient( 'mcptp_olx_pt_category_suggestions', $mcptp_olx_categories, DAY_IN_SECONDS );
        return $mcptp_olx_categories;
    }

    private function mcptp_olx_parse_attribute_lines( $mcptp_olx_raw ) {
        $mcptp_olx_attributes = array();
        foreach ( preg_split( '/\r\n|\r|\n/', (string) $mcptp_olx_raw ) as $mcptp_olx_line ) {
            $mcptp_olx_line = trim( $mcptp_olx_line );
            if ( '' === $mcptp_olx_line || false === strpos( $mcptp_olx_line, '=' ) ) {
                continue;
            }
            list( $mcptp_olx_code, $mcptp_olx_value ) = array_map( 'trim', explode( '=', $mcptp_olx_line, 2 ) );
            $mcptp_olx_code  = sanitize_key( $mcptp_olx_code );
            $mcptp_olx_value = sanitize_text_field( $mcptp_olx_value );
            if ( $mcptp_olx_code && '' !== $mcptp_olx_value ) {
                $mcptp_olx_attributes[] = array( 'code' => $mcptp_olx_code, 'value' => $mcptp_olx_value );
            }
        }
        return $this->mcptp_olx_dedupe_attributes( $mcptp_olx_attributes );
    }

    private function mcptp_olx_format_attribute_lines( array $mcptp_olx_attributes ) {
        $mcptp_olx_lines = array();
        foreach ( $mcptp_olx_attributes as $mcptp_olx_attribute ) {
            if ( ! empty( $mcptp_olx_attribute['code'] ) && isset( $mcptp_olx_attribute['value'] ) ) {
                $mcptp_olx_lines[] = sanitize_key( $mcptp_olx_attribute['code'] ) . '=' . sanitize_text_field( (string) $mcptp_olx_attribute['value'] );
            }
        }
        return implode( "\n", $mcptp_olx_lines );
    }

    private function mcptp_olx_dedupe_attributes( array $mcptp_olx_attributes ) {
        $mcptp_olx_seen = array();
        $mcptp_olx_clean = array();
        foreach ( $mcptp_olx_attributes as $mcptp_olx_attribute ) {
            if ( empty( $mcptp_olx_attribute['code'] ) || ! isset( $mcptp_olx_attribute['value'] ) ) {
                continue;
            }
            $mcptp_olx_code = sanitize_key( $mcptp_olx_attribute['code'] );
            if ( ! $mcptp_olx_code || isset( $mcptp_olx_seen[ $mcptp_olx_code ] ) ) {
                continue;
            }
            $mcptp_olx_seen[ $mcptp_olx_code ] = true;
            $mcptp_olx_clean[] = array( 'code' => $mcptp_olx_code, 'value' => sanitize_text_field( (string) $mcptp_olx_attribute['value'] ) );
        }
        return $mcptp_olx_clean;
    }
}
