<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCPTP_OLX_Product_Sync {
    const MCPTP_OLX_ADVERT_ID_META = '_mcptp_olx_advert_id';
    const MCPTP_OLX_STATUS_META    = '_mcptp_olx_status';
    const MCPTP_OLX_LAST_ERROR_META= '_mcptp_olx_last_error';
    const MCPTP_OLX_SYNC_NONCE     = 'mcptp_olx_sync_product_nonce_action';

    private $mcptp_olx_settings;
    private $mcptp_olx_category_map;
    private $mcptp_olx_api_client;

    public function __construct( MCPTP_OLX_Settings $mcptp_olx_settings, MCPTP_OLX_Category_Map $mcptp_olx_category_map ) {
        $this->mcptp_olx_settings     = $mcptp_olx_settings;
        $this->mcptp_olx_category_map = $mcptp_olx_category_map;
        $this->mcptp_olx_api_client   = new MCPTP_OLX_API_Client( $mcptp_olx_settings );
    }

    public function mcptp_olx_register_hooks() {
        add_action( 'add_meta_boxes_product', array( $this, 'mcptp_olx_add_product_metabox' ) );
        add_action( 'admin_post_mcptp_olx_sync_product', array( $this, 'mcptp_olx_handle_manual_sync' ) );
        add_filter( 'bulk_actions-edit-product', array( $this, 'mcptp_olx_register_bulk_actions' ) );
        add_filter( 'handle_bulk_actions-edit-product', array( $this, 'mcptp_olx_handle_bulk_actions' ), 10, 3 );
    }

    public function mcptp_olx_add_product_metabox() {
        add_meta_box(
            'mcptp_olx_product_sync',
            esc_html__( 'Marketplace Connector PT PRO Sync', 'marketplace-connector-pt-pro-for-woocommerce' ),
            array( $this, 'mcptp_olx_render_product_metabox' ),
            'product',
            'side',
            'default'
        );
    }

    public function mcptp_olx_render_product_metabox( $mcptp_olx_post ) {
        if ( ! current_user_can( 'edit_product', $mcptp_olx_post->ID ) ) {
            return;
        }
        $mcptp_olx_advert_id = get_post_meta( $mcptp_olx_post->ID, self::MCPTP_OLX_ADVERT_ID_META, true );
        $mcptp_olx_status    = get_post_meta( $mcptp_olx_post->ID, self::MCPTP_OLX_STATUS_META, true );
        $mcptp_olx_error     = get_post_meta( $mcptp_olx_post->ID, self::MCPTP_OLX_LAST_ERROR_META, true );
        $mcptp_olx_url       = wp_nonce_url(
            admin_url( 'admin-post.php?action=mcptp_olx_sync_product&product_id=' . absint( $mcptp_olx_post->ID ) ),
            self::MCPTP_OLX_SYNC_NONCE,
            'mcptp_olx_nonce'
        );
        echo '<p><strong>' . esc_html__( 'Advert ID:', 'marketplace-connector-pt-pro-for-woocommerce' ) . '</strong> ' . esc_html( $mcptp_olx_advert_id ? $mcptp_olx_advert_id : '-' ) . '</p>';
        echo '<p><strong>' . esc_html__( 'Status:', 'marketplace-connector-pt-pro-for-woocommerce' ) . '</strong> ' . esc_html( $mcptp_olx_status ? $mcptp_olx_status : '-' ) . '</p>';
        if ( $mcptp_olx_error ) {
            echo '<p class="description" style="color:#b32d2e;">' . esc_html( $mcptp_olx_error ) . '</p>';
        }
        echo '<p><a class="button button-primary" href="' . esc_url( $mcptp_olx_url ) . '">' . esc_html__( 'Sync to OLX', 'marketplace-connector-pt-pro-for-woocommerce' ) . '</a></p>';
    }

    public function mcptp_olx_handle_manual_sync() {
        $mcptp_olx_product_id = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0;
        if ( ! $mcptp_olx_product_id || ! current_user_can( 'edit_product', $mcptp_olx_product_id ) ) {
            wp_die( esc_html__( 'You do not have permission to sync this product.', 'marketplace-connector-pt-pro-for-woocommerce' ) );
        }
        check_admin_referer( self::MCPTP_OLX_SYNC_NONCE, 'mcptp_olx_nonce' );

        $mcptp_olx_result = $this->mcptp_olx_sync_product( $mcptp_olx_product_id );
        $mcptp_olx_args   = is_wp_error( $mcptp_olx_result )
            ? array( 'mcptp_olx_error' => rawurlencode( $mcptp_olx_result->get_error_message() ) )
            : array( 'mcptp_olx_message' => rawurlencode( esc_html__( 'Product synced to OLX.pt.', 'marketplace-connector-pt-pro-for-woocommerce' ) ) );

        wp_safe_redirect( add_query_arg( $mcptp_olx_args, get_edit_post_link( $mcptp_olx_product_id, 'url' ) ) );
        exit;
    }

    public function mcptp_olx_register_bulk_actions( $mcptp_olx_actions ) {
        $mcptp_olx_actions['mcptp_olx_bulk_sync'] = esc_html__( 'Sync to Marketplace Connector PT PRO', 'marketplace-connector-pt-pro-for-woocommerce' );
        return $mcptp_olx_actions;
    }

    public function mcptp_olx_handle_bulk_actions( $mcptp_olx_redirect, $mcptp_olx_action, $mcptp_olx_product_ids ) {
        if ( 'mcptp_olx_bulk_sync' !== $mcptp_olx_action ) {
            return $mcptp_olx_redirect;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return $mcptp_olx_redirect;
        }
        // WordPress core verifies the bulk action nonce before this filter is called.
        $mcptp_olx_success = 0;
        $mcptp_olx_failed  = 0;
        foreach ( array_map( 'absint', (array) $mcptp_olx_product_ids ) as $mcptp_olx_product_id ) {
            $mcptp_olx_result = $this->mcptp_olx_sync_product( $mcptp_olx_product_id );
            is_wp_error( $mcptp_olx_result ) ? $mcptp_olx_failed++ : $mcptp_olx_success++;
        }
        return add_query_arg( array( 'mcptp_olx_success' => $mcptp_olx_success, 'mcptp_olx_failed' => $mcptp_olx_failed ), $mcptp_olx_redirect );
    }

    public function mcptp_olx_sync_product( $mcptp_olx_product_id ) {
        if ( ! function_exists( 'wc_get_product' ) ) {
            return new WP_Error( 'mcptp_olx_missing_wc', esc_html__( 'WooCommerce is not active.', 'marketplace-connector-pt-pro-for-woocommerce' ) );
        }

        $mcptp_olx_product = wc_get_product( absint( $mcptp_olx_product_id ) );
        if ( ! $mcptp_olx_product ) {
            return new WP_Error( 'mcptp_olx_missing_product', esc_html__( 'Product not found.', 'marketplace-connector-pt-pro-for-woocommerce' ) );
        }

        $mcptp_olx_payload = $this->mcptp_olx_build_advert_payload( $mcptp_olx_product );
        if ( is_wp_error( $mcptp_olx_payload ) ) {
            return $mcptp_olx_payload;
        }

        /** Hook for PRO/custom payload changes: variations, custom attributes, GPS, delivery, safety regulations. */
        $mcptp_olx_payload = apply_filters( 'mcptp_olx_advert_payload', $mcptp_olx_payload, $mcptp_olx_product );
        do_action( 'mcptp_olx_before_manual_sync', $mcptp_olx_product->get_id(), $mcptp_olx_payload );

        $mcptp_olx_existing_advert_id = get_post_meta( $mcptp_olx_product->get_id(), self::MCPTP_OLX_ADVERT_ID_META, true );
        $mcptp_olx_response = $mcptp_olx_existing_advert_id ? $this->mcptp_olx_api_client->mcptp_olx_update_v2_advert( $mcptp_olx_existing_advert_id, $mcptp_olx_payload ) : $this->mcptp_olx_api_client->mcptp_olx_post_v2_advert( $mcptp_olx_payload );
        if ( is_wp_error( $mcptp_olx_response ) ) {
            update_post_meta( $mcptp_olx_product->get_id(), self::MCPTP_OLX_LAST_ERROR_META, sanitize_text_field( $mcptp_olx_response->get_error_message() ) );
            return $mcptp_olx_response;
        }

        if ( isset( $mcptp_olx_response['id'] ) ) {
            update_post_meta( $mcptp_olx_product->get_id(), self::MCPTP_OLX_ADVERT_ID_META, absint( $mcptp_olx_response['id'] ) );
        }
        if ( isset( $mcptp_olx_response['status'] ) ) {
            update_post_meta( $mcptp_olx_product->get_id(), self::MCPTP_OLX_STATUS_META, sanitize_text_field( $mcptp_olx_response['status'] ) );
        }
        delete_post_meta( $mcptp_olx_product->get_id(), self::MCPTP_OLX_LAST_ERROR_META );
        do_action( 'mcptp_olx_after_manual_sync', $mcptp_olx_product->get_id(), $mcptp_olx_response );

        return $mcptp_olx_response;
    }

    private function mcptp_olx_build_advert_payload( WC_Product $mcptp_olx_product ) {
        $mcptp_olx_options     = $this->mcptp_olx_settings->mcptp_olx_get_options();
        $mcptp_olx_market      = $this->mcptp_olx_settings->mcptp_olx_get_market_config( $mcptp_olx_options['market'] );
        $mcptp_olx_category_id = $this->mcptp_olx_category_map->mcptp_olx_get_olx_category_id_for_product( $mcptp_olx_product->get_id() );

        if ( ! $mcptp_olx_category_id ) {
            return new WP_Error( 'mcptp_olx_missing_category', esc_html__( 'Missing OLX category mapping for this product.', 'marketplace-connector-pt-pro-for-woocommerce' ) );
        }
        if ( empty( $mcptp_olx_options['city_id'] ) || empty( $mcptp_olx_options['contact_name'] ) ) {
            return new WP_Error( 'mcptp_olx_missing_required_settings', esc_html__( 'Missing default city ID or contact name in Marketplace Connector PT PRO settings.', 'marketplace-connector-pt-pro-for-woocommerce' ) );
        }

        $mcptp_olx_title = sanitize_text_field( wp_strip_all_tags( $mcptp_olx_product->get_name() ) );
        $mcptp_olx_desc  = wp_kses_post( $mcptp_olx_product->get_description() ? $mcptp_olx_product->get_description() : $mcptp_olx_product->get_short_description() );
        $mcptp_olx_price = (float) wc_get_price_to_display( $mcptp_olx_product );
        $mcptp_olx_currency = $mcptp_olx_options['currency'] ? $mcptp_olx_options['currency'] : $mcptp_olx_market['currency'];

        $mcptp_olx_images = array();
        $mcptp_olx_image_ids = array_filter( array_unique( array_merge( array( $mcptp_olx_product->get_image_id() ), $mcptp_olx_product->get_gallery_image_ids() ) ) );
        foreach ( array_slice( $mcptp_olx_image_ids, 0, 8 ) as $mcptp_olx_image_id ) {
            $mcptp_olx_image_url = wp_get_attachment_url( absint( $mcptp_olx_image_id ) );
            if ( $mcptp_olx_image_url && $this->mcptp_olx_is_public_image_url( $mcptp_olx_image_url ) ) {
                $mcptp_olx_images[] = array( 'url' => esc_url_raw( $mcptp_olx_image_url ) );
            }
        }

        $mcptp_olx_payload = array(
            'title'           => $mcptp_olx_title,
            'description'     => $mcptp_olx_desc,
            'category_id'     => absint( $mcptp_olx_category_id ),
            'advertiser_type' => sanitize_text_field( $mcptp_olx_options['advertiser_type'] ),
            'external_id'     => (string) $mcptp_olx_product->get_id(),
            'contact'         => array(
                'name'  => sanitize_text_field( $mcptp_olx_options['contact_name'] ),
                'phone' => sanitize_text_field( $mcptp_olx_options['contact_phone'] ),
            ),
            'location'        => array_filter(
                array(
                    'city_id'     => absint( $mcptp_olx_options['city_id'] ),
                    'district_id' => ! empty( $mcptp_olx_options['district_id'] ) ? absint( $mcptp_olx_options['district_id'] ) : null,
                )
            ),
            'images'          => $mcptp_olx_images,
            'price'           => array(
                'value'      => $mcptp_olx_price,
                'currency'   => sanitize_text_field( $mcptp_olx_currency ),
                'negotiable' => false,
                'trade'      => false,
                'budget'     => false,
            ),
            'attributes'      => $this->mcptp_olx_category_map->mcptp_olx_get_attributes_for_product( $mcptp_olx_product->get_id() ),
        );

        return $mcptp_olx_payload;
    }

    private function mcptp_olx_is_public_image_url( $mcptp_olx_image_url ) {
        $mcptp_olx_host = wp_parse_url( $mcptp_olx_image_url, PHP_URL_HOST );
        if ( ! $mcptp_olx_host ) {
            return false;
        }
        $mcptp_olx_host = strtolower( $mcptp_olx_host );
        if ( 'localhost' === $mcptp_olx_host || '.local' === substr( $mcptp_olx_host, -6 ) || '.test' === substr( $mcptp_olx_host, -5 ) ) {
            return false;
        }
        if ( filter_var( $mcptp_olx_host, FILTER_VALIDATE_IP ) ) {
            return ! preg_match( '/^(127\.|10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[0-1])\.)/', $mcptp_olx_host );
        }
        return true;
    }
}
