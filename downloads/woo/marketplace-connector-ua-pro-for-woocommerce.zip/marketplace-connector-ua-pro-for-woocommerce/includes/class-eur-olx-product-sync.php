<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCUAP_OLX_Product_Sync {
    const MCUAP_OLX_ADVERT_ID_META = '_mcuap_olx_advert_id';
    const MCUAP_OLX_STATUS_META    = '_mcuap_olx_status';
    const MCUAP_OLX_LAST_ERROR_META= '_mcuap_olx_last_error';
    const MCUAP_OLX_SYNC_NONCE     = 'mcuap_olx_sync_product_nonce_action';

    private $mcuap_olx_settings;
    private $mcuap_olx_category_map;
    private $mcuap_olx_api_client;

    public function __construct( MCUAP_OLX_Settings $mcuap_olx_settings, MCUAP_OLX_Category_Map $mcuap_olx_category_map ) {
        $this->mcuap_olx_settings     = $mcuap_olx_settings;
        $this->mcuap_olx_category_map = $mcuap_olx_category_map;
        $this->mcuap_olx_api_client   = new MCUAP_OLX_API_Client( $mcuap_olx_settings );
    }

    public function mcuap_olx_register_hooks() {
        add_action( 'add_meta_boxes_product', array( $this, 'mcuap_olx_add_product_metabox' ) );
        add_action( 'admin_post_mcuap_olx_sync_product', array( $this, 'mcuap_olx_handle_manual_sync' ) );
        add_filter( 'bulk_actions-edit-product', array( $this, 'mcuap_olx_register_bulk_actions' ) );
        add_filter( 'handle_bulk_actions-edit-product', array( $this, 'mcuap_olx_handle_bulk_actions' ), 10, 3 );
    }

    public function mcuap_olx_add_product_metabox() {
        add_meta_box(
            'mcuap_olx_product_sync',
            esc_html__( 'Marketplace Connector UA PRO Sync', 'marketplace-connector-ua-pro-for-woocommerce' ),
            array( $this, 'mcuap_olx_render_product_metabox' ),
            'product',
            'side',
            'default'
        );
    }

    public function mcuap_olx_render_product_metabox( $mcuap_olx_post ) {
        if ( ! current_user_can( 'edit_product', $mcuap_olx_post->ID ) ) {
            return;
        }
        $mcuap_olx_advert_id = get_post_meta( $mcuap_olx_post->ID, self::MCUAP_OLX_ADVERT_ID_META, true );
        $mcuap_olx_status    = get_post_meta( $mcuap_olx_post->ID, self::MCUAP_OLX_STATUS_META, true );
        $mcuap_olx_error     = get_post_meta( $mcuap_olx_post->ID, self::MCUAP_OLX_LAST_ERROR_META, true );
        $mcuap_olx_url       = wp_nonce_url(
            admin_url( 'admin-post.php?action=mcuap_olx_sync_product&product_id=' . absint( $mcuap_olx_post->ID ) ),
            self::MCUAP_OLX_SYNC_NONCE,
            'mcuap_olx_nonce'
        );
        echo '<p><strong>' . esc_html__( 'Advert ID:', 'marketplace-connector-ua-pro-for-woocommerce' ) . '</strong> ' . esc_html( $mcuap_olx_advert_id ? $mcuap_olx_advert_id : '-' ) . '</p>';
        echo '<p><strong>' . esc_html__( 'Status:', 'marketplace-connector-ua-pro-for-woocommerce' ) . '</strong> ' . esc_html( $mcuap_olx_status ? $mcuap_olx_status : '-' ) . '</p>';
        if ( $mcuap_olx_error ) {
            echo '<p class="description" style="color:#b32d2e;">' . esc_html( $mcuap_olx_error ) . '</p>';
        }
        echo '<p><a class="button button-primary" href="' . esc_url( $mcuap_olx_url ) . '">' . esc_html__( 'Sync to OLX', 'marketplace-connector-ua-pro-for-woocommerce' ) . '</a></p>';
    }

    public function mcuap_olx_handle_manual_sync() {
        $mcuap_olx_product_id = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0;
        if ( ! $mcuap_olx_product_id || ! current_user_can( 'edit_product', $mcuap_olx_product_id ) ) {
            wp_die( esc_html__( 'You do not have permission to sync this product.', 'marketplace-connector-ua-pro-for-woocommerce' ) );
        }
        check_admin_referer( self::MCUAP_OLX_SYNC_NONCE, 'mcuap_olx_nonce' );

        $mcuap_olx_result = $this->mcuap_olx_sync_product( $mcuap_olx_product_id );
        $mcuap_olx_args   = is_wp_error( $mcuap_olx_result )
            ? array( 'mcuap_olx_error' => rawurlencode( $mcuap_olx_result->get_error_message() ) )
            : array( 'mcuap_olx_message' => rawurlencode( esc_html__( 'Product synced to OLX.ua.', 'marketplace-connector-ua-pro-for-woocommerce' ) ) );

        wp_safe_redirect( add_query_arg( $mcuap_olx_args, get_edit_post_link( $mcuap_olx_product_id, 'url' ) ) );
        exit;
    }

    public function mcuap_olx_register_bulk_actions( $mcuap_olx_actions ) {
        $mcuap_olx_actions['mcuap_olx_bulk_sync'] = esc_html__( 'Sync to Marketplace Connector UA PRO', 'marketplace-connector-ua-pro-for-woocommerce' );
        return $mcuap_olx_actions;
    }

    public function mcuap_olx_handle_bulk_actions( $mcuap_olx_redirect, $mcuap_olx_action, $mcuap_olx_product_ids ) {
        if ( 'mcuap_olx_bulk_sync' !== $mcuap_olx_action ) {
            return $mcuap_olx_redirect;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return $mcuap_olx_redirect;
        }
        // WordPress core verifies the bulk action nonce before this filter is called.
        $mcuap_olx_success = 0;
        $mcuap_olx_failed  = 0;
        foreach ( array_map( 'absint', (array) $mcuap_olx_product_ids ) as $mcuap_olx_product_id ) {
            $mcuap_olx_result = $this->mcuap_olx_sync_product( $mcuap_olx_product_id );
            is_wp_error( $mcuap_olx_result ) ? $mcuap_olx_failed++ : $mcuap_olx_success++;
        }
        return add_query_arg( array( 'mcuap_olx_success' => $mcuap_olx_success, 'mcuap_olx_failed' => $mcuap_olx_failed ), $mcuap_olx_redirect );
    }

    public function mcuap_olx_sync_product( $mcuap_olx_product_id ) {
        if ( ! function_exists( 'wc_get_product' ) ) {
            return new WP_Error( 'mcuap_olx_missing_wc', esc_html__( 'WooCommerce is not active.', 'marketplace-connector-ua-pro-for-woocommerce' ) );
        }

        $mcuap_olx_product = wc_get_product( absint( $mcuap_olx_product_id ) );
        if ( ! $mcuap_olx_product ) {
            return new WP_Error( 'mcuap_olx_missing_product', esc_html__( 'Product not found.', 'marketplace-connector-ua-pro-for-woocommerce' ) );
        }

        $mcuap_olx_payload = $this->mcuap_olx_build_advert_payload( $mcuap_olx_product );
        if ( is_wp_error( $mcuap_olx_payload ) ) {
            return $mcuap_olx_payload;
        }

        /** Hook for PRO/custom payload changes: variations, custom attributes, GPS, delivery, safety regulations. */
        $mcuap_olx_payload = apply_filters( 'mcuap_olx_advert_payload', $mcuap_olx_payload, $mcuap_olx_product );
        do_action( 'mcuap_olx_before_manual_sync', $mcuap_olx_product->get_id(), $mcuap_olx_payload );

        $mcuap_olx_existing_advert_id = get_post_meta( $mcuap_olx_product->get_id(), self::MCUAP_OLX_ADVERT_ID_META, true );
        $mcuap_olx_response = $mcuap_olx_existing_advert_id ? $this->mcuap_olx_api_client->mcuap_olx_update_v2_advert( $mcuap_olx_existing_advert_id, $mcuap_olx_payload ) : $this->mcuap_olx_api_client->mcuap_olx_post_v2_advert( $mcuap_olx_payload );
        if ( is_wp_error( $mcuap_olx_response ) ) {
            update_post_meta( $mcuap_olx_product->get_id(), self::MCUAP_OLX_LAST_ERROR_META, sanitize_text_field( $mcuap_olx_response->get_error_message() ) );
            return $mcuap_olx_response;
        }

        if ( isset( $mcuap_olx_response['id'] ) ) {
            update_post_meta( $mcuap_olx_product->get_id(), self::MCUAP_OLX_ADVERT_ID_META, absint( $mcuap_olx_response['id'] ) );
        }
        if ( isset( $mcuap_olx_response['status'] ) ) {
            update_post_meta( $mcuap_olx_product->get_id(), self::MCUAP_OLX_STATUS_META, sanitize_text_field( $mcuap_olx_response['status'] ) );
        }
        delete_post_meta( $mcuap_olx_product->get_id(), self::MCUAP_OLX_LAST_ERROR_META );
        do_action( 'mcuap_olx_after_manual_sync', $mcuap_olx_product->get_id(), $mcuap_olx_response );

        return $mcuap_olx_response;
    }

    private function mcuap_olx_build_advert_payload( WC_Product $mcuap_olx_product ) {
        $mcuap_olx_options     = $this->mcuap_olx_settings->mcuap_olx_get_options();
        $mcuap_olx_market      = $this->mcuap_olx_settings->mcuap_olx_get_market_config( $mcuap_olx_options['market'] );
        $mcuap_olx_category_id = $this->mcuap_olx_category_map->mcuap_olx_get_olx_category_id_for_product( $mcuap_olx_product->get_id() );

        if ( ! $mcuap_olx_category_id ) {
            return new WP_Error( 'mcuap_olx_missing_category', esc_html__( 'Missing OLX category mapping for this product.', 'marketplace-connector-ua-pro-for-woocommerce' ) );
        }
        if ( empty( $mcuap_olx_options['city_id'] ) || empty( $mcuap_olx_options['contact_name'] ) ) {
            return new WP_Error( 'mcuap_olx_missing_required_settings', esc_html__( 'Missing default city ID or contact name in Marketplace Connector UA PRO settings.', 'marketplace-connector-ua-pro-for-woocommerce' ) );
        }

        $mcuap_olx_title = sanitize_text_field( wp_strip_all_tags( $mcuap_olx_product->get_name() ) );
        $mcuap_olx_desc  = wp_kses_post( $mcuap_olx_product->get_description() ? $mcuap_olx_product->get_description() : $mcuap_olx_product->get_short_description() );
        $mcuap_olx_price = (float) wc_get_price_to_display( $mcuap_olx_product );
        $mcuap_olx_currency = $mcuap_olx_options['currency'] ? $mcuap_olx_options['currency'] : $mcuap_olx_market['currency'];

        $mcuap_olx_images = array();
        $mcuap_olx_image_ids = array_filter( array_unique( array_merge( array( $mcuap_olx_product->get_image_id() ), $mcuap_olx_product->get_gallery_image_ids() ) ) );
        foreach ( array_slice( $mcuap_olx_image_ids, 0, 8 ) as $mcuap_olx_image_id ) {
            $mcuap_olx_image_url = wp_get_attachment_url( absint( $mcuap_olx_image_id ) );
            if ( $mcuap_olx_image_url && $this->mcuap_olx_is_public_image_url( $mcuap_olx_image_url ) ) {
                $mcuap_olx_images[] = array( 'url' => esc_url_raw( $mcuap_olx_image_url ) );
            }
        }

        $mcuap_olx_payload = array(
            'title'           => $mcuap_olx_title,
            'description'     => $mcuap_olx_desc,
            'category_id'     => absint( $mcuap_olx_category_id ),
            'advertiser_type' => sanitize_text_field( $mcuap_olx_options['advertiser_type'] ),
            'external_id'     => (string) $mcuap_olx_product->get_id(),
            'contact'         => array(
                'name'  => sanitize_text_field( $mcuap_olx_options['contact_name'] ),
                'phone' => sanitize_text_field( $mcuap_olx_options['contact_phone'] ),
            ),
            'location'        => array_filter(
                array(
                    'city_id'     => absint( $mcuap_olx_options['city_id'] ),
                    'district_id' => ! empty( $mcuap_olx_options['district_id'] ) ? absint( $mcuap_olx_options['district_id'] ) : null,
                )
            ),
            'images'          => $mcuap_olx_images,
            'price'           => array(
                'value'      => $mcuap_olx_price,
                'currency'   => sanitize_text_field( $mcuap_olx_currency ),
                'negotiable' => false,
                'trade'      => false,
                'budget'     => false,
            ),
            'attributes'      => $this->mcuap_olx_category_map->mcuap_olx_get_attributes_for_product( $mcuap_olx_product->get_id() ),
        );

        return $mcuap_olx_payload;
    }

    private function mcuap_olx_is_public_image_url( $mcuap_olx_image_url ) {
        $mcuap_olx_host = wp_parse_url( $mcuap_olx_image_url, PHP_URL_HOST );
        if ( ! $mcuap_olx_host ) {
            return false;
        }
        $mcuap_olx_host = strtolower( $mcuap_olx_host );
        if ( 'localhost' === $mcuap_olx_host || '.local' === substr( $mcuap_olx_host, -6 ) || '.test' === substr( $mcuap_olx_host, -5 ) ) {
            return false;
        }
        if ( filter_var( $mcuap_olx_host, FILTER_VALIDATE_IP ) ) {
            return ! preg_match( '/^(127\.|10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[0-1])\.)/', $mcuap_olx_host );
        }
        return true;
    }
}
