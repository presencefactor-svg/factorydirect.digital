<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCUAP_OLX_Category_Map {
    const MCUAP_OLX_CATEGORY_MAP_OPTION = 'mcuap_olx_category_map';
    const MCUAP_OLX_CATEGORY_MAP_NONCE = 'mcuap_olx_category_map_nonce_action';

    public function mcuap_olx_get_map() {
        $mcuap_olx_map = get_option( self::MCUAP_OLX_CATEGORY_MAP_OPTION, array() );
        return is_array( $mcuap_olx_map ) ? $mcuap_olx_map : array();
    }

    public function mcuap_olx_get_mapping_for_product( $mcuap_olx_product_id ) {
        $mcuap_olx_map   = $this->mcuap_olx_get_map();
        $mcuap_olx_terms = wp_get_post_terms( absint( $mcuap_olx_product_id ), 'product_cat' );
        if ( is_wp_error( $mcuap_olx_terms ) ) {
            return array();
        }
        foreach ( $mcuap_olx_terms as $mcuap_olx_term ) {
            $mcuap_olx_term_id = (string) absint( $mcuap_olx_term->term_id );
            if ( empty( $mcuap_olx_map[ $mcuap_olx_term_id ] ) ) {
                continue;
            }
            if ( is_array( $mcuap_olx_map[ $mcuap_olx_term_id ] ) ) {
                return $mcuap_olx_map[ $mcuap_olx_term_id ];
            }
            return array( 'category_id' => absint( $mcuap_olx_map[ $mcuap_olx_term_id ] ) );
        }
        return array();
    }

    public function mcuap_olx_get_olx_category_id_for_product( $mcuap_olx_product_id ) {
        $mcuap_olx_mapping = $this->mcuap_olx_get_mapping_for_product( $mcuap_olx_product_id );
        return ! empty( $mcuap_olx_mapping['category_id'] ) ? absint( $mcuap_olx_mapping['category_id'] ) : '';
    }

    public function mcuap_olx_get_attributes_for_product( $mcuap_olx_product_id ) {
        $mcuap_olx_mapping    = $this->mcuap_olx_get_mapping_for_product( $mcuap_olx_product_id );
        $mcuap_olx_attributes = array();
        $mcuap_olx_state      = ! empty( $mcuap_olx_mapping['state'] ) ? sanitize_key( $mcuap_olx_mapping['state'] ) : 'new';
        if ( $mcuap_olx_state ) {
            $mcuap_olx_attributes[] = array( 'code' => 'state', 'value' => $mcuap_olx_state );
        }
        if ( ! empty( $mcuap_olx_mapping['attributes'] ) && is_array( $mcuap_olx_mapping['attributes'] ) ) {
            foreach ( $mcuap_olx_mapping['attributes'] as $mcuap_olx_attribute ) {
                if ( empty( $mcuap_olx_attribute['code'] ) || ! isset( $mcuap_olx_attribute['value'] ) ) {
                    continue;
                }
                $mcuap_olx_code  = sanitize_key( $mcuap_olx_attribute['code'] );
                $mcuap_olx_value = sanitize_text_field( (string) $mcuap_olx_attribute['value'] );
                if ( $mcuap_olx_code && '' !== $mcuap_olx_value ) {
                    $mcuap_olx_attributes[] = array( 'code' => $mcuap_olx_code, 'value' => $mcuap_olx_value );
                }
            }
        }
        return $this->mcuap_olx_dedupe_attributes( $mcuap_olx_attributes );
    }

    public function mcuap_olx_handle_category_map_save() {
        if ( empty( $_POST['mcuap_olx_category_map_submit'] ) ) {
            return;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to save category mapping.', 'marketplace-connector-ua-pro-for-woocommerce' ) );
        }
        check_admin_referer( self::MCUAP_OLX_CATEGORY_MAP_NONCE, 'mcuap_olx_category_map_nonce' );

        $mcuap_olx_raw_map = isset( $_POST['mcuap_olx_category_map'] ) && is_array( $_POST['mcuap_olx_category_map'] ) ? map_deep( wp_unslash( $_POST['mcuap_olx_category_map'] ), 'sanitize_text_field' ) : array();
        $mcuap_olx_clean   = array();
        foreach ( $mcuap_olx_raw_map as $mcuap_olx_woo_cat_id => $mcuap_olx_row ) {
            $mcuap_olx_woo_cat_id = absint( $mcuap_olx_woo_cat_id );
            if ( ! $mcuap_olx_woo_cat_id || ! is_array( $mcuap_olx_row ) ) {
                continue;
            }
            $mcuap_olx_olx_cat_id = ! empty( $mcuap_olx_row['category_id'] ) ? absint( $mcuap_olx_row['category_id'] ) : 0;
            if ( ! $mcuap_olx_olx_cat_id ) {
                continue;
            }
            $mcuap_olx_clean[ (string) $mcuap_olx_woo_cat_id ] = array(
                'category_id'   => $mcuap_olx_olx_cat_id,
                'category_path' => isset( $mcuap_olx_row['category_path'] ) ? sanitize_text_field( $mcuap_olx_row['category_path'] ) : '',
                'state'         => isset( $mcuap_olx_row['state'] ) ? sanitize_key( $mcuap_olx_row['state'] ) : 'new',
                'attributes'    => $this->mcuap_olx_parse_attribute_lines( isset( $mcuap_olx_row['attributes'] ) ? (string) $mcuap_olx_row['attributes'] : '' ),
            );
        }
        update_option( self::MCUAP_OLX_CATEGORY_MAP_OPTION, $mcuap_olx_clean, false );
        add_settings_error( 'mcuap_olx_category_map', 'mcuap_olx_category_map_saved', esc_html__( 'Category mapping saved.', 'marketplace-connector-ua-pro-for-woocommerce' ), 'updated' );
    }

    public function mcuap_olx_render_category_map_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'marketplace-connector-ua-pro-for-woocommerce' ) );
        }
        $mcuap_olx_map        = $this->mcuap_olx_get_map();
        $mcuap_olx_categories = $this->mcuap_olx_get_ua_category_suggestions();
        $mcuap_olx_terms      = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Marketplace Connector UA PRO Category Mapping', 'marketplace-connector-ua-pro-for-woocommerce' ); ?></h1>
            <p class="description"><?php echo esc_html__( 'Map WooCommerce categories to OLX.ua category IDs and define required category attributes such as condition/state. Category ID fields include live OLX.ua API suggestions when OAuth is connected. Additional attributes use one code=value pair per line, for example brand=Samsung.', 'marketplace-connector-ua-pro-for-woocommerce' ); ?></p>
            <?php if ( ! empty( $mcuap_olx_categories ) ) : ?>
                <datalist id="mcuap_olx_ua_categories">
                    <?php foreach ( $mcuap_olx_categories as $mcuap_olx_category ) : ?>
                        <option value="<?php echo esc_attr( $mcuap_olx_category['id'] ); ?>" label="<?php echo esc_attr( $mcuap_olx_category['name'] ); ?>"></option>
                    <?php endforeach; ?>
                </datalist>
            <?php endif; ?>
            <?php settings_errors( 'mcuap_olx_category_map' ); ?>
            <form method="post">
                <?php wp_nonce_field( self::MCUAP_OLX_CATEGORY_MAP_NONCE, 'mcuap_olx_category_map_nonce' ); ?>
                <input type="hidden" name="mcuap_olx_category_map_submit" value="1">
                <table class="widefat striped">
                    <thead><tr><th><?php echo esc_html__( 'WooCommerce category', 'marketplace-connector-ua-pro-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'OLX.ua category ID', 'marketplace-connector-ua-pro-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Category note/path', 'marketplace-connector-ua-pro-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Condition', 'marketplace-connector-ua-pro-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Extra attributes', 'marketplace-connector-ua-pro-for-woocommerce' ); ?></th></tr></thead>
                    <tbody>
                    <?php if ( ! is_wp_error( $mcuap_olx_terms ) ) : ?>
                        <?php foreach ( $mcuap_olx_terms as $mcuap_olx_term ) : ?>
                            <?php
                            $mcuap_olx_row = isset( $mcuap_olx_map[ (string) $mcuap_olx_term->term_id ] ) ? $mcuap_olx_map[ (string) $mcuap_olx_term->term_id ] : array();
                            if ( ! is_array( $mcuap_olx_row ) ) {
                                $mcuap_olx_row = array( 'category_id' => absint( $mcuap_olx_row ) );
                            }
                            $mcuap_olx_value = ! empty( $mcuap_olx_row['category_id'] ) ? absint( $mcuap_olx_row['category_id'] ) : '';
                            $mcuap_olx_state = ! empty( $mcuap_olx_row['state'] ) ? sanitize_key( $mcuap_olx_row['state'] ) : 'new';
                            ?>
                            <tr>
                                <td><?php echo esc_html( $mcuap_olx_term->name ); ?></td>
                                <td><input type="number" min="1" list="mcuap_olx_ua_categories" name="mcuap_olx_category_map[<?php echo esc_attr( $mcuap_olx_term->term_id ); ?>][category_id]" value="<?php echo esc_attr( $mcuap_olx_value ); ?>" class="small-text"></td>
                                <td><input type="text" name="mcuap_olx_category_map[<?php echo esc_attr( $mcuap_olx_term->term_id ); ?>][category_path]" value="<?php echo esc_attr( isset( $mcuap_olx_row['category_path'] ) ? $mcuap_olx_row['category_path'] : '' ); ?>" class="regular-text" placeholder="<?php echo esc_attr__( 'e.g. Home / Lighting', 'marketplace-connector-ua-pro-for-woocommerce' ); ?>"></td>
                                <td><select name="mcuap_olx_category_map[<?php echo esc_attr( $mcuap_olx_term->term_id ); ?>][state]"><option value="new" <?php selected( $mcuap_olx_state, 'new' ); ?>><?php echo esc_html__( 'New', 'marketplace-connector-ua-pro-for-woocommerce' ); ?></option><option value="used" <?php selected( $mcuap_olx_state, 'used' ); ?>><?php echo esc_html__( 'Used', 'marketplace-connector-ua-pro-for-woocommerce' ); ?></option></select></td>
                                <td><textarea rows="3" cols="32" name="mcuap_olx_category_map[<?php echo esc_attr( $mcuap_olx_term->term_id ); ?>][attributes]" placeholder="brand=Samsung&#10;model=A54"><?php echo esc_textarea( $this->mcuap_olx_format_attribute_lines( isset( $mcuap_olx_row['attributes'] ) && is_array( $mcuap_olx_row['attributes'] ) ? $mcuap_olx_row['attributes'] : array() ) ); ?></textarea></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
                <?php submit_button( esc_html__( 'Save mapping', 'marketplace-connector-ua-pro-for-woocommerce' ) ); ?>
            </form>
        </div>
        <?php
    }


    private function mcuap_olx_get_ua_category_suggestions() {
        $mcuap_olx_cached = get_transient( 'mcuap_olx_ua_category_suggestions' );
        if ( is_array( $mcuap_olx_cached ) ) {
            return $mcuap_olx_cached;
        }
        $mcuap_olx_options = get_option( 'mcuap_olx_options', array() );
        if ( empty( $mcuap_olx_options['access_token'] ) ) {
            return array();
        }
        $mcuap_olx_response = wp_remote_get(
            'https://www.olx.ua/api/partner/categories?limit=1000',
            array(
                'timeout' => 20,
                'headers' => array(
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer ' . $mcuap_olx_options['access_token'],
                    'Version'       => '2.0',
                ),
            )
        );
        if ( is_wp_error( $mcuap_olx_response ) || 200 !== (int) wp_remote_retrieve_response_code( $mcuap_olx_response ) ) {
            return array();
        }
        $mcuap_olx_json = json_decode( (string) wp_remote_retrieve_body( $mcuap_olx_response ), true );
        $mcuap_olx_rows = isset( $mcuap_olx_json['data'] ) && is_array( $mcuap_olx_json['data'] ) ? $mcuap_olx_json['data'] : array();
        $mcuap_olx_categories = array();
        foreach ( $mcuap_olx_rows as $mcuap_olx_row ) {
            if ( empty( $mcuap_olx_row['id'] ) || empty( $mcuap_olx_row['name'] ) ) {
                continue;
            }
            $mcuap_olx_categories[] = array(
                'id'   => absint( $mcuap_olx_row['id'] ),
                'name' => sanitize_text_field( (string) $mcuap_olx_row['name'] ),
            );
        }
        set_transient( 'mcuap_olx_ua_category_suggestions', $mcuap_olx_categories, DAY_IN_SECONDS );
        return $mcuap_olx_categories;
    }

    private function mcuap_olx_parse_attribute_lines( $mcuap_olx_raw ) {
        $mcuap_olx_attributes = array();
        foreach ( preg_split( '/\r\n|\r|\n/', (string) $mcuap_olx_raw ) as $mcuap_olx_line ) {
            $mcuap_olx_line = trim( $mcuap_olx_line );
            if ( '' === $mcuap_olx_line || false === strpos( $mcuap_olx_line, '=' ) ) {
                continue;
            }
            list( $mcuap_olx_code, $mcuap_olx_value ) = array_map( 'trim', explode( '=', $mcuap_olx_line, 2 ) );
            $mcuap_olx_code  = sanitize_key( $mcuap_olx_code );
            $mcuap_olx_value = sanitize_text_field( $mcuap_olx_value );
            if ( $mcuap_olx_code && '' !== $mcuap_olx_value ) {
                $mcuap_olx_attributes[] = array( 'code' => $mcuap_olx_code, 'value' => $mcuap_olx_value );
            }
        }
        return $this->mcuap_olx_dedupe_attributes( $mcuap_olx_attributes );
    }

    private function mcuap_olx_format_attribute_lines( array $mcuap_olx_attributes ) {
        $mcuap_olx_lines = array();
        foreach ( $mcuap_olx_attributes as $mcuap_olx_attribute ) {
            if ( ! empty( $mcuap_olx_attribute['code'] ) && isset( $mcuap_olx_attribute['value'] ) ) {
                $mcuap_olx_lines[] = sanitize_key( $mcuap_olx_attribute['code'] ) . '=' . sanitize_text_field( (string) $mcuap_olx_attribute['value'] );
            }
        }
        return implode( "\n", $mcuap_olx_lines );
    }

    private function mcuap_olx_dedupe_attributes( array $mcuap_olx_attributes ) {
        $mcuap_olx_seen = array();
        $mcuap_olx_clean = array();
        foreach ( $mcuap_olx_attributes as $mcuap_olx_attribute ) {
            if ( empty( $mcuap_olx_attribute['code'] ) || ! isset( $mcuap_olx_attribute['value'] ) ) {
                continue;
            }
            $mcuap_olx_code = sanitize_key( $mcuap_olx_attribute['code'] );
            if ( ! $mcuap_olx_code || isset( $mcuap_olx_seen[ $mcuap_olx_code ] ) ) {
                continue;
            }
            $mcuap_olx_seen[ $mcuap_olx_code ] = true;
            $mcuap_olx_clean[] = array( 'code' => $mcuap_olx_code, 'value' => sanitize_text_field( (string) $mcuap_olx_attribute['value'] ) );
        }
        return $mcuap_olx_clean;
    }
}
