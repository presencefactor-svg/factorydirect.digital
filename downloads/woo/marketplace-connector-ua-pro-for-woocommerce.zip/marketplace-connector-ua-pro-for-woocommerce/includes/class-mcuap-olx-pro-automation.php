<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCUAP_OLX_Pro_Automation {
    const MCUAP_OLX_CRON_HOOK = 'mcuap_olx_pro_cron_sync';

    private $mcuap_olx_settings;
    private $mcuap_olx_product_sync;

    public function __construct( MCUAP_OLX_Settings $mcuap_olx_settings, MCUAP_OLX_Product_Sync $mcuap_olx_product_sync ) {
        $this->mcuap_olx_settings     = $mcuap_olx_settings;
        $this->mcuap_olx_product_sync = $mcuap_olx_product_sync;

        add_filter( 'cron_schedules', array( $this, 'mcuap_olx_cron_schedules' ) );
        add_action( 'init', array( $this, 'mcuap_olx_maybe_schedule_cron' ) );
        add_action( self::MCUAP_OLX_CRON_HOOK, array( $this, 'mcuap_olx_run_cron_sync' ) );
        add_action( 'save_post_product', array( $this, 'mcuap_olx_auto_sync_on_save' ), 20, 2 );
        add_action( 'woocommerce_product_set_stock_status', array( $this, 'mcuap_olx_stock_status_sync' ), 20, 3 );
    }

    public function mcuap_olx_cron_schedules( $schedules ) {
        if ( ! isset( $schedules['mcuap_olx_hourly'] ) ) {
            $schedules['mcuap_olx_hourly'] = array(
                'interval' => HOUR_IN_SECONDS,
                'display'  => esc_html__( 'Marketplace Connector PRO hourly', 'marketplace-connector-ua-pro-for-woocommerce' ),
            );
        }
        return $schedules;
    }

    public function mcuap_olx_maybe_schedule_cron() {
        $options = $this->mcuap_olx_settings->mcuap_olx_get_options();
        $enabled = ! empty( $options['pro_cron_sync'] ) && '1' === $options['pro_cron_sync'];
        $next = wp_next_scheduled( self::MCUAP_OLX_CRON_HOOK );
        if ( $enabled && ! $next ) {
            wp_schedule_event( time() + 300, 'mcuap_olx_hourly', self::MCUAP_OLX_CRON_HOOK );
        } elseif ( ! $enabled && $next ) {
            wp_clear_scheduled_hook( self::MCUAP_OLX_CRON_HOOK );
        }
    }

    public function mcuap_olx_auto_sync_on_save( $post_id, $post ) {
        $options = $this->mcuap_olx_settings->mcuap_olx_get_options();
        if ( empty( $options['pro_auto_sync_on_save'] ) || '1' !== $options['pro_auto_sync_on_save'] ) {
            return;
        }
        if ( wp_is_post_revision( $post_id ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) {
            return;
        }
        if ( ! $post || 'publish' !== $post->post_status || ! current_user_can( 'edit_product', $post_id ) ) {
            return;
        }
        $this->mcuap_olx_product_sync->mcuap_olx_sync_product( absint( $post_id ) );
    }

    public function mcuap_olx_stock_status_sync( $product_id, $stock_status, $product ) {
        $options = $this->mcuap_olx_settings->mcuap_olx_get_options();
        if ( empty( $options['pro_stock_status_sync'] ) || '1' !== $options['pro_stock_status_sync'] ) {
            return;
        }
        $product_id = absint( $product_id );
        if ( ! $product_id || ! get_post_meta( $product_id, MCUAP_OLX_Product_Sync::MCUAP_OLX_ADVERT_ID_META, true ) ) {
            return;
        }
        $this->mcuap_olx_product_sync->mcuap_olx_sync_product( $product_id );
    }

    public function mcuap_olx_run_cron_sync() {
        $options = $this->mcuap_olx_settings->mcuap_olx_get_options();
        if ( empty( $options['pro_cron_sync'] ) || '1' !== $options['pro_cron_sync'] || ! function_exists( 'wc_get_products' ) ) {
            return;
        }
        $limit = ! empty( $options['pro_cron_limit'] ) ? absint( $options['pro_cron_limit'] ) : 20;
        $ids = wc_get_products( array(
            'status'     => 'publish',
            'limit'      => max( 1, min( 200, $limit ) ),
            'return'     => 'ids',
            'meta_key'   => MCUAP_OLX_Product_Sync::MCUAP_OLX_ADVERT_ID_META,
            'meta_compare' => 'EXISTS',
        ) );
        foreach ( array_map( 'absint', $ids ) as $product_id ) {
            $this->mcuap_olx_product_sync->mcuap_olx_sync_product( $product_id );
        }
    }
}
