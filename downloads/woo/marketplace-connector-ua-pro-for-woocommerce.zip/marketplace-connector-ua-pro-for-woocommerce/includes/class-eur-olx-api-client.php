<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCUAP_OLX_API_Client {
    private $mcuap_olx_settings;

    public function __construct( MCUAP_OLX_Settings $mcuap_olx_settings ) {
        $this->mcuap_olx_settings = $mcuap_olx_settings;
    }

    public function mcuap_olx_request( $mcuap_olx_method, $mcuap_olx_path, $mcuap_olx_body = null ) {
        $mcuap_olx_options = $this->mcuap_olx_settings->mcuap_olx_get_options();
        if ( ( empty( $mcuap_olx_options['access_token'] ) && ! empty( $mcuap_olx_options['refresh_token'] ) ) || ( ! empty( $mcuap_olx_options['token_expires_at'] ) && absint( $mcuap_olx_options['token_expires_at'] ) < time() + 120 ) ) {
            $mcuap_olx_refreshed = $this->mcuap_olx_refresh_access_token();
            if ( ! is_wp_error( $mcuap_olx_refreshed ) ) {
                $mcuap_olx_options = $this->mcuap_olx_settings->mcuap_olx_get_options();
            }
        }

        $mcuap_olx_market = $this->mcuap_olx_settings->mcuap_olx_get_market_config( $mcuap_olx_options['market'] );
        $mcuap_olx_token  = trim( (string) $mcuap_olx_options['access_token'] );

        if ( '' === $mcuap_olx_token ) {
            return new WP_Error( 'mcuap_olx_missing_token', esc_html__( 'Missing OAuth access token.', 'marketplace-connector-ua-pro-for-woocommerce' ) );
        }

        $mcuap_olx_url = trailingslashit( $mcuap_olx_market['base_url'] ) . ltrim( $mcuap_olx_path, '/' );
        $mcuap_olx_args = array(
            'method'  => strtoupper( sanitize_key( $mcuap_olx_method ) ),
            'timeout' => 45,
            'headers' => array(
                'Accept'        => 'application/json',
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $mcuap_olx_token,
                'Version'       => '2.0',
            ),
        );

        if ( null !== $mcuap_olx_body ) {
            $mcuap_olx_args['body'] = wp_json_encode( $mcuap_olx_body );
        }

        $mcuap_olx_args = apply_filters( 'mcuap_olx_api_request_args', $mcuap_olx_args, $mcuap_olx_path, $mcuap_olx_body );
        $mcuap_olx_response = wp_remote_request( esc_url_raw( $mcuap_olx_url ), $mcuap_olx_args );
        return $this->mcuap_olx_parse_response( $mcuap_olx_response );
    }

    public function mcuap_olx_post_v2_advert( array $mcuap_olx_payload ) {
        return $this->mcuap_olx_request( 'POST', '/adverts', $mcuap_olx_payload );
    }

    public function mcuap_olx_update_v2_advert( $mcuap_olx_advert_id, array $mcuap_olx_payload ) {
        return $this->mcuap_olx_request( 'PUT', '/adverts/' . absint( $mcuap_olx_advert_id ), $mcuap_olx_payload );
    }

    public function mcuap_olx_refresh_access_token() {
        $mcuap_olx_options = $this->mcuap_olx_settings->mcuap_olx_get_options();
        if ( empty( $mcuap_olx_options['client_id'] ) || empty( $mcuap_olx_options['client_secret'] ) || empty( $mcuap_olx_options['refresh_token'] ) ) {
            return new WP_Error( 'mcuap_olx_refresh_missing_credentials', esc_html__( 'Missing OAuth refresh credentials.', 'marketplace-connector-ua-pro-for-woocommerce' ) );
        }

        $mcuap_olx_market = $this->mcuap_olx_settings->mcuap_olx_get_market_config( $mcuap_olx_options['market'] );
        $mcuap_olx_response = wp_remote_post(
            esc_url_raw( $mcuap_olx_market['token_url'] ),
            array(
                'timeout' => 45,
                'headers' => array( 'Accept' => 'application/json' ),
                'body'    => array(
                    'grant_type'    => 'refresh_token',
                    'client_id'     => $mcuap_olx_options['client_id'],
                    'client_secret' => $mcuap_olx_options['client_secret'],
                    'refresh_token' => $mcuap_olx_options['refresh_token'],
                ),
            )
        );

        $mcuap_olx_json = $this->mcuap_olx_parse_response( $mcuap_olx_response );
        if ( is_wp_error( $mcuap_olx_json ) ) {
            return $mcuap_olx_json;
        }
        $this->mcuap_olx_settings->mcuap_olx_save_tokens_from_response( $mcuap_olx_json );
        return $mcuap_olx_json;
    }

    private function mcuap_olx_parse_response( $mcuap_olx_response ) {
        if ( is_wp_error( $mcuap_olx_response ) ) {
            return $mcuap_olx_response;
        }
        $mcuap_olx_code = (int) wp_remote_retrieve_response_code( $mcuap_olx_response );
        $mcuap_olx_raw  = (string) wp_remote_retrieve_body( $mcuap_olx_response );
        $mcuap_olx_json = json_decode( $mcuap_olx_raw, true );
        if ( $mcuap_olx_code < 200 || $mcuap_olx_code >= 300 ) {
            return new WP_Error(
                'mcuap_olx_api_error',
                sprintf(
                    /* translators: 1: HTTP status code, 2: response body */
                    esc_html__( 'OLX API error %1$d: %2$s', 'marketplace-connector-ua-pro-for-woocommerce' ),
                    $mcuap_olx_code,
                    is_array( $mcuap_olx_json ) ? wp_json_encode( $mcuap_olx_json ) : $mcuap_olx_raw
                )
            );
        }
        if ( is_array( $mcuap_olx_json ) && array_key_exists( 'data', $mcuap_olx_json ) ) {
            return is_array( $mcuap_olx_json['data'] ) ? $mcuap_olx_json['data'] : array( 'data' => $mcuap_olx_json['data'] );
        }
        return is_array( $mcuap_olx_json ) ? $mcuap_olx_json : array( 'raw' => $mcuap_olx_raw );
    }
}
