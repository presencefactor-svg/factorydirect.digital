<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class MCUAP_OLX_Plugin {
    private static $mcuap_olx_instance = null;

    private $mcuap_olx_settings;
    private $mcuap_olx_category_map;
    private $mcuap_olx_product_sync;

    public static function mcuap_olx_instance() {
        if ( null === self::$mcuap_olx_instance ) {
            self::$mcuap_olx_instance = new self();
        }
        return self::$mcuap_olx_instance;
    }

    private function __construct() {
        $this->mcuap_olx_settings     = new MCUAP_OLX_Settings();
        $this->mcuap_olx_category_map = new MCUAP_OLX_Category_Map();
        $this->mcuap_olx_product_sync = new MCUAP_OLX_Product_Sync( $this->mcuap_olx_settings, $this->mcuap_olx_category_map );

        add_action( 'admin_menu', array( $this, 'mcuap_olx_admin_menu' ) );
        add_action( 'admin_init', array( $this->mcuap_olx_settings, 'mcuap_olx_register_settings' ) );
        add_action( 'admin_init', array( $this->mcuap_olx_category_map, 'mcuap_olx_handle_category_map_save' ) );
        add_action( 'admin_post_mcuap_olx_oauth_start', array( $this->mcuap_olx_settings, 'mcuap_olx_handle_oauth_start' ) );
        add_action( 'admin_post_mcuap_olx_oauth_callback', array( $this->mcuap_olx_settings, 'mcuap_olx_handle_oauth_callback' ) );

        $this->mcuap_olx_product_sync->mcuap_olx_register_hooks();

        /**
         * Extension hook: keep this PRO plugin automation-ready; add automation in add-ons if needed.
         */
        do_action( 'mcuap_olx_lite_loaded', $this );
        new MCUAP_OLX_Pro_Automation( $this->mcuap_olx_settings, $this->mcuap_olx_product_sync );
    }

    public function mcuap_olx_admin_menu() {
        add_menu_page(
            esc_html__( 'Marketplace Connector UA PRO for WooCommerce', 'marketplace-connector-ua-pro-for-woocommerce' ),
            esc_html__( 'Marketplace Connector UA PRO for WooCommerce', 'marketplace-connector-ua-pro-for-woocommerce' ),
            'manage_woocommerce',
            'mcuap_olx-settings',
            array( $this->mcuap_olx_settings, 'mcuap_olx_render_settings_page' ),
            'dashicons-store',
            56
        );

        add_submenu_page(
            'mcuap_olx-settings',
            esc_html__( 'Category Mapping', 'marketplace-connector-ua-pro-for-woocommerce' ),
            esc_html__( 'Category Mapping', 'marketplace-connector-ua-pro-for-woocommerce' ),
            'manage_woocommerce',
            'mcuap_olx-category-map',
            array( $this->mcuap_olx_category_map, 'mcuap_olx_render_category_map_page' )
        );
    }

    public function mcuap_olx_get_product_sync() {
        return $this->mcuap_olx_product_sync;
    }

}
