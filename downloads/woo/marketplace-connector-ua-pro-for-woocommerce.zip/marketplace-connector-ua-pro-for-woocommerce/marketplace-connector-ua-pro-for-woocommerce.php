<?php
/**
 * Plugin Name: Marketplace Connector UA PRO for WooCommerce
 * Plugin URI: https://factorydirect.digital/woo/
 * Description: Automated and manual WooCommerce product synchronization with the OLX.ua Partner API v2 for Ukraine.
 * Version: 1.0.0
 * Author: Factory Direct Multimedia
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: marketplace-connector-ua-pro-for-woocommerce
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * WC requires at least: 7.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'MCUAP_OLX_PRO_VERSION', '1.0.0' );
define( 'MCUAP_OLX_LITE_FILE', __FILE__ );
define( 'MCUAP_OLX_LITE_PATH', plugin_dir_path( __FILE__ ) );
define( 'MCUAP_OLX_LITE_URL', plugin_dir_url( __FILE__ ) );
define( 'MCUAP_OLX_PRO', true );

require_once MCUAP_OLX_LITE_PATH . 'includes/class-eur-olx-api-client.php';
require_once MCUAP_OLX_LITE_PATH . 'includes/class-eur-olx-settings.php';
require_once MCUAP_OLX_LITE_PATH . 'includes/class-eur-olx-category-map.php';
require_once MCUAP_OLX_LITE_PATH . 'includes/class-eur-olx-product-sync.php';
require_once MCUAP_OLX_LITE_PATH . 'includes/class-eur-olx-plugin.php';
require_once MCUAP_OLX_LITE_PATH . 'includes/class-mcuap-olx-pro-automation.php';

/**
 * Bootstrap plugin. Global function is prefixed for WordPress.org compatibility.
 *
 * @return MCUAP_OLX_Plugin
 */
function mcuap_olx_lite() {
    return MCUAP_OLX_Plugin::mcuap_olx_instance();
}

add_action( 'plugins_loaded', 'mcuap_olx_lite' );
