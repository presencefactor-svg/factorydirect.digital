<?php
/**
 * Plugin Name: Marketplace Connector BA for WooCommerce
 * Plugin URI: https://factorydirect.digital/woo/
 * Description: Manual WooCommerce product synchronization with the OLX.ba marketplace API for Bosnia and Herzegovina, including category mapping, attributes, images, status actions and admin logs.
 * Version: 1.0.0
 * Author: Factory Direct Multimedia
 * Text Domain: marketplace-connector-ba-for-woocommerce
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if (!defined('ABSPATH')) exit;

// Custom connector tables are intentionally queried through $wpdb. All variable values are sanitized/prepared before use.
// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

final class FDMM_OLXBA_WC_Universal {
    const VERSION = '1.0.0';
    const OPT = 'fdmm_olxba_wc_options';
    const NONCE = 'fdmm_olxba_wc_nonce';

    const META_ID = '_fdmm_olx_listing_id';
    const META_SYNC = '_fdmm_olx_sync';
    const META_STATUS = '_fdmm_olx_status';
    const META_LAST = '_fdmm_olx_last_sync';
    const META_CAT = '_fdmm_olx_category_id';
    const META_COUNTRY = '_fdmm_olx_country_id';
    const META_CITY = '_fdmm_olx_city_id';
    const META_STATE = '_fdmm_olx_state';
    const META_PRICE_REQ = '_fdmm_olx_price_by_agreement';
    const META_ATTR_JSON = '_fdmm_olx_attributes_json';

    private static $inst = null;
    private $syncing = false;

    static function instance(){
        if (!self::$inst) self::$inst = new self();
        return self::$inst;
    }

    private function __construct(){
        add_action('admin_menu', [$this,'admin_menu']);
        add_action('admin_init', [$this,'register_settings']);
        add_action('add_meta_boxes', [$this,'metabox']);
        add_action('save_post_product', [$this,'save_product_meta'], 10, 2);
        add_action('admin_post_fdmm_olx_sync_product', [$this,'post_sync_product']);
        add_action('admin_post_fdmm_olx_upload_images', [$this,'post_upload_images']);
        add_action('admin_post_fdmm_olx_action', [$this,'post_action']);
        add_action('admin_post_fdmm_olx_generate_token', [$this,'post_generate_token']);
        add_filter('post_row_actions', [$this,'row_actions'], 10, 2);
        add_filter('manage_edit-product_columns', [$this,'product_columns']);
        add_action('manage_product_posts_custom_column', [$this,'product_column'], 10, 2);
        add_filter('bulk_actions-edit-product', [$this,'bulk_actions']);
        add_filter('handle_bulk_actions-edit-product', [$this,'handle_bulk'], 10, 3);
        add_action('restrict_manage_posts', [$this,'product_filter']);
        add_action('pre_get_posts', [$this,'apply_product_filter']);
    }

    static function activate(){
        self::instance()->install_tables();
    }

    private function table($name){
        global $wpdb;
        return $wpdb->prefix . 'fdmm_olx_' . $name;
    }

    private function install_tables(){
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$this->table('log')} (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            product_id bigint unsigned NULL,
            user_id bigint unsigned NULL,
            action varchar(80) NOT NULL,
            listing_id varchar(80) NULL,
            status varchar(30) NOT NULL DEFAULT 'info',
            message text NULL,
            payload longtext NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id), KEY product_id (product_id), KEY listing_id (listing_id), KEY created_at (created_at)
        ) $charset;");
        dbDelta("CREATE TABLE {$this->table('catmap')} (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            local_category_id bigint unsigned NOT NULL,
            local_category_name varchar(255) NULL,
            olx_category_id varchar(80) NOT NULL,
            olx_category_name varchar(255) NULL,
            state_used tinyint(1) NOT NULL DEFAULT 0,
            auto_refresh tinyint(1) NOT NULL DEFAULT 0,
            PRIMARY KEY (id), UNIQUE KEY local_category_id (local_category_id)
        ) $charset;");
        dbDelta("CREATE TABLE {$this->table('attrmap')} (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            local_category_id bigint unsigned NOT NULL DEFAULT 0,
            local_attribute_slug varchar(120) NOT NULL,
            olx_attribute_id varchar(80) NOT NULL,
            olx_attribute_name varchar(255) NULL,
            required tinyint(1) NOT NULL DEFAULT 0,
            value_map longtext NULL,
            PRIMARY KEY (id), KEY local_category_id (local_category_id)
        ) $charset;");
    }

    private function opts(){
        $o = wp_parse_args(get_option(self::OPT, []), [
            'api_base'=>'','username'=>'','password'=>'','token'=>'','client_id'=>'','client_token'=>'',
            'country_id'=>'','city_id'=>'','category_id'=>'','default_state'=>'new','shipping'=>'no_shipping',
            'title_prefix'=>'','olx_fixed_price'=>'','olx_desc_footer'=>'',
            'publish_after_create'=>'1','upload_images'=>'1','auto_update'=>'0','hide_if_out'=>'0','delete_if_out'=>'0',
            'truncate_title'=>'0','variations_individual'=>'0','universal_desc'=>'0','universal_desc_position'=>'after',
            'universal_desc_text'=>'','renew_expired'=>'0'
        ]);
        return $o;
    }

    function register_settings(){
        register_setting('fdmm_olxba_wc', self::OPT, [$this,'sanitize_opts']);
    }

    function sanitize_opts($in){
        $old = $this->opts();
        $out = [];
        foreach(['api_base','username','country_id','city_id','category_id','shipping','title_prefix','universal_desc_text','olx_desc_footer'] as $k){
            $out[$k] = isset($in[$k]) ? wp_kses_post(wp_unslash($in[$k])) : ($old[$k] ?? '');
        }
        $out['api_base'] = esc_url_raw($out['api_base']);
        $out['username'] = sanitize_text_field($out['username']);
        foreach(['country_id','city_id','category_id','shipping','title_prefix'] as $k) $out[$k] = sanitize_text_field($out[$k]);
        $price_raw = isset($in['olx_fixed_price']) ? str_replace(',', '.', sanitize_text_field(wp_unslash($in['olx_fixed_price']))) : ($old['olx_fixed_price'] ?? '');
        $out['olx_fixed_price'] = ($price_raw !== '' && is_numeric($price_raw) && (float)$price_raw >= 0) ? (string)(float)$price_raw : '';
        foreach(['password','token','client_id','client_token'] as $k){
            $posted = isset($in[$k]) ? sanitize_text_field(wp_unslash($in[$k])) : '';
            $out[$k] = $posted !== '' ? $posted : ($old[$k] ?? '');
        }
        $out['default_state'] = in_array(($in['default_state'] ?? 'new'), ['new','used'], true) ? $in['default_state'] : 'new';
        $out['universal_desc_position'] = in_array(($in['universal_desc_position'] ?? 'after'), ['overwrite','before','after'], true) ? $in['universal_desc_position'] : 'after';
        foreach(['publish_after_create','upload_images','auto_update','hide_if_out','delete_if_out','truncate_title','variations_individual','universal_desc','renew_expired'] as $k){
            $out[$k] = !empty($in[$k]) ? '1' : '0';
        }
        if (!empty($out['username']) && !empty($out['password']) && empty($out['token'])) {
            $login = $this->login($out);
            $token = is_wp_error($login) ? '' : $this->extract_token($login);
            if ($token) $out['token'] = $token;
            else add_settings_error('fdmm_olxba_wc','login_failed','OLX login nije uspio: '.(is_wp_error($login) ? $login->get_error_message() : 'token nije pronađen u odgovoru').'.', 'error');
        }
        return $out;
    }

    function admin_menu(){
        add_menu_page('Marketplace Connector BA','Marketplace Connector BA','manage_woocommerce','fdmm-olxba-wc',[$this,'dashboard'],'dashicons-store',56);
        add_submenu_page('fdmm-olxba-wc','Settings','Settings','manage_woocommerce','fdmm-olxba-wc-settings',[$this,'settings_page']);
        add_submenu_page('fdmm-olxba-wc','Category Mapping','Category Mapping','manage_woocommerce','fdmm-olxba-wc-catmap',[$this,'catmap_page']);
        add_submenu_page('fdmm-olxba-wc','Attribute Mapping','Attribute Mapping','manage_woocommerce','fdmm-olxba-wc-attrmap',[$this,'attrmap_page']);
        add_submenu_page('fdmm-olxba-wc','Activity log','Activity log','manage_woocommerce','fdmm-olxba-wc-log',[$this,'log_page']);
    }

    function dashboard(){
        if(!current_user_can('manage_woocommerce')) return;
        global $wpdb;
        $synced = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key=%s AND meta_value<>''", self::META_ID ) );
        echo '<div class="wrap"><h1>Marketplace Connector BA for WooCommerce</h1><table class="widefat striped"><tbody>';
        echo '<tr><td>Verzija</td><td>'.esc_html(self::VERSION).'</td></tr><tr><td>Autor</td><td>Factory Direct Multimedia</td></tr><tr><td>Sinhronizovanih artikala</td><td>'.esc_html($synced).'</td></tr></tbody></table>';
        echo '<p><a class="button button-primary" href="'.esc_url(admin_url('edit.php?post_type=product')).'">Otvori proizvode</a> <a class="button" href="'.esc_url(admin_url('admin.php?page=fdmm-olxba-wc-settings')).'">Postavke</a></p></div>';
    }

    function settings_page(){
        $o = $this->opts();
        $test = wp_nonce_url(admin_url('admin-post.php?action=fdmm_olx_action&do=test'), self::NONCE);
        ?>
        <div class="wrap"><h1>Marketplace Connector BA — Settings</h1>
        <div class="notice notice-info inline"><p><strong>Status:</strong> username <?php echo !empty($o['username']) ? 'OK' : 'nije sačuvan'; ?> | šifra <?php echo !empty($o['password']) ? 'sačuvana' : 'nije sačuvana'; ?> | Bearer token <?php echo !empty($o['token']) ? 'sačuvan' : 'nije sačuvan'; ?></p></div>
        <form method="post" action="options.php"><?php settings_fields('fdmm_olxba_wc'); ?>
        <h2>Pristupni podaci</h2><table class="form-table">
        <tr><th>API base</th><td><input class="regular-text" name="<?php echo esc_attr(self::OPT); ?>[api_base]" value="<?php echo esc_attr($o['api_base']);?>" placeholder="https://api.olx.ba"><p class="description">Može ostati prazno; plugin interno koristi https://api.olx.ba.</p></td></tr>
        <tr><th>OLX username / šifra</th><td><input name="<?php echo esc_attr(self::OPT); ?>[username]" value="<?php echo esc_attr($o['username']);?>" placeholder="OLX username"> <input type="password" name="<?php echo esc_attr(self::OPT); ?>[password]" value="" placeholder="OLX šifra"><p class="description">Prazna šifra/token ne briše prethodno sačuvanu vrijednost.</p></td></tr>
        <tr><th>Bearer token</th><td><input type="password" class="regular-text" name="<?php echo esc_attr(self::OPT); ?>[token]" value="" placeholder="Bearer token"></td></tr>
        <tr><th>Legacy client headers</th><td><input name="<?php echo esc_attr(self::OPT); ?>[client_id]" value="<?php echo esc_attr($o['client_id']);?>" placeholder="OLX-CLIENT-ID"> <input type="password" name="<?php echo esc_attr(self::OPT); ?>[client_token]" value="" placeholder="OLX-CLIENT-TOKEN"></td></tr></table>
        <h2>OLX podaci</h2><table class="form-table">
        <tr><th>Država / grad</th><td><input name="<?php echo esc_attr(self::OPT); ?>[country_id]" value="<?php echo esc_attr($o['country_id']);?>" placeholder="country_id"> <input name="<?php echo esc_attr(self::OPT); ?>[city_id]" value="<?php echo esc_attr($o['city_id']);?>" placeholder="city_id"></td></tr>
        <tr><th>Default OLX kategorija</th><td><input name="<?php echo esc_attr(self::OPT); ?>[category_id]" value="<?php echo esc_attr($o['category_id']);?>" placeholder="category_id"></td></tr>
        <tr><th>Default stanje</th><td><select name="<?php echo esc_attr(self::OPT); ?>[default_state]"><option value="new" <?php selected($o['default_state'],'new');?>>new</option><option value="used" <?php selected($o['default_state'],'used');?>>used</option></select></td></tr>
        <tr><th>OLX preambula naslova</th><td><input class="regular-text" name="<?php echo esc_attr(self::OPT); ?>[title_prefix]" value="<?php echo esc_attr($o['title_prefix']);?>" placeholder="npr. Novo"><p class="description">Opcionalno; dodaje se samo na OLX naslov.</p></td></tr>
        <tr><th>OLX fiksna cijena</th><td><input class="small-text" name="<?php echo esc_attr(self::OPT); ?>[olx_fixed_price]" value="<?php echo esc_attr($o['olx_fixed_price']);?>" placeholder=""><p class="description">Ako je prazno, koristi WooCommerce cijenu proizvoda. Ako je uneseno, šalje tu cijenu samo na OLX.</p></td></tr>
        <tr><th>OLX dodatak opisu</th><td><textarea class="large-text" rows="5" name="<?php echo esc_attr(self::OPT); ?>[olx_desc_footer]" placeholder="Tekst koji ide na kraj OLX opisa"><?php echo esc_textarea($o['olx_desc_footer']);?></textarea><p class="description">Ne mijenja opis na sajtu; dodaje se samo na OLX opis.</p></td></tr></table>
        <h2>Napredno</h2><table class="form-table"><tr><th>Sync</th><td><?php foreach(['publish_after_create'=>'Objavi poslije kreiranja','upload_images'=>'Sinhronizuj slike','auto_update'=>'Auto update na snimanje proizvoda','hide_if_out'=>'Sakrij ako nije na stanju','delete_if_out'=>'Obriši ako nije na stanju','truncate_title'=>'Skrati naziv na 65 karaktera','variations_individual'=>'Varijacije kao pojedinačni oglasi','renew_expired'=>'Auto obnovi istekle oglase'] as $k=>$lbl){ echo '<label><input type="checkbox" name="'.esc_attr(self::OPT.'['.$k.']').'" value="1" '.checked($o[$k],'1',false).'> '.esc_html($lbl).'</label><br>'; } ?></td></tr>
        <tr><th>Univerzalni opis</th><td><label><input type="checkbox" name="<?php echo esc_attr(self::OPT); ?>[universal_desc]" value="1" <?php checked($o['universal_desc'],'1');?>> koristi</label> <select name="<?php echo esc_attr(self::OPT); ?>[universal_desc_position]"><option value="overwrite" <?php selected($o['universal_desc_position'],'overwrite');?>>prepiši</option><option value="before" <?php selected($o['universal_desc_position'],'before');?>>prije</option><option value="after" <?php selected($o['universal_desc_position'],'after');?>>poslije</option></select><br><textarea class="large-text" rows="5" name="<?php echo esc_attr(self::OPT); ?>[universal_desc_text]"><?php echo esc_textarea($o['universal_desc_text']);?></textarea></td></tr></table>
        <?php submit_button('Sačuvaj'); ?></form>
        <hr><h2>Direktno generisanje tokena</h2><p>Ako “Testiraj /me” javlja da token nedostaje, koristi ovo. Forma direktno poziva OLX login i snima samo Bearer token.</p>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <?php wp_nonce_field(self::NONCE); ?><input type="hidden" name="action" value="fdmm_olx_generate_token">
            <input class="regular-text" name="api_base" value="<?php echo esc_attr($o['api_base']); ?>" placeholder="https://api.olx.ba">
            <input name="username" value="<?php echo esc_attr($o['username']); ?>" placeholder="OLX username">
            <input type="password" name="password" value="" placeholder="OLX šifra">
            <?php submit_button('Generiši / sačuvaj Bearer token', 'secondary', '', false); ?>
        </form>
        <p><a class="button" href="<?php echo esc_url($test); ?>">Testiraj /me</a></p></div>
        <?php
    }

    function catmap_page(){
        if(!current_user_can('manage_woocommerce')) return;
        global $wpdb;
        if(isset($_POST['fdmm_save_catmap'])){
            check_admin_referer(self::NONCE);
            $map_rows = [];
            if ( isset( $_POST['map'] ) && is_array( $_POST['map'] ) ) {
                // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- nested values are sanitized per field below.
                $map_rows = wp_unslash( $_POST['map'] );
            }
            foreach((array)$map_rows as $local=>$row){
                $local = absint($local); if(!$local) continue;
                $row = is_array($row) ? $row : [];
                $olx = sanitize_text_field($row['olx_category_id'] ?? '');
                if($olx==='') continue;
                $term = get_term($local,'product_cat');
                $wpdb->replace($this->table('catmap'),[
                    'local_category_id'=>$local,'local_category_name'=>$term && !is_wp_error($term) ? $term->name : '',
                    'olx_category_id'=>$olx,'olx_category_name'=>sanitize_text_field($row['olx_category_name'] ?? ''),
                    'state_used'=>!empty($row['state_used'])?1:0,'auto_refresh'=>!empty($row['auto_refresh'])?1:0
                ],['%d','%s','%s','%s','%d','%d']);
            }
            echo '<div class="updated"><p>Mapiranje kategorija sačuvano.</p></div>';
        }
        $terms = get_terms(['taxonomy'=>'product_cat','hide_empty'=>false]);
        echo '<div class="wrap"><h1>Mapiranje kategorija</h1><form method="post">'; wp_nonce_field(self::NONCE); echo '<input type="hidden" name="fdmm_save_catmap" value="1"><table class="widefat striped"><thead><tr><th>Woo kategorija</th><th>OLX category_id</th><th>OLX naziv</th><th>used</th><th>auto refresh</th></tr></thead><tbody>';
        foreach($terms as $t){
            $r = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table('catmap')} WHERE local_category_id=%d", $t->term_id), ARRAY_A);
            echo '<tr><td>'.esc_html($t->name).'</td><td><input name="map['.esc_attr((string)$t->term_id).'][olx_category_id]" value="'.esc_attr($r['olx_category_id'] ?? '').'"></td><td><input name="map['.esc_attr((string)$t->term_id).'][olx_category_name]" value="'.esc_attr($r['olx_category_name'] ?? '').'"></td><td><input type="checkbox" name="map['.esc_attr((string)$t->term_id).'][state_used]" value="1" '.checked(($r['state_used'] ?? 0),1,false).'></td><td><input type="checkbox" name="map['.esc_attr((string)$t->term_id).'][auto_refresh]" value="1" '.checked(($r['auto_refresh'] ?? 0),1,false).'></td></tr>';
        }
        echo '</tbody></table>'; submit_button('Sačuvaj mapiranje'); echo '</form></div>';
    }

    function attrmap_page(){
        if(!current_user_can('manage_woocommerce')) return;
        global $wpdb;
        if(isset($_POST['fdmm_add_attrmap'])){
            check_admin_referer(self::NONCE);
            $wpdb->insert($this->table('attrmap'),[
                'local_category_id'=>absint($_POST['local_category_id'] ?? 0),
                'local_attribute_slug'=>sanitize_text_field(wp_unslash($_POST['local_attribute_slug'] ?? '')),
                'olx_attribute_id'=>sanitize_text_field(wp_unslash($_POST['olx_attribute_id'] ?? '')),
                'olx_attribute_name'=>sanitize_text_field(wp_unslash($_POST['olx_attribute_name'] ?? '')),
                'required'=>!empty($_POST['required'])?1:0,
                'value_map'=>wp_kses_post(wp_unslash($_POST['value_map'] ?? ''))
            ],['%d','%s','%s','%s','%d','%s']);
            echo '<div class="updated"><p>Mapiranje atributa dodano.</p></div>';
        }
        if(isset($_GET['delete'])){ check_admin_referer(self::NONCE); $wpdb->delete($this->table('attrmap'),['id'=>absint($_GET['delete'])],['%d']); }
        $rows = $wpdb->get_results("SELECT * FROM {$this->table('attrmap')} ORDER BY local_category_id,id");
        $attrs = wc_get_attribute_taxonomies();
        echo '<div class="wrap"><h1>Mapiranje atributa</h1><form method="post">'; wp_nonce_field(self::NONCE); echo '<input type="hidden" name="fdmm_add_attrmap" value="1"><table class="form-table"><tr><th>Woo category ID</th><td><input name="local_category_id" placeholder="0 = sve / ručno"></td></tr><tr><th>Woo atribut</th><td><select name="local_attribute_slug"><option value="">Odaberi</option>';
        foreach($attrs as $a){ $tax = wc_attribute_taxonomy_name($a->attribute_name); echo '<option value="'.esc_attr($tax).'">'.esc_html($tax).'</option>'; }
        echo '</select></td></tr><tr><th>OLX attribute ID / naziv</th><td><input name="olx_attribute_id" placeholder="npr. 6928"> <input name="olx_attribute_name" placeholder="npr. Oblasti"> <label><input type="checkbox" name="required" value="1"> required</label></td></tr><tr><th>Value map</th><td><textarea name="value_map" class="large-text" rows="4" placeholder="OLX vrijednost = Woo vrijednost"></textarea></td></tr></table>'; submit_button('Dodaj mapiranje'); echo '</form><h2>Postojeća mapiranja</h2><table class="widefat striped"><thead><tr><th>ID</th><th>Woo cat</th><th>Woo atribut</th><th>OLX atribut</th><th>Required</th><th></th></tr></thead><tbody>';
        foreach($rows as $r){ echo '<tr><td>'.esc_html($r->id).'</td><td>'.esc_html($r->local_category_id).'</td><td>'.esc_html($r->local_attribute_slug).'</td><td>'.esc_html($r->olx_attribute_id.' '.$r->olx_attribute_name).'</td><td>'.esc_html($r->required).'</td><td><a href="'.esc_url(wp_nonce_url(add_query_arg(['delete'=>$r->id]), self::NONCE)).'">Obriši</a></td></tr>'; }
        echo '</tbody></table></div>';
    }

    function log_page(){
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$this->table('log')} ORDER BY id DESC LIMIT 300");
        echo '<div class="wrap"><h1>OLX Activity log</h1><table class="widefat striped"><thead><tr><th>Vrijeme</th><th>Product</th><th>OLX ID</th><th>Akcija</th><th>Status</th><th>Poruka</th></tr></thead><tbody>';
        foreach($rows as $r){ echo '<tr><td>'.esc_html($r->created_at).'</td><td>'.esc_html($r->product_id).'</td><td>'.esc_html($r->listing_id).'</td><td>'.esc_html($r->action).'</td><td>'.esc_html($r->status).'</td><td>'.esc_html($r->message).'</td></tr>'; }
        echo '</tbody></table></div>';
    }

    function metabox(){ add_meta_box('fdmm_olx_sync','OLX.ba Sync',[$this,'metabox_html'],'product','side'); }

    function metabox_html($post){
        wp_nonce_field(self::NONCE,'fdmm_olx_nonce');
        $o = $this->opts(); $id = get_post_meta($post->ID,self::META_ID,true);
        $cat = get_post_meta($post->ID,self::META_CAT,true) ?: $this->mapped_category_id($post->ID) ?: $o['category_id'];
        $sync_meta = get_post_meta($post->ID,self::META_SYNC,true); $sync_checked = ($sync_meta==='' || $sync_meta==='1') ? '1' : '0';
        echo '<p><label><input type="checkbox" name="fdmm_olx_enabled" value="1" '.checked($sync_checked,'1',false).'> Sync enabled</label></p>';
        foreach(['fdmm_olx_listing_id'=>'OLX listing ID','fdmm_olx_category_id'=>'OLX category ID','fdmm_olx_country_id'=>'Country ID','fdmm_olx_city_id'=>'City ID'] as $field=>$label){
            $meta=['fdmm_olx_listing_id'=>self::META_ID,'fdmm_olx_category_id'=>self::META_CAT,'fdmm_olx_country_id'=>self::META_COUNTRY,'fdmm_olx_city_id'=>self::META_CITY][$field];
            $val=$field==='fdmm_olx_category_id'?$cat:(get_post_meta($post->ID,$meta,true) ?: ($field==='fdmm_olx_country_id'?$o['country_id']:($field==='fdmm_olx_city_id'?$o['city_id']:'')));
            echo '<p><label>'.esc_html($label).'<br><input style="width:100%" name="'.esc_attr($field).'" value="'.esc_attr($val).'"></label></p>';
        }
        echo '<p><label>Stanje<br><select name="fdmm_olx_state" style="width:100%"><option value="new" '.selected(get_post_meta($post->ID,self::META_STATE,true) ?: $o['default_state'],'new',false).'>new</option><option value="used" '.selected(get_post_meta($post->ID,self::META_STATE,true) ?: $o['default_state'],'used',false).'>used</option></select></label></p>';
        echo '<p><label><input type="checkbox" name="fdmm_olx_price_by_agreement" value="1" '.checked(get_post_meta($post->ID,self::META_PRICE_REQ,true),'1',false).'> Cijena na upit</label></p>';
        echo '<p><label>Manual attributes JSON<br><textarea name="fdmm_olx_attributes_json" style="width:100%;height:70px">'.esc_textarea(get_post_meta($post->ID,self::META_ATTR_JSON,true)).'</textarea></label></p>';
        echo '<p><b>Status:</b> '.esc_html(get_post_meta($post->ID,self::META_STATUS,true)).'<br><b>Last:</b> '.esc_html(get_post_meta($post->ID,self::META_LAST,true)).'</p>';
        echo '<p><a class="button button-primary" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=fdmm_olx_sync_product&product_id='.$post->ID),self::NONCE)).'">Sync now</a></p>';
        if($id) echo '<p><a class="button button-secondary" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=fdmm_olx_upload_images&product_id='.$post->ID),self::NONCE)).'">Upload/Fix images</a></p>';
        if($id) foreach(['activate'=>'Aktiviraj','publish'=>'Objavi','refresh'=>'Obnovi','hide'=>'Sakrij','unhide'=>'Vrati','finish'=>'Završi','delete'=>'Obriši'] as $do=>$lbl) echo '<a class="button" style="margin:2px" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=fdmm_olx_action&do='.$do.'&product_id='.$post->ID),self::NONCE)).'">'.esc_html($lbl).'</a> ';
    }

    function save_product_meta($post_id,$post){
        if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if(!current_user_can('edit_product',$post_id)) return;
        if(isset($_POST['fdmm_olx_nonce']) && !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['fdmm_olx_nonce'])), self::NONCE)) return;
        $map=['fdmm_olx_listing_id'=>self::META_ID,'fdmm_olx_category_id'=>self::META_CAT,'fdmm_olx_country_id'=>self::META_COUNTRY,'fdmm_olx_city_id'=>self::META_CITY,'fdmm_olx_state'=>self::META_STATE,'fdmm_olx_attributes_json'=>self::META_ATTR_JSON];
        foreach($map as $f=>$m) if(isset($_POST[$f])) update_post_meta($post_id,$m,$f==='fdmm_olx_attributes_json'?wp_kses_post(wp_unslash($_POST[$f])):sanitize_text_field(wp_unslash($_POST[$f])));
        update_post_meta($post_id,self::META_SYNC,!empty($_POST['fdmm_olx_enabled'])?'1':'0');
        update_post_meta($post_id,self::META_PRICE_REQ,!empty($_POST['fdmm_olx_price_by_agreement'])?'1':'0');
        $o=$this->opts();
        if($o['auto_update']==='1' && !$this->syncing && get_post_status($post_id)==='publish') $this->sync_product($post_id,true);
    }

    private function mapped_category($product_id){
        global $wpdb;
        $terms = wp_get_post_terms($product_id,'product_cat');
        if(is_wp_error($terms)) return null;
        foreach($terms as $t){
            $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table('catmap')} WHERE local_category_id=%d",$t->term_id),ARRAY_A);
            if($r) return $r;
        }
        return null;
    }
    private function mapped_category_id($product_id){ $r=$this->mapped_category($product_id); return $r['olx_category_id']??''; }

    private function payload($product){
        $o=$this->opts(); $pid=$product->get_id(); $catmap=$this->mapped_category($pid);
        $title=wp_strip_all_tags($product->get_name());
        $title_prefix=trim((string)($o['title_prefix']??''));
        if($title_prefix!=='' && stripos($title,$title_prefix)!==0) $title=$title_prefix.' '.$title;
        if($o['truncate_title']==='1') $title=wp_html_excerpt($title,65,'');
        $desc=$product->get_description() ?: $product->get_short_description();
        if($o['universal_desc']==='1' && $o['universal_desc_text']!==''){
            if($o['universal_desc_position']==='overwrite') $desc=$o['universal_desc_text'];
            elseif($o['universal_desc_position']==='before') $desc=$o['universal_desc_text'].'<br><br>'.$desc;
            else $desc=$desc.'<br><br>'.$o['universal_desc_text'];
        }
        $footer=trim((string)($o['olx_desc_footer']??''));
        if($footer!==''){ $footer=nl2br($footer,false); $desc=trim((string)$desc)!=='' ? $desc.'<br><br>'.$footer : $footer; }
        $price=$product->get_regular_price() ?: $product->get_price();
        if(($o['olx_fixed_price']??'')!=='' && is_numeric($o['olx_fixed_price'])) $price=(float)$o['olx_fixed_price'];
        if(get_post_meta($pid,self::META_PRICE_REQ,true)==='1') $price=0;
        $data=['title'=>$title,'description'=>$desc,'short_description'=>wp_html_excerpt(wp_strip_all_tags($product->get_short_description() ?: $desc),250,''),'price'=>(float)$price,'available'=>$product->is_in_stock(),'quantity'=>$product->managing_stock()?(int)$product->get_stock_quantity():0,'listing_type'=>'sell','state'=>get_post_meta($pid,self::META_STATE,true) ?: (($catmap&&!empty($catmap['state_used']))?'used':$o['default_state']),'sku_number'=>$product->get_sku(),'price_by_agreement'=>get_post_meta($pid,self::META_PRICE_REQ,true)==='1'];
        foreach(['country_id'=>self::META_COUNTRY,'city_id'=>self::META_CITY,'category_id'=>self::META_CAT] as $k=>$m){
            $v=get_post_meta($pid,$m,true);
            if(!$v) $v=$k==='country_id'?$o['country_id']:($k==='city_id'?$o['city_id']:(($catmap['olx_category_id']??'') ?: $o['category_id']));
            if($v!=='') $data[$k]=is_numeric($v)?(int)$v:$v;
        }
        $attrs=$this->mapped_attrs($product);
        $manual=trim((string)get_post_meta($pid,self::META_ATTR_JSON,true));
        if($manual!==''){
            $j=json_decode($manual,true);
            if(json_last_error()===JSON_ERROR_NONE && is_array($j)) $attrs=array_merge($attrs,$j);
        }
        if($attrs || !empty($data['category_id'])) $data['attributes']=$attrs;
        return array_filter($data, function($v){ return $v!=='' && $v!==null; });
    }

    private function mapped_attrs($product){
        global $wpdb; $cat=$this->mapped_category($product->get_id());
        $cat_id=$cat['local_category_id']??0;
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->table('attrmap')} WHERE local_category_id IN (0,%d)",$cat_id));
        $out=[];
        foreach($rows as $r){
            if(!$r->local_attribute_slug || !taxonomy_exists($r->local_attribute_slug)) continue;
            $terms=wp_get_post_terms($product->get_id(),$r->local_attribute_slug);
            if(!$terms||is_wp_error($terms)) continue;
            $term=end($terms); $value=$term->name; $map=$this->parse_value_map($r->value_map);
            if(isset($map[$value])) $value=$map[$value]; elseif(isset($map[$term->slug])) $value=$map[$term->slug];
            $out[]=['id'=>is_numeric($r->olx_attribute_id)?(int)$r->olx_attribute_id:$r->olx_attribute_id,'value'=>$value];
        }
        return $out;
    }
    private function parse_value_map($txt){
        $m=[]; foreach(preg_split('/\r?\n/',(string)$txt) as $line){ if(strpos($line,'=')!==false){ [$a,$b]=array_map('trim',explode('=',$line,2)); if($a!=='') $m[$a]=$b; } }
        return $m;
    }

    function sync_product($product_id,$force=false){
        if($this->syncing) return new WP_Error('busy','Sync već radi');
        if(!function_exists('wc_get_product')) return new WP_Error('wc','WooCommerce nije aktivan');
        $product=wc_get_product($product_id); if(!$product) return new WP_Error('product','Proizvod ne postoji');
        if(!$force && get_post_meta($product_id,self::META_SYNC,true)!=='1' && !get_post_meta($product_id,self::META_ID,true)) return new WP_Error('disabled','Sync nije omogućen za proizvod');
        $this->syncing=true;
        $listing=get_post_meta($product_id,self::META_ID,true); $data=$this->payload($product);
        $res=$listing?$this->api('PUT','/listings/'.rawurlencode($listing),$data):$this->api('POST','/listings',$data);
        $this->syncing=false;
        if(is_wp_error($res)){ update_post_meta($product_id,self::META_STATUS,'ERROR: '.$res->get_error_message()); update_post_meta($product_id,self::META_LAST,current_time('mysql')); $this->log($product_id,'sync_error',$listing,'error',$res->get_error_message(),$data); return $res; }
        $new=$res['id']??($res['data']['id']??$listing); if($new) update_post_meta($product_id,self::META_ID,$new);
        $status=$this->normalize_listing_status($res,$res['status']??($res['data']['status']??'synced'));
        update_post_meta($product_id,self::META_STATUS,$status); update_post_meta($product_id,self::META_LAST,current_time('mysql')); update_post_meta($product_id,self::META_SYNC,'1');
        $this->log($product_id,$listing?'update':'create',$new,'ok','OK',$data);
        $o=$this->opts();
        if($new && $o['upload_images']==='1') $this->upload_images_if_missing($product,$new);
        if(!$listing && $new && $o['publish_after_create']==='1'){
            $pub=$this->listing_action($product_id,'publish'); if(!is_wp_error($pub)) $status='published';
        }
        if($new){
            $status=$this->refresh_listing_status($product_id,$new,$status);
            if($o['publish_after_create']==='1' && in_array(strtolower((string)$status), ['inactive','draft','hidden','unpublished'], true)){
                $act=$this->activate_listing($product_id,$new); if(!is_wp_error($act)) $this->refresh_listing_status($product_id,$new,'published');
            }
        }
        return $new;
    }

    private function normalize_listing_status($r,$fallback='synced'){
        $item=(is_array($r) && isset($r['data']) && is_array($r['data'])) ? $r['data'] : $r;
        if(!is_array($item)) return $fallback;
        $status=!empty($item['status']) ? sanitize_text_field((string)$item['status']) : $fallback;
        if(array_key_exists('visible',$item)) return $item['visible'] ? 'published' : ($status ?: 'hidden');
        if(array_key_exists('active',$item)) return $item['active'] ? 'published' : ($status ?: 'hidden');
        return $status ?: $fallback;
    }

    private function refresh_listing_status($product_id,$listing,$fallback='synced'){
        $r=$this->api('GET','/listings/'.rawurlencode($listing));
        if(is_wp_error($r)){ $this->log($product_id,'status_check',$listing,'error',$r->get_error_message()); if($fallback) update_post_meta($product_id,self::META_STATUS,$fallback); return $fallback; }
        $status=$this->normalize_listing_status($r,$fallback);
        update_post_meta($product_id,self::META_STATUS,$status); update_post_meta($product_id,self::META_LAST,current_time('mysql'));
        $this->log($product_id,'status_check',$listing,'ok','Status: '.$status); return $status;
    }

    private function normalize_image_url($url){
        $url=(string)$url; if($url==='') return '';
        $p=wp_parse_url($url); if(!$p || empty($p['scheme']) || empty($p['host']) || empty($p['path'])) return esc_url_raw($url);
        $path=implode('/', array_map(function($seg){ return rawurlencode(rawurldecode($seg)); }, explode('/', $p['path'])));
        $out=$p['scheme'].'://'.$p['host']; if(!empty($p['port'])) $out.=':'.$p['port']; $out.=$path;
        if(isset($p['query'])) $out.='?'.$p['query']; if(isset($p['fragment'])) $out.='#'.$p['fragment'];
        return esc_url_raw($out);
    }

    private function listing_images_count($listing){
        $r=$this->api('GET','/listings/'.rawurlencode($listing).'/images'); if(is_wp_error($r)) return $r;
        $items=$r['data']??$r; return is_array($items) ? count($items) : 0;
    }

    private function upload_images_if_missing($product,$listing){
        $count=$this->listing_images_count($listing);
        if(is_wp_error($count)){ $this->log($product->get_id(),'images_check',$listing,'error',$count->get_error_message()); return; }
        if((int)$count>0){ $this->log($product->get_id(),'images_check',$listing,'ok','OLX listing already has '.$count.' image(s)'); return; }
        $this->upload_images($product,$listing);
    }

    private function upload_images($product,$listing){
        $ids=array_filter(array_unique(array_merge([$product->get_image_id()],$product->get_gallery_image_ids())));
        if(!$ids){ $this->log($product->get_id(),'images',$listing,'error','WooCommerce product has no featured/gallery images'); return; }
        $uploaded=0; $failed=0; $payloads=[];
        foreach(array_slice($ids,0,10) as $i){
            $raw_url=wp_get_attachment_url($i); if(!$raw_url) continue;
            $url=$this->normalize_image_url($raw_url); if(!$url) continue;
            $payload=['image_url'=>$url]; if($raw_url!==$url) $payload['original_url']=$raw_url; $payloads[]=$payload;
            $r=$this->api('POST','/listings/'.rawurlencode($listing).'/image-upload',['image_url'=>$url]);
            is_wp_error($r) ? $failed++ : $uploaded++;
            $this->log($product->get_id(),'image_upload',$listing,is_wp_error($r)?'error':'ok',is_wp_error($r)?$r->get_error_message():'Image uploaded: '.$url,$payload);
        }
        $after=$this->listing_images_count($listing);
        $after_msg=is_wp_error($after) ? 'count check failed: '.$after->get_error_message() : 'OLX images after upload: '.$after;
        $this->log($product->get_id(),'images',$listing,($failed || (!is_wp_error($after) && (int)$after===0))?'error':'ok','Uploaded '.$uploaded.' image(s), failed '.$failed.'. '.$after_msg,$payloads);
    }

    private function activate_listing($product_id,$listing=null){
        $listing=$listing ?: get_post_meta($product_id,self::META_ID,true); if(!$listing) return new WP_Error('noid','Nema OLX listing ID');
        $r=$this->listing_action($product_id,'publish');
        if(!is_wp_error($r)){ update_post_meta($product_id,self::META_STATUS,'published'); $this->log($product_id,'activate',$listing,'ok','Activated with publish'); return $r; }
        $first=$r->get_error_message(); $r2=$this->listing_action($product_id,'unhide');
        if(!is_wp_error($r2)){ update_post_meta($product_id,self::META_STATUS,'published'); $this->log($product_id,'activate',$listing,'ok','Activated with unhide after publish failed: '.$first); return $r2; }
        $this->listing_action($product_id,'refresh'); $msg='Publish failed: '.$first.' | Unhide failed: '.$r2->get_error_message(); $this->log($product_id,'activate',$listing,'error',$msg); return new WP_Error('activate_failed',$msg);
    }

    private function listing_action($product_id,$do){
        $listing=get_post_meta($product_id,self::META_ID,true); if(!$listing) return new WP_Error('noid','Nema OLX listing ID');
        if($do==='activate') return $this->activate_listing($product_id,$listing);
        $paths=['publish'=>['POST','/publish'],'refresh'=>['PUT','/refresh'],'hide'=>['POST','/hide'],'unhide'=>['POST','/unhide'],'finish'=>['POST','/finish'],'delete'=>['DELETE','']];
        if(!isset($paths[$do])) return new WP_Error('bad','Nepoznata akcija');
        [$m,$suffix]=$paths[$do]; $r=$this->api($m,'/listings/'.rawurlencode($listing).$suffix);
        if(!is_wp_error($r)){
            if($do==='delete'){ delete_post_meta($product_id,self::META_ID); update_post_meta($product_id,self::META_STATUS,'deleted'); }
            elseif(in_array($do,['publish','unhide'],true)) update_post_meta($product_id,self::META_STATUS,'published');
            elseif($do==='hide') update_post_meta($product_id,self::META_STATUS,'hidden');
            elseif($do==='finish') update_post_meta($product_id,self::META_STATUS,'finished');
            elseif($do==='refresh') $this->refresh_listing_status($product_id,$listing,'refreshed');
            update_post_meta($product_id,self::META_LAST,current_time('mysql'));
        }
        $this->log($product_id,$do,$listing,is_wp_error($r)?'error':'ok',is_wp_error($r)?$r->get_error_message():'OK'); return $r;
    }

    private function extract_token($login){
        if(!is_array($login)) return '';
        foreach(['token','access_token','bearer_token'] as $k) if(!empty($login[$k])) return sanitize_text_field($login[$k]);
        foreach(['data','result','response'] as $wrap) if(!empty($login[$wrap]) && is_array($login[$wrap])) foreach(['token','access_token','bearer_token'] as $k) if(!empty($login[$wrap][$k])) return sanitize_text_field($login[$wrap][$k]);
        return '';
    }

    private function login($override=null){
        $o=$override ?: $this->opts(); if(empty($o['username']) || empty($o['password'])) return new WP_Error('auth','Nedostaje OLX username ili šifra');
        $url=rtrim($o['api_base'] ?: 'https://api.olx.ba','/').'/auth/login';
        $payload=['username'=>$o['username'],'password'=>$o['password'],'device_name'=>'fdmm_olxba_wc_universal'];
        $res=wp_remote_post($url,['headers'=>['Accept'=>'application/json'],'timeout'=>45,'body'=>$payload]);
        if(is_wp_error($res)) return $res;
        $code=wp_remote_retrieve_response_code($res); $raw=wp_remote_retrieve_body($res); $json=json_decode($raw,true);
        if($code>=200 && $code<300 && is_array($json)) return $json;
        $res=wp_remote_post($url,['headers'=>['Accept'=>'application/json','Content-Type'=>'application/json'],'timeout'=>45,'body'=>wp_json_encode($payload)]);
        if(is_wp_error($res)) return $res;
        $code=wp_remote_retrieve_response_code($res); $raw=wp_remote_retrieve_body($res); $json=json_decode($raw,true);
        if($code<200 || $code>=300) return new WP_Error('http_'.$code,'OLX login HTTP '.$code.': '.($json?wp_json_encode($json):$raw));
        return is_array($json)?$json:['raw'=>$raw];
    }

    private function api($method,$path,$body=null,$auth=true,$override=null){
        $o=$override ?: $this->opts(); $headers=['Accept'=>'application/json','Content-Type'=>'application/json'];
        if($auth){
            if(empty($o['token']) && !empty($o['username']) && !empty($o['password'])){
                $login=$this->login($o); $token=is_wp_error($login) ? '' : $this->extract_token($login);
                if($token){ $o['token']=$token; if(!$override) update_option(self::OPT, $o); }
            }
            if(!empty($o['token'])) $headers['Authorization']='Bearer '.$o['token'];
            elseif(!empty($o['client_id'])&&!empty($o['client_token'])){ $headers['OLX-CLIENT-ID']=$o['client_id']; $headers['OLX-CLIENT-TOKEN']=$o['client_token']; }
            else return new WP_Error('auth','Nedostaje OLX token. Sačuvaj postavke sa username/šifrom ili ručno unesi Bearer token.');
        }
        $args=['method'=>$method,'headers'=>$headers,'timeout'=>45]; if($body!==null) $args['body']=wp_json_encode($body);
        $res=wp_remote_request(rtrim($o['api_base'] ?: 'https://api.olx.ba','/').$path,$args);
        if(is_wp_error($res)) return $res;
        $code=wp_remote_retrieve_response_code($res); $raw=wp_remote_retrieve_body($res); $json=json_decode($raw,true);
        if($code<200||$code>=300) return new WP_Error('http_'.$code,'OLX API HTTP '.$code.': '.($json?wp_json_encode($json):$raw));
        return is_array($json)?$json:['raw'=>$raw];
    }

    private function log($pid,$action,$listing='',$status='info',$msg='',$payload=null){
        global $wpdb;
        $wpdb->insert($this->table('log'),['product_id'=>$pid?:null,'user_id'=>get_current_user_id()?:null,'action'=>$action,'listing_id'=>$listing,'status'=>$status,'message'=>$msg,'payload'=>$payload?wp_json_encode($payload):null,'created_at'=>current_time('mysql')],['%d','%d','%s','%s','%s','%s','%s','%s']);
    }

    function post_sync_product(){
        if(!current_user_can('manage_woocommerce')) wp_die('No'); check_admin_referer(self::NONCE);
        $pid=absint($_GET['product_id']??0); $r=$this->sync_product($pid,true);
        wp_safe_redirect(add_query_arg(is_wp_error($r)?['olxba_error'=>rawurlencode($r->get_error_message())]:['olxba_msg'=>rawurlencode('Sync OK: '.$r)], get_edit_post_link($pid,'url'))); exit;
    }

    function post_upload_images(){
        if(!current_user_can('manage_woocommerce')) wp_die('No'); check_admin_referer(self::NONCE);
        $pid=absint($_GET['product_id']??0); $product=wc_get_product($pid); $listing=get_post_meta($pid,self::META_ID,true);
        if(!$product || !$listing){ wp_safe_redirect(add_query_arg(['olxba_error'=>rawurlencode('Nema proizvoda ili OLX listing ID')], get_edit_post_link($pid,'url'))); exit; }
        $this->upload_images_if_missing($product,$listing); $count=$this->listing_images_count($listing);
        wp_safe_redirect(add_query_arg(is_wp_error($count)?['olxba_error'=>rawurlencode($count->get_error_message())]:['olxba_msg'=>rawurlencode('OLX images count: '.$count)], get_edit_post_link($pid,'url'))); exit;
    }

    function post_generate_token(){
        if(!current_user_can('manage_woocommerce')) wp_die('No'); check_admin_referer(self::NONCE);
        $o=$this->opts(); $o['api_base']=esc_url_raw(wp_unslash($_POST['api_base'] ?? $o['api_base'])); $o['username']=sanitize_text_field(wp_unslash($_POST['username'] ?? '')); $o['password']=sanitize_text_field(wp_unslash($_POST['password'] ?? ''));
        $login=$this->login($o); $token=is_wp_error($login) ? '' : $this->extract_token($login);
        if($token){ $save=$this->opts(); $save['api_base']=$o['api_base']; $save['username']=$o['username']; $save['token']=$token; update_option(self::OPT, $save); wp_safe_redirect(add_query_arg(['olxba_msg'=>rawurlencode('Bearer token generisan i sačuvan. Sada klikni Testiraj /me.')], admin_url('admin.php?page=fdmm-olxba-wc-settings'))); exit; }
        wp_safe_redirect(add_query_arg(['olxba_error'=>rawurlencode(is_wp_error($login) ? $login->get_error_message() : 'OLX login nije vratio token')], admin_url('admin.php?page=fdmm-olxba-wc-settings'))); exit;
    }

    function post_action(){
        if(!current_user_can('manage_woocommerce')) wp_die('No'); check_admin_referer(self::NONCE);
        $do=sanitize_key($_GET['do']??'');
        if($do==='test'){ $r=$this->api('GET','/me'); wp_safe_redirect(add_query_arg(is_wp_error($r)?['olxba_error'=>rawurlencode($r->get_error_message())]:['olxba_msg'=>rawurlencode('Konekcija OK')], admin_url('admin.php?page=fdmm-olxba-wc-settings'))); exit; }
        $pid=absint($_GET['product_id']??0); $r=$this->listing_action($pid,$do);
        wp_safe_redirect(add_query_arg(is_wp_error($r)?['olxba_error'=>rawurlencode($r->get_error_message())]:['olxba_msg'=>rawurlencode('OLX akcija OK: '.$do)], get_edit_post_link($pid,'url'))); exit;
    }

    function row_actions($a,$post){ if($post->post_type==='product'&&current_user_can('edit_product',$post->ID)) $a['fdmm_olx_sync']='<a href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=fdmm_olx_sync_product&product_id='.$post->ID),self::NONCE)).'">OLX sync</a>'; return $a; }
    function product_columns($c){ $c['fdmm_olx']='OLX'; return $c; }
    function product_column($col,$id){ if($col==='fdmm_olx'){ $lid=get_post_meta($id,self::META_ID,true); echo $lid?'<b>ID:</b> '.esc_html($lid).'<br>':''; echo esc_html(get_post_meta($id,self::META_STATUS,true)); } }
    function bulk_actions($a){ $a['fdmm_olx_sync']='OLX.ba sync'; $a['fdmm_olx_activate']='OLX.ba activate'; $a['fdmm_olx_hide']='OLX.ba hide'; $a['fdmm_olx_refresh']='OLX.ba refresh'; return $a; }
    function handle_bulk($redir,$action,$ids){ if(!in_array($action,['fdmm_olx_sync','fdmm_olx_activate','fdmm_olx_hide','fdmm_olx_refresh'],true)) return $redir; $ok=0;$fail=0; foreach($ids as $id){ if($action==='fdmm_olx_sync') $r=$this->sync_product($id,true); elseif($action==='fdmm_olx_activate') $r=$this->activate_listing($id); else $r=$this->listing_action($id,$action==='fdmm_olx_hide'?'hide':'refresh'); is_wp_error($r)?$fail++:$ok++; } return add_query_arg(['olxba_ok'=>$ok,'olxba_fail'=>$fail],$redir); }
    function product_filter(){
        global $typenow;
        if($typenow==='product'){
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only admin list filter.
            $v = isset($_GET['fdmm_olx_filter']) ? sanitize_text_field(wp_unslash($_GET['fdmm_olx_filter'])) : '';
            echo '<select name="fdmm_olx_filter"><option value="">OLX status</option><option value="synced" '.selected($v,'synced',false).'>Synced</option><option value="not_synced" '.selected($v,'not_synced',false).'>Not synced</option><option value="error" '.selected($v,'error',false).'>Error</option><option value="inactive" '.selected($v,'inactive',false).'>Inactive</option></select>';
        }
    }
    function apply_product_filter($q){
        if(!is_admin()||!$q->is_main_query()||$q->get('post_type')!=='product') return;
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only admin list filter.
        $v = isset($_GET['fdmm_olx_filter']) ? sanitize_text_field(wp_unslash($_GET['fdmm_olx_filter'])) : '';
        if($v==='synced') $q->set('meta_query',[['key'=>self::META_ID,'compare'=>'EXISTS']]);
        if($v==='not_synced') $q->set('meta_query',[['key'=>self::META_ID,'compare'=>'NOT EXISTS']]);
        if($v==='error') $q->set('meta_query',[['key'=>self::META_STATUS,'value'=>'ERROR','compare'=>'LIKE']]);
        if($v==='inactive') $q->set('meta_query',[['key'=>self::META_STATUS,'value'=>'inactive','compare'=>'LIKE']]);
    }
}

register_activation_hook(__FILE__, ['FDMM_OLXBA_WC_Universal','activate']);
add_action('plugins_loaded', function(){ FDMM_OLXBA_WC_Universal::instance(); });
