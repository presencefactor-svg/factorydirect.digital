=== Marketplace Connector BA for WooCommerce ===
Contributors: factorydirectmultimedia
Tags: woocommerce, marketplace, olx, product sync, ecommerce
Requires at least: 6.0
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Manual WooCommerce product synchronization with the OLX.ba marketplace API for Bosnia and Herzegovina.

== Description ==

Marketplace Connector BA for WooCommerce helps store administrators prepare and manually synchronize WooCommerce product data with the OLX.ba marketplace.

The free plugin is built for controlled, administrator-driven workflows. It can store marketplace API credentials, generate or save a Bearer token, map WooCommerce categories to OLX.ba category IDs, map WooCommerce product attributes to marketplace attributes, send listing data, upload public image URLs, publish or hide listings, refresh status, and keep an activity log in WordPress admin.

Main features:

* Manual product sync from WooCommerce product screens and product list actions.
* Category mapping from WooCommerce product categories to marketplace category IDs.
* Attribute mapping, including required marketplace attributes and value mapping.
* Product-level metabox for listing ID, category, country, city, condition/state, price-on-request and manual attributes JSON.
* Bulk actions for sync, activate, hide and refresh status.
* Public image URL upload with URL path encoding for safer media handling.
* Activity log for API requests, responses and admin actions.
* Write-only password/token fields so empty saves do not erase existing credentials.

This plugin is an independent connector. It is not affiliated with, endorsed by, or sponsored by OLX.ba, OLX Group, WooCommerce, or Automattic.

== Installation ==

1. Upload the plugin ZIP through WordPress Admin > Plugins > Add New > Upload Plugin, or install it from the WordPress Plugin Directory when available.
2. Activate WooCommerce first, then activate Marketplace Connector BA for WooCommerce.
3. Open Marketplace Connector BA > Settings.
4. Enter your OLX.ba API credentials or a valid Bearer token.
5. Use Test /me to verify the connection.
6. Configure country, city, default category, category mapping and attribute mapping.
7. Test one real product manually before running any bulk action.

== Frequently Asked Questions ==

= Does this plugin publish products automatically? =

The free plugin is designed for manual, controlled synchronization. Administrators choose when to sync, activate, hide or refresh products.

= Does the plugin include OLX.ba credentials? =

No. All account-specific fields are blank by default. Administrators must enter their own credentials or token in WordPress admin.

= Can it update an existing listing instead of creating duplicates? =

Yes. If a product already has a saved marketplace listing ID, the plugin updates that listing instead of creating a new one.

= Why did my sync fail with a required attribute error? =

Some marketplace categories require specific attributes. Add the missing value in the product data, product metabox, or attribute mapping, then retry sync.

= Can local images be uploaded? =

The marketplace must be able to fetch image URLs publicly. Localhost, private network and blocked URLs will not work reliably.

== Screenshots ==

1. Settings and API connection screen.
2. Category mapping screen.
3. Attribute mapping screen.
4. Product metabox and manual sync actions.
5. Activity log screen.

== External Services ==

This plugin connects to the OLX.ba marketplace API when an authorized administrator saves credentials, generates a token, tests the account endpoint, synchronizes a product, uploads product images, publishes/hides a listing, or refreshes listing status.

Service endpoint:

* `https://api.olx.ba`

Data sent to the service may include marketplace username/password for token generation, Bearer token or legacy client headers, WooCommerce product title, description, price, category ID, country ID, city ID, condition/state, shipping option, product attributes, listing ID, stock/status intent, and public product image URLs.

Data is sent only when an administrator configures the connector or manually runs a marketplace action. The free plugin does not send product data automatically by default.

Please review the OLX.ba terms and privacy information before connecting your store account:

* https://olx.ba

== Privacy ==

The plugin stores configuration, marketplace tokens, listing IDs, mapping data and activity logs in the WordPress database. It does not send data to Factory Direct Multimedia. Product and account data is sent to the marketplace API only for administrator-requested connector actions.

== Security ==

Only users with WooCommerce management permissions can access connector settings and actions. Password and token fields are write-only in the settings form: leaving them empty keeps the previously saved value.

== Uninstall ==

Deleting the plugin removes only plugin files. Marketplace listings and WooCommerce products are not deleted. Before uninstalling, export or record any mapping/listing data you still need.

== Changelog ==

= 1.0.0 =
* Initial WordPress.org-ready BA connector package.
* Manual WooCommerce product sync with OLX.ba API.
* Category mapping, attribute mapping, product metabox, status actions and activity log.
* Neutral plugin name and no bundled credentials.

== Upgrade Notice ==

= 1.0.0 =
Initial public package for controlled WooCommerce to OLX.ba marketplace synchronization.
