<?php
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }
// Marketplace listings and WooCommerce product data are intentionally left untouched.
