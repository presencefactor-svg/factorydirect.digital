<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCRO_OLX_API_Client {
    private $mcro_olx_settings;

    public function __construct( MCRO_OLX_Settings $mcro_olx_settings ) {
        $this->mcro_olx_settings = $mcro_olx_settings;
    }

    public function mcro_olx_request( $mcro_olx_method, $mcro_olx_path, $mcro_olx_body = null ) {
        $mcro_olx_options = $this->mcro_olx_settings->mcro_olx_get_options();
        if ( ( empty( $mcro_olx_options['access_token'] ) && ! empty( $mcro_olx_options['refresh_token'] ) ) || ( ! empty( $mcro_olx_options['token_expires_at'] ) && absint( $mcro_olx_options['token_expires_at'] ) < time() + 120 ) ) {
            $mcro_olx_refreshed = $this->mcro_olx_refresh_access_token();
            if ( ! is_wp_error( $mcro_olx_refreshed ) ) {
                $mcro_olx_options = $this->mcro_olx_settings->mcro_olx_get_options();
            }
        }

        $mcro_olx_market = $this->mcro_olx_settings->mcro_olx_get_market_config( $mcro_olx_options['market'] );
        $mcro_olx_token  = trim( (string) $mcro_olx_options['access_token'] );

        if ( '' === $mcro_olx_token ) {
            return new WP_Error( 'mcro_olx_missing_token', esc_html__( 'Missing OAuth access token.', 'marketplace-connector-ro-for-woocommerce' ) );
        }

        $mcro_olx_url = trailingslashit( $mcro_olx_market['base_url'] ) . ltrim( $mcro_olx_path, '/' );
        $mcro_olx_args = array(
            'method'  => strtoupper( sanitize_key( $mcro_olx_method ) ),
            'timeout' => 45,
            'headers' => array(
                'Accept'        => 'application/json',
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $mcro_olx_token,
                'Version'       => '2.0',
            ),
        );

        if ( null !== $mcro_olx_body ) {
            $mcro_olx_args['body'] = wp_json_encode( $mcro_olx_body );
        }

        $mcro_olx_args = apply_filters( 'mcro_olx_api_request_args', $mcro_olx_args, $mcro_olx_path, $mcro_olx_body );
        $mcro_olx_response = wp_remote_request( esc_url_raw( $mcro_olx_url ), $mcro_olx_args );
        return $this->mcro_olx_parse_response( $mcro_olx_response );
    }

    public function mcro_olx_post_v2_advert( array $mcro_olx_payload ) {
        return $this->mcro_olx_request( 'POST', '/adverts', $mcro_olx_payload );
    }

    public function mcro_olx_update_v2_advert( $mcro_olx_advert_id, array $mcro_olx_payload ) {
        return $this->mcro_olx_request( 'PUT', '/adverts/' . absint( $mcro_olx_advert_id ), $mcro_olx_payload );
    }

    public function mcro_olx_refresh_access_token() {
        $mcro_olx_options = $this->mcro_olx_settings->mcro_olx_get_options();
        if ( empty( $mcro_olx_options['client_id'] ) || empty( $mcro_olx_options['client_secret'] ) || empty( $mcro_olx_options['refresh_token'] ) ) {
            return new WP_Error( 'mcro_olx_refresh_missing_credentials', esc_html__( 'Missing OAuth refresh credentials.', 'marketplace-connector-ro-for-woocommerce' ) );
        }

        $mcro_olx_market = $this->mcro_olx_settings->mcro_olx_get_market_config( $mcro_olx_options['market'] );
        $mcro_olx_response = wp_remote_post(
            esc_url_raw( $mcro_olx_market['token_url'] ),
            array(
                'timeout' => 45,
                'headers' => array( 'Accept' => 'application/json' ),
                'body'    => array(
                    'grant_type'    => 'refresh_token',
                    'client_id'     => $mcro_olx_options['client_id'],
                    'client_secret' => $mcro_olx_options['client_secret'],
                    'refresh_token' => $mcro_olx_options['refresh_token'],
                ),
            )
        );

        $mcro_olx_json = $this->mcro_olx_parse_response( $mcro_olx_response );
        if ( is_wp_error( $mcro_olx_json ) ) {
            return $mcro_olx_json;
        }
        $this->mcro_olx_settings->mcro_olx_save_tokens_from_response( $mcro_olx_json );
        return $mcro_olx_json;
    }

    private function mcro_olx_parse_response( $mcro_olx_response ) {
        if ( is_wp_error( $mcro_olx_response ) ) {
            return $mcro_olx_response;
        }
        $mcro_olx_code = (int) wp_remote_retrieve_response_code( $mcro_olx_response );
        $mcro_olx_raw  = (string) wp_remote_retrieve_body( $mcro_olx_response );
        $mcro_olx_json = json_decode( $mcro_olx_raw, true );
        if ( $mcro_olx_code < 200 || $mcro_olx_code >= 300 ) {
            return new WP_Error(
                'mcro_olx_api_error',
                sprintf(
                    /* translators: 1: HTTP status code, 2: response body */
                    esc_html__( 'OLX API error %1$d: %2$s', 'marketplace-connector-ro-for-woocommerce' ),
                    $mcro_olx_code,
                    is_array( $mcro_olx_json ) ? wp_json_encode( $mcro_olx_json ) : $mcro_olx_raw
                )
            );
        }
        if ( is_array( $mcro_olx_json ) && array_key_exists( 'data', $mcro_olx_json ) ) {
            return is_array( $mcro_olx_json['data'] ) ? $mcro_olx_json['data'] : array( 'data' => $mcro_olx_json['data'] );
        }
        return is_array( $mcro_olx_json ) ? $mcro_olx_json : array( 'raw' => $mcro_olx_raw );
    }
}
