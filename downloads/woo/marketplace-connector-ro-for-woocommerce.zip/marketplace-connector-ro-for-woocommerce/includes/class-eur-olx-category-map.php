<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCRO_OLX_Category_Map {
    const MCRO_OLX_CATEGORY_MAP_OPTION = 'mcro_olx_category_map';
    const MCRO_OLX_CATEGORY_MAP_NONCE = 'mcro_olx_category_map_nonce_action';

    public function mcro_olx_get_map() {
        $mcro_olx_map = get_option( self::MCRO_OLX_CATEGORY_MAP_OPTION, array() );
        return is_array( $mcro_olx_map ) ? $mcro_olx_map : array();
    }

    public function mcro_olx_get_mapping_for_product( $mcro_olx_product_id ) {
        $mcro_olx_map   = $this->mcro_olx_get_map();
        $mcro_olx_terms = wp_get_post_terms( absint( $mcro_olx_product_id ), 'product_cat' );
        if ( is_wp_error( $mcro_olx_terms ) ) {
            return array();
        }
        foreach ( $mcro_olx_terms as $mcro_olx_term ) {
            $mcro_olx_term_id = (string) absint( $mcro_olx_term->term_id );
            if ( empty( $mcro_olx_map[ $mcro_olx_term_id ] ) ) {
                continue;
            }
            if ( is_array( $mcro_olx_map[ $mcro_olx_term_id ] ) ) {
                return $mcro_olx_map[ $mcro_olx_term_id ];
            }
            return array( 'category_id' => absint( $mcro_olx_map[ $mcro_olx_term_id ] ) );
        }
        return array();
    }

    public function mcro_olx_get_olx_category_id_for_product( $mcro_olx_product_id ) {
        $mcro_olx_mapping = $this->mcro_olx_get_mapping_for_product( $mcro_olx_product_id );
        return ! empty( $mcro_olx_mapping['category_id'] ) ? absint( $mcro_olx_mapping['category_id'] ) : '';
    }

    public function mcro_olx_get_attributes_for_product( $mcro_olx_product_id ) {
        $mcro_olx_mapping    = $this->mcro_olx_get_mapping_for_product( $mcro_olx_product_id );
        $mcro_olx_attributes = array();
        $mcro_olx_state      = ! empty( $mcro_olx_mapping['state'] ) ? sanitize_key( $mcro_olx_mapping['state'] ) : 'new';
        if ( $mcro_olx_state ) {
            $mcro_olx_attributes[] = array( 'code' => 'state', 'value' => $mcro_olx_state );
        }
        if ( ! empty( $mcro_olx_mapping['attributes'] ) && is_array( $mcro_olx_mapping['attributes'] ) ) {
            foreach ( $mcro_olx_mapping['attributes'] as $mcro_olx_attribute ) {
                if ( empty( $mcro_olx_attribute['code'] ) || ! isset( $mcro_olx_attribute['value'] ) ) {
                    continue;
                }
                $mcro_olx_code  = sanitize_key( $mcro_olx_attribute['code'] );
                $mcro_olx_value = sanitize_text_field( (string) $mcro_olx_attribute['value'] );
                if ( $mcro_olx_code && '' !== $mcro_olx_value ) {
                    $mcro_olx_attributes[] = array( 'code' => $mcro_olx_code, 'value' => $mcro_olx_value );
                }
            }
        }
        return $this->mcro_olx_dedupe_attributes( $mcro_olx_attributes );
    }

    public function mcro_olx_handle_category_map_save() {
        if ( empty( $_POST['mcro_olx_category_map_submit'] ) ) {
            return;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to save category mapping.', 'marketplace-connector-ro-for-woocommerce' ) );
        }
        check_admin_referer( self::MCRO_OLX_CATEGORY_MAP_NONCE, 'mcro_olx_category_map_nonce' );

        $mcro_olx_raw_map = isset( $_POST['mcro_olx_category_map'] ) && is_array( $_POST['mcro_olx_category_map'] ) ? map_deep( wp_unslash( $_POST['mcro_olx_category_map'] ), 'sanitize_text_field' ) : array();
        $mcro_olx_clean   = array();
        foreach ( $mcro_olx_raw_map as $mcro_olx_woo_cat_id => $mcro_olx_row ) {
            $mcro_olx_woo_cat_id = absint( $mcro_olx_woo_cat_id );
            if ( ! $mcro_olx_woo_cat_id || ! is_array( $mcro_olx_row ) ) {
                continue;
            }
            $mcro_olx_olx_cat_id = ! empty( $mcro_olx_row['category_id'] ) ? absint( $mcro_olx_row['category_id'] ) : 0;
            if ( ! $mcro_olx_olx_cat_id ) {
                continue;
            }
            $mcro_olx_clean[ (string) $mcro_olx_woo_cat_id ] = array(
                'category_id'   => $mcro_olx_olx_cat_id,
                'category_path' => isset( $mcro_olx_row['category_path'] ) ? sanitize_text_field( $mcro_olx_row['category_path'] ) : '',
                'state'         => isset( $mcro_olx_row['state'] ) ? sanitize_key( $mcro_olx_row['state'] ) : 'new',
                'attributes'    => $this->mcro_olx_parse_attribute_lines( isset( $mcro_olx_row['attributes'] ) ? (string) $mcro_olx_row['attributes'] : '' ),
            );
        }
        update_option( self::MCRO_OLX_CATEGORY_MAP_OPTION, $mcro_olx_clean, false );
        add_settings_error( 'mcro_olx_category_map', 'mcro_olx_category_map_saved', esc_html__( 'Category mapping saved.', 'marketplace-connector-ro-for-woocommerce' ), 'updated' );
    }

    public function mcro_olx_render_category_map_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'marketplace-connector-ro-for-woocommerce' ) );
        }
        $mcro_olx_map        = $this->mcro_olx_get_map();
        $mcro_olx_categories = $this->mcro_olx_get_ro_category_suggestions();
        $mcro_olx_terms      = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Marketplace Connector RO Category Mapping', 'marketplace-connector-ro-for-woocommerce' ); ?></h1>
            <p class="description"><?php echo esc_html__( 'Map WooCommerce categories to OLX.ro category IDs and define required category attributes such as condition/state. Category ID fields include live OLX.ro API suggestions when OAuth is connected. Additional attributes use one code=value pair per line, for example brand=Samsung.', 'marketplace-connector-ro-for-woocommerce' ); ?></p>
            <?php if ( ! empty( $mcro_olx_categories ) ) : ?>
                <datalist id="mcro_olx_ro_categories">
                    <?php foreach ( $mcro_olx_categories as $mcro_olx_category ) : ?>
                        <option value="<?php echo esc_attr( $mcro_olx_category['id'] ); ?>" label="<?php echo esc_attr( $mcro_olx_category['name'] ); ?>"></option>
                    <?php endforeach; ?>
                </datalist>
            <?php endif; ?>
            <?php settings_errors( 'mcro_olx_category_map' ); ?>
            <form method="post">
                <?php wp_nonce_field( self::MCRO_OLX_CATEGORY_MAP_NONCE, 'mcro_olx_category_map_nonce' ); ?>
                <input type="hidden" name="mcro_olx_category_map_submit" value="1">
                <table class="widefat striped">
                    <thead><tr><th><?php echo esc_html__( 'WooCommerce category', 'marketplace-connector-ro-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'OLX.ro category ID', 'marketplace-connector-ro-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Category note/path', 'marketplace-connector-ro-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Condition', 'marketplace-connector-ro-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Extra attributes', 'marketplace-connector-ro-for-woocommerce' ); ?></th></tr></thead>
                    <tbody>
                    <?php if ( ! is_wp_error( $mcro_olx_terms ) ) : ?>
                        <?php foreach ( $mcro_olx_terms as $mcro_olx_term ) : ?>
                            <?php
                            $mcro_olx_row = isset( $mcro_olx_map[ (string) $mcro_olx_term->term_id ] ) ? $mcro_olx_map[ (string) $mcro_olx_term->term_id ] : array();
                            if ( ! is_array( $mcro_olx_row ) ) {
                                $mcro_olx_row = array( 'category_id' => absint( $mcro_olx_row ) );
                            }
                            $mcro_olx_value = ! empty( $mcro_olx_row['category_id'] ) ? absint( $mcro_olx_row['category_id'] ) : '';
                            $mcro_olx_state = ! empty( $mcro_olx_row['state'] ) ? sanitize_key( $mcro_olx_row['state'] ) : 'new';
                            ?>
                            <tr>
                                <td><?php echo esc_html( $mcro_olx_term->name ); ?></td>
                                <td><input type="number" min="1" list="mcro_olx_ro_categories" name="mcro_olx_category_map[<?php echo esc_attr( $mcro_olx_term->term_id ); ?>][category_id]" value="<?php echo esc_attr( $mcro_olx_value ); ?>" class="small-text"></td>
                                <td><input type="text" name="mcro_olx_category_map[<?php echo esc_attr( $mcro_olx_term->term_id ); ?>][category_path]" value="<?php echo esc_attr( isset( $mcro_olx_row['category_path'] ) ? $mcro_olx_row['category_path'] : '' ); ?>" class="regular-text" placeholder="<?php echo esc_attr__( 'e.g. Home / Lighting', 'marketplace-connector-ro-for-woocommerce' ); ?>"></td>
                                <td><select name="mcro_olx_category_map[<?php echo esc_attr( $mcro_olx_term->term_id ); ?>][state]"><option value="new" <?php selected( $mcro_olx_state, 'new' ); ?>><?php echo esc_html__( 'New', 'marketplace-connector-ro-for-woocommerce' ); ?></option><option value="used" <?php selected( $mcro_olx_state, 'used' ); ?>><?php echo esc_html__( 'Used', 'marketplace-connector-ro-for-woocommerce' ); ?></option></select></td>
                                <td><textarea rows="3" cols="32" name="mcro_olx_category_map[<?php echo esc_attr( $mcro_olx_term->term_id ); ?>][attributes]" placeholder="brand=Samsung&#10;model=A54"><?php echo esc_textarea( $this->mcro_olx_format_attribute_lines( isset( $mcro_olx_row['attributes'] ) && is_array( $mcro_olx_row['attributes'] ) ? $mcro_olx_row['attributes'] : array() ) ); ?></textarea></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
                <?php submit_button( esc_html__( 'Save mapping', 'marketplace-connector-ro-for-woocommerce' ) ); ?>
            </form>
        </div>
        <?php
    }


    private function mcro_olx_get_ro_category_suggestions() {
        $mcro_olx_cached = get_transient( 'mcro_olx_ro_category_suggestions' );
        if ( is_array( $mcro_olx_cached ) ) {
            return $mcro_olx_cached;
        }
        $mcro_olx_options = get_option( 'mcro_olx_options', array() );
        if ( empty( $mcro_olx_options['access_token'] ) ) {
            return array();
        }
        $mcro_olx_response = wp_remote_get(
            'https://www.olx.ro/api/partner/categories?limit=1000',
            array(
                'timeout' => 20,
                'headers' => array(
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer ' . $mcro_olx_options['access_token'],
                    'Version'       => '2.0',
                ),
            )
        );
        if ( is_wp_error( $mcro_olx_response ) || 200 !== (int) wp_remote_retrieve_response_code( $mcro_olx_response ) ) {
            return array();
        }
        $mcro_olx_json = json_decode( (string) wp_remote_retrieve_body( $mcro_olx_response ), true );
        $mcro_olx_rows = isset( $mcro_olx_json['data'] ) && is_array( $mcro_olx_json['data'] ) ? $mcro_olx_json['data'] : array();
        $mcro_olx_categories = array();
        foreach ( $mcro_olx_rows as $mcro_olx_row ) {
            if ( empty( $mcro_olx_row['id'] ) || empty( $mcro_olx_row['name'] ) ) {
                continue;
            }
            $mcro_olx_categories[] = array(
                'id'   => absint( $mcro_olx_row['id'] ),
                'name' => sanitize_text_field( (string) $mcro_olx_row['name'] ),
            );
        }
        set_transient( 'mcro_olx_ro_category_suggestions', $mcro_olx_categories, DAY_IN_SECONDS );
        return $mcro_olx_categories;
    }

    private function mcro_olx_parse_attribute_lines( $mcro_olx_raw ) {
        $mcro_olx_attributes = array();
        foreach ( preg_split( '/\r\n|\r|\n/', (string) $mcro_olx_raw ) as $mcro_olx_line ) {
            $mcro_olx_line = trim( $mcro_olx_line );
            if ( '' === $mcro_olx_line || false === strpos( $mcro_olx_line, '=' ) ) {
                continue;
            }
            list( $mcro_olx_code, $mcro_olx_value ) = array_map( 'trim', explode( '=', $mcro_olx_line, 2 ) );
            $mcro_olx_code  = sanitize_key( $mcro_olx_code );
            $mcro_olx_value = sanitize_text_field( $mcro_olx_value );
            if ( $mcro_olx_code && '' !== $mcro_olx_value ) {
                $mcro_olx_attributes[] = array( 'code' => $mcro_olx_code, 'value' => $mcro_olx_value );
            }
        }
        return $this->mcro_olx_dedupe_attributes( $mcro_olx_attributes );
    }

    private function mcro_olx_format_attribute_lines( array $mcro_olx_attributes ) {
        $mcro_olx_lines = array();
        foreach ( $mcro_olx_attributes as $mcro_olx_attribute ) {
            if ( ! empty( $mcro_olx_attribute['code'] ) && isset( $mcro_olx_attribute['value'] ) ) {
                $mcro_olx_lines[] = sanitize_key( $mcro_olx_attribute['code'] ) . '=' . sanitize_text_field( (string) $mcro_olx_attribute['value'] );
            }
        }
        return implode( "\n", $mcro_olx_lines );
    }

    private function mcro_olx_dedupe_attributes( array $mcro_olx_attributes ) {
        $mcro_olx_seen = array();
        $mcro_olx_clean = array();
        foreach ( $mcro_olx_attributes as $mcro_olx_attribute ) {
            if ( empty( $mcro_olx_attribute['code'] ) || ! isset( $mcro_olx_attribute['value'] ) ) {
                continue;
            }
            $mcro_olx_code = sanitize_key( $mcro_olx_attribute['code'] );
            if ( ! $mcro_olx_code || isset( $mcro_olx_seen[ $mcro_olx_code ] ) ) {
                continue;
            }
            $mcro_olx_seen[ $mcro_olx_code ] = true;
            $mcro_olx_clean[] = array( 'code' => $mcro_olx_code, 'value' => sanitize_text_field( (string) $mcro_olx_attribute['value'] ) );
        }
        return $mcro_olx_clean;
    }
}
