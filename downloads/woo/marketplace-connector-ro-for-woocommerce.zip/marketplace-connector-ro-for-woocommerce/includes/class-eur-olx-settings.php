<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCRO_OLX_Settings {
    const MCRO_OLX_OPTION = 'mcro_olx_options';
    const MCRO_OLX_NONCE_ACTION = 'mcro_olx_settings_nonce_action';
    const MCRO_OLX_OAUTH_STATE_TRANSIENT_PREFIX = 'mcro_olx_oauth_state_';

    public function mcro_olx_get_defaults() {
        return array(
            'market'           => 'ro',
            'client_id'        => '',
            'client_secret'    => '',
            'access_token'     => '',
            'refresh_token'    => '',
            'token_expires_at' => '',
            'currency'         => '',
            'advertiser_type'  => 'business',
            'contact_name'     => '',
            'contact_phone'    => '',
            'city_id'          => '',
            'district_id'      => '',
            'cleanup_data'     => '0',
        );
    }

    public function mcro_olx_get_options() {
        $mcro_olx_options = get_option( self::MCRO_OLX_OPTION, array() );
        return wp_parse_args( is_array( $mcro_olx_options ) ? $mcro_olx_options : array(), $this->mcro_olx_get_defaults() );
    }

    public function mcro_olx_register_settings() {
        register_setting(
            'mcro_olx_settings_group',
            self::MCRO_OLX_OPTION,
            array(
                'type'              => 'array',
                'sanitize_callback' => array( $this, 'mcro_olx_sanitize_options' ),
                'default'           => $this->mcro_olx_get_defaults(),
            )
        );
    }

    public function mcro_olx_sanitize_options( $mcro_olx_input ) {
        $mcro_olx_old = $this->mcro_olx_get_options();
        if ( ! isset( $_POST['mcro_olx_settings_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mcro_olx_settings_nonce'] ) ), self::MCRO_OLX_NONCE_ACTION ) ) {
            add_settings_error( 'mcro_olx_settings', 'mcro_olx_settings_nonce_failed', esc_html__( 'Security check failed. Settings were not saved.', 'marketplace-connector-ro-for-woocommerce' ), 'error' );
            return $mcro_olx_old;
        }

        $mcro_olx_input = is_array( $mcro_olx_input ) ? wp_unslash( $mcro_olx_input ) : array();
        $mcro_olx_allowed_markets = array( 'ro' );
        $mcro_olx_market = isset( $mcro_olx_input['market'] ) ? sanitize_key( $mcro_olx_input['market'] ) : 'ro';

        return array(
            'market'           => in_array( $mcro_olx_market, $mcro_olx_allowed_markets, true ) ? $mcro_olx_market : 'pl',
            'client_id'        => isset( $mcro_olx_input['client_id'] ) ? sanitize_text_field( $mcro_olx_input['client_id'] ) : '',
            'client_secret'    => isset( $mcro_olx_input['client_secret'] ) && '' !== $mcro_olx_input['client_secret'] ? sanitize_text_field( $mcro_olx_input['client_secret'] ) : $mcro_olx_old['client_secret'],
            'access_token'     => isset( $mcro_olx_input['access_token'] ) && '' !== $mcro_olx_input['access_token'] ? sanitize_textarea_field( $mcro_olx_input['access_token'] ) : $mcro_olx_old['access_token'],
            'refresh_token'    => isset( $mcro_olx_input['refresh_token'] ) && '' !== $mcro_olx_input['refresh_token'] ? sanitize_textarea_field( $mcro_olx_input['refresh_token'] ) : $mcro_olx_old['refresh_token'],
            'token_expires_at' => isset( $mcro_olx_input['token_expires_at'] ) ? absint( $mcro_olx_input['token_expires_at'] ) : absint( $mcro_olx_old['token_expires_at'] ),
            'currency'         => isset( $mcro_olx_input['currency'] ) ? strtoupper( sanitize_text_field( $mcro_olx_input['currency'] ) ) : '',
            'advertiser_type'  => isset( $mcro_olx_input['advertiser_type'] ) && in_array( $mcro_olx_input['advertiser_type'], array( 'private', 'business' ), true ) ? sanitize_key( $mcro_olx_input['advertiser_type'] ) : 'business',
            'contact_name'     => isset( $mcro_olx_input['contact_name'] ) ? sanitize_text_field( $mcro_olx_input['contact_name'] ) : '',
            'contact_phone'    => isset( $mcro_olx_input['contact_phone'] ) ? sanitize_text_field( $mcro_olx_input['contact_phone'] ) : '',
            'city_id'          => isset( $mcro_olx_input['city_id'] ) ? absint( $mcro_olx_input['city_id'] ) : '',
            'district_id'      => isset( $mcro_olx_input['district_id'] ) ? absint( $mcro_olx_input['district_id'] ) : '',
            'cleanup_data'     => ! empty( $mcro_olx_input['cleanup_data'] ) ? '1' : '0',
        );
    }

    public function mcro_olx_get_market_config( $mcro_olx_market = '' ) {
        $mcro_olx_market = $mcro_olx_market ? sanitize_key( $mcro_olx_market ) : $this->mcro_olx_get_options()['market'];
        $mcro_olx_markets = array(
            'ro' => array( 'label' => 'Romania', 'base_url' => 'https://www.olx.ro/api/partner', 'oauth_url' => 'https://www.olx.ro/oauth/authorize', 'token_url' => 'https://www.olx.ro/api/open/oauth/token', 'currency' => 'RON' ),
        );
        $mcro_olx_markets = apply_filters( 'mcro_olx_market_configs', $mcro_olx_markets );
        return isset( $mcro_olx_markets[ $mcro_olx_market ] ) ? $mcro_olx_markets[ $mcro_olx_market ] : $mcro_olx_markets['ro'];
    }

    public function mcro_olx_get_oauth_redirect_uri() {
        return admin_url( 'admin-post.php?action=mcro_olx_oauth_callback' );
    }

    public function mcro_olx_handle_oauth_start() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to connect OLX.', 'marketplace-connector-ro-for-woocommerce' ) );
        }
        check_admin_referer( 'mcro_olx_oauth_start' );
        $mcro_olx_options = $this->mcro_olx_get_options();
        if ( empty( $mcro_olx_options['client_id'] ) ) {
            wp_safe_redirect( add_query_arg( 'mcro_olx_oauth_error', rawurlencode( __( 'Client ID is required before connecting.', 'marketplace-connector-ro-for-woocommerce' ) ), admin_url( 'admin.php?page=mcro_olx-settings' ) ) );
            exit;
        }
        $mcro_olx_market = $this->mcro_olx_get_market_config( $mcro_olx_options['market'] );
        $mcro_olx_state = wp_generate_password( 32, false, false );
        set_transient( self::MCRO_OLX_OAUTH_STATE_TRANSIENT_PREFIX . $mcro_olx_state, get_current_user_id(), 10 * MINUTE_IN_SECONDS );
        $mcro_olx_scopes = apply_filters( 'mcro_olx_oauth_scopes', array( 'v2', 'read', 'write' ) );
        $mcro_olx_auth_query = http_build_query(
            array(
                'response_type' => 'code',
                'client_id'     => $mcro_olx_options['client_id'],
                'redirect_uri'  => $this->mcro_olx_get_oauth_redirect_uri(),
                'scope'         => implode( ' ', array_map( 'sanitize_key', (array) $mcro_olx_scopes ) ),
                'state'         => $mcro_olx_state,
            ),
            '',
            '&',
            PHP_QUERY_RFC3986
        );
        $mcro_olx_auth_url = $mcro_olx_market['oauth_url'] . '?' . $mcro_olx_auth_query;
        update_option( 'mcro_olx_last_oauth_debug', array( 'phase' => 'start', 'redirect_uri' => $this->mcro_olx_get_oauth_redirect_uri(), 'auth_host' => wp_parse_url( $mcro_olx_market['oauth_url'], PHP_URL_HOST ), 'time' => time() ), false );
        wp_redirect( esc_url_raw( $mcro_olx_auth_url ) ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- External OAuth authorization URL is built from fixed OLX market configuration.
        exit;
    }

    public function mcro_olx_handle_oauth_callback() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to connect OLX.', 'marketplace-connector-ro-for-woocommerce' ) );
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- OAuth callbacks are validated via the provider state parameter.
        $mcro_olx_state = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- OAuth callbacks are validated via the provider state parameter.
        $mcro_olx_code  = isset( $_GET['code'] ) ? sanitize_text_field( wp_unslash( $_GET['code'] ) ) : '';
        $mcro_olx_saved = $mcro_olx_state ? get_transient( self::MCRO_OLX_OAUTH_STATE_TRANSIENT_PREFIX . $mcro_olx_state ) : false;
        update_option( 'mcro_olx_last_oauth_debug', array( 'phase' => 'callback_received', 'has_code' => $mcro_olx_code ? 'yes' : 'no', 'has_state' => $mcro_olx_state ? 'yes' : 'no', 'state_valid' => false === $mcro_olx_saved ? 'no' : 'yes', 'time' => time() ), false );
        if ( ! $mcro_olx_state || ! $mcro_olx_code || false === $mcro_olx_saved ) {
            wp_safe_redirect( add_query_arg( 'mcro_olx_oauth_error', rawurlencode( __( 'OAuth callback validation failed. The callback did not include a valid code/state pair.', 'marketplace-connector-ro-for-woocommerce' ) ), admin_url( 'admin.php?page=mcro_olx-settings' ) ) );
            exit;
        }
        delete_transient( self::MCRO_OLX_OAUTH_STATE_TRANSIENT_PREFIX . $mcro_olx_state );
        $mcro_olx_result = $this->mcro_olx_exchange_code_for_tokens( $mcro_olx_code );
        if ( ! is_wp_error( $mcro_olx_result ) ) {
            $mcro_olx_after_save = $this->mcro_olx_get_options();
            if ( empty( $mcro_olx_after_save['access_token'] ) ) {
                $mcro_olx_result = new WP_Error( 'mcro_olx_oauth_token_not_saved', esc_html__( 'OAuth completed but the access token was not saved. Re-save Client Secret and connect again.', 'marketplace-connector-ro-for-woocommerce' ) );
            }
        }
        $mcro_olx_arg = is_wp_error( $mcro_olx_result ) ? array( 'mcro_olx_oauth_error' => rawurlencode( $mcro_olx_result->get_error_message() ) ) : array( 'mcro_olx_oauth_connected' => '1' );
        wp_safe_redirect( add_query_arg( $mcro_olx_arg, admin_url( 'admin.php?page=mcro_olx-settings' ) ) );
        exit;
    }

    private function mcro_olx_exchange_code_for_tokens( $mcro_olx_code ) {
        $mcro_olx_options = $this->mcro_olx_get_options();
        $mcro_olx_market = $this->mcro_olx_get_market_config( $mcro_olx_options['market'] );
        if ( empty( $mcro_olx_options['client_id'] ) || empty( $mcro_olx_options['client_secret'] ) ) {
            return new WP_Error( 'mcro_olx_oauth_missing_client', esc_html__( 'Client ID and Client Secret are required.', 'marketplace-connector-ro-for-woocommerce' ) );
        }
        $mcro_olx_response = wp_remote_post(
            esc_url_raw( $mcro_olx_market['token_url'] ),
            array(
                'timeout' => 45,
                'headers' => array( 'Accept' => 'application/json' ),
                'body'    => array(
                    'grant_type'    => 'authorization_code',
                    'client_id'     => $mcro_olx_options['client_id'],
                    'client_secret' => $mcro_olx_options['client_secret'],
                    'redirect_uri'  => $this->mcro_olx_get_oauth_redirect_uri(),
                    'code'          => $mcro_olx_code,
                ),
            )
        );
        if ( is_wp_error( $mcro_olx_response ) ) {
            return $mcro_olx_response;
        }
        $mcro_olx_code_http = (int) wp_remote_retrieve_response_code( $mcro_olx_response );
        $mcro_olx_raw = (string) wp_remote_retrieve_body( $mcro_olx_response );
        $mcro_olx_json = json_decode( $mcro_olx_raw, true );
        $mcro_olx_debug_body = $mcro_olx_raw;
        $mcro_olx_debug_body = preg_replace( '/"access_token"\s*:\s*"[^"]+"/', '"access_token":"[REDACTED]"', $mcro_olx_debug_body );
        $mcro_olx_debug_body = preg_replace( '/"refresh_token"\s*:\s*"[^"]+"/', '"refresh_token":"[REDACTED]"', $mcro_olx_debug_body );
        update_option( 'mcro_olx_last_oauth_debug', array( 'phase' => 'token_response', 'http' => $mcro_olx_code_http, 'json' => is_array( $mcro_olx_json ) ? 'yes' : 'no', 'has_access_token' => is_array( $mcro_olx_json ) && ! empty( $mcro_olx_json['access_token'] ) ? 'yes' : 'no', 'has_refresh_token' => is_array( $mcro_olx_json ) && ! empty( $mcro_olx_json['refresh_token'] ) ? 'yes' : 'no', 'body' => substr( sanitize_textarea_field( $mcro_olx_debug_body ), 0, 800 ), 'time' => time() ), false );
        if ( $mcro_olx_code_http < 200 || $mcro_olx_code_http >= 300 || ! is_array( $mcro_olx_json ) ) {
            /* translators: %s: Redacted response body returned by the OAuth token endpoint. */
            return new WP_Error( 'mcro_olx_oauth_token_error', sprintf( esc_html__( 'OAuth token exchange failed: %s', 'marketplace-connector-ro-for-woocommerce' ), $mcro_olx_raw ) );
        }
        if ( empty( $mcro_olx_json['access_token'] ) ) {
            return new WP_Error( 'mcro_olx_oauth_missing_access_token', esc_html__( 'OAuth token exchange completed but OLX did not return an access token. Check the callback URI and application approval.', 'marketplace-connector-ro-for-woocommerce' ) );
        }
        $this->mcro_olx_save_tokens_from_response( $mcro_olx_json );
        return $mcro_olx_json;
    }

    public function mcro_olx_save_tokens_from_response( array $mcro_olx_response ) {
        $mcro_olx_options = $this->mcro_olx_get_options();
        if ( ! empty( $mcro_olx_response['access_token'] ) ) {
            $mcro_olx_options['access_token'] = sanitize_textarea_field( $mcro_olx_response['access_token'] );
        }
        if ( ! empty( $mcro_olx_response['refresh_token'] ) ) {
            $mcro_olx_options['refresh_token'] = sanitize_textarea_field( $mcro_olx_response['refresh_token'] );
        }
        if ( ! empty( $mcro_olx_response['expires_in'] ) ) {
            $mcro_olx_options['token_expires_at'] = time() + absint( $mcro_olx_response['expires_in'] );
        }
        // OAuth callback is an internal trusted write; bypass the settings-form nonce sanitizer for this update.
        remove_filter( 'sanitize_option_' . self::MCRO_OLX_OPTION, array( $this, 'mcro_olx_sanitize_options' ), 10 );
        update_option( self::MCRO_OLX_OPTION, $mcro_olx_options, false );
        add_filter( 'sanitize_option_' . self::MCRO_OLX_OPTION, array( $this, 'mcro_olx_sanitize_options' ), 10, 1 );
        $mcro_olx_persisted = $this->mcro_olx_get_options();
        update_option( 'mcro_olx_last_oauth_debug', array( 'phase' => 'tokens_saved', 'access_len' => ! empty( $mcro_olx_persisted['access_token'] ) ? strlen( $mcro_olx_persisted['access_token'] ) : 0, 'refresh_len' => ! empty( $mcro_olx_persisted['refresh_token'] ) ? strlen( $mcro_olx_persisted['refresh_token'] ) : 0, 'expires_at' => ! empty( $mcro_olx_persisted['token_expires_at'] ) ? absint( $mcro_olx_persisted['token_expires_at'] ) : 0, 'time' => time() ), false );
    }

    public function mcro_olx_render_settings_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'marketplace-connector-ro-for-woocommerce' ) );
        }
        $mcro_olx_options = $this->mcro_olx_get_options();
        $mcro_olx_market_config = $this->mcro_olx_get_market_config( $mcro_olx_options['market'] );
        $mcro_olx_connect_url = wp_nonce_url( admin_url( 'admin-post.php?action=mcro_olx_oauth_start' ), 'mcro_olx_oauth_start' );
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Marketplace Connector RO for WooCommerce', 'marketplace-connector-ro-for-woocommerce' ); ?></h1>
            <p><?php echo esc_html__( 'Manual WooCommerce product synchronization for the OLX.ro marketplace. This plugin is not affiliated with, endorsed by, or sponsored by OLX Group.', 'marketplace-connector-ro-for-woocommerce' ); ?></p>
            <?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Admin notice flag after OAuth redirect. ?>
            <?php if ( isset( $_GET['mcro_olx_oauth_connected'] ) && ! empty( $mcro_olx_options['access_token'] ) ) : ?>
                <div class="notice notice-success"><p><?php echo esc_html__( 'OLX OAuth connection completed and token saved.', 'marketplace-connector-ro-for-woocommerce' ); ?></p></div>
            <?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Admin notice flag after OAuth redirect. ?>
            <?php elseif ( isset( $_GET['mcro_olx_oauth_connected'] ) ) : ?>
                <div class="notice notice-warning"><p><?php echo esc_html__( 'OLX returned to this page, but no access token is saved yet. Please use the exact callback URI and complete the Connect with OLX flow again.', 'marketplace-connector-ro-for-woocommerce' ); ?></p></div>
            <?php endif; ?>
            <?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Admin notice flag after OAuth redirect. ?>
            <?php if ( isset( $_GET['mcro_olx_oauth_error'] ) ) : ?>
                <?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Admin notice flag after OAuth redirect. ?>
                <div class="notice notice-error"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['mcro_olx_oauth_error'] ) ) ); ?></p></div>
            <?php endif; ?>
            <?php $mcro_olx_oauth_debug = get_option( 'mcro_olx_last_oauth_debug', array() ); ?>
            <?php if ( ! empty( $mcro_olx_oauth_debug ) && is_array( $mcro_olx_oauth_debug ) ) : ?>
                <div class="notice notice-info"><p><strong><?php echo esc_html__( 'Last OAuth debug:', 'marketplace-connector-ro-for-woocommerce' ); ?></strong> <?php echo esc_html( wp_json_encode( $mcro_olx_oauth_debug ) ); ?></p></div>
            <?php endif; ?>
            <form method="post" action="options.php">
                <?php settings_fields( 'mcro_olx_settings_group' ); ?>
                <?php wp_nonce_field( self::MCRO_OLX_NONCE_ACTION, 'mcro_olx_settings_nonce' ); ?>
                <table class="form-table" role="presentation">
                    <tr><th scope="row"><label for="mcro_olx_market"><?php echo esc_html__( 'Market', 'marketplace-connector-ro-for-woocommerce' ); ?></label></th><td><select id="mcro_olx_market" name="<?php echo esc_attr( self::MCRO_OLX_OPTION ); ?>[market]"><?php foreach ( array( 'ro' => 'Romania' ) as $mcro_olx_key => $mcro_olx_label ) : ?><option value="<?php echo esc_attr( $mcro_olx_key ); ?>" <?php selected( $mcro_olx_options['market'], $mcro_olx_key ); ?>><?php echo esc_html( $mcro_olx_label ); ?></option><?php endforeach; ?></select><p class="description"><?php echo esc_html( sprintf( 'Current API base: %s', $mcro_olx_market_config['base_url'] ) ); ?></p></td></tr>
                    <tr><th scope="row"><label for="mcro_olx_client_id">Client ID</label></th><td><input id="mcro_olx_client_id" class="regular-text" name="<?php echo esc_attr( self::MCRO_OLX_OPTION ); ?>[client_id]" value="<?php echo esc_attr( $mcro_olx_options['client_id'] ); ?>"></td></tr>
                    <tr><th scope="row"><label for="mcro_olx_client_secret">Client Secret</label></th><td><input id="mcro_olx_client_secret" type="password" class="regular-text" name="<?php echo esc_attr( self::MCRO_OLX_OPTION ); ?>[client_secret]" value="" placeholder="<?php echo esc_attr__( 'Leave empty to keep saved value', 'marketplace-connector-ro-for-woocommerce' ); ?>"></td></tr>
                    <tr><th scope="row"><?php echo esc_html__( 'OAuth connection', 'marketplace-connector-ro-for-woocommerce' ); ?></th><td><a class="button" href="<?php echo esc_url( $mcro_olx_connect_url ); ?>"><?php echo esc_html__( 'Connect with OLX', 'marketplace-connector-ro-for-woocommerce' ); ?></a><p class="description"><?php echo esc_html__( 'Save Client ID and Client Secret first, then connect. Manual token fields below remain available for advanced troubleshooting.', 'marketplace-connector-ro-for-woocommerce' ); ?></p></td></tr>
                    <tr><th scope="row"><label for="mcro_olx_access_token">Access Token</label></th><td><textarea id="mcro_olx_access_token" class="large-text" rows="3" name="<?php echo esc_attr( self::MCRO_OLX_OPTION ); ?>[access_token]" placeholder="<?php echo esc_attr__( 'Leave empty to keep saved value', 'marketplace-connector-ro-for-woocommerce' ); ?>"></textarea></td></tr>
                    <tr><th scope="row"><label for="mcro_olx_refresh_token">Refresh Token</label></th><td><textarea id="mcro_olx_refresh_token" class="large-text" rows="3" name="<?php echo esc_attr( self::MCRO_OLX_OPTION ); ?>[refresh_token]" placeholder="<?php echo esc_attr__( 'Leave empty to keep saved value', 'marketplace-connector-ro-for-woocommerce' ); ?>"></textarea></td></tr>
                    <tr><th scope="row"><label for="mcro_olx_currency">Currency</label></th><td><input id="mcro_olx_currency" name="<?php echo esc_attr( self::MCRO_OLX_OPTION ); ?>[currency]" value="<?php echo esc_attr( $mcro_olx_options['currency'] ); ?>" placeholder="<?php echo esc_attr( $mcro_olx_market_config['currency'] ); ?>"></td></tr>
                    <tr><th scope="row">Advertiser type</th><td><select name="<?php echo esc_attr( self::MCRO_OLX_OPTION ); ?>[advertiser_type]"><option value="business" <?php selected( $mcro_olx_options['advertiser_type'], 'business' ); ?>>business</option><option value="private" <?php selected( $mcro_olx_options['advertiser_type'], 'private' ); ?>>private</option></select></td></tr>
                    <tr><th scope="row"><label for="mcro_olx_contact_name">Contact name</label></th><td><input id="mcro_olx_contact_name" class="regular-text" name="<?php echo esc_attr( self::MCRO_OLX_OPTION ); ?>[contact_name]" value="<?php echo esc_attr( $mcro_olx_options['contact_name'] ); ?>"></td></tr>
                    <tr><th scope="row"><label for="mcro_olx_contact_phone">Contact phone</label></th><td><input id="mcro_olx_contact_phone" class="regular-text" name="<?php echo esc_attr( self::MCRO_OLX_OPTION ); ?>[contact_phone]" value="<?php echo esc_attr( $mcro_olx_options['contact_phone'] ); ?>"></td></tr>
                    <tr><th scope="row"><label for="mcro_olx_city_id">Default city ID</label></th><td><input id="mcro_olx_city_id" type="number" name="<?php echo esc_attr( self::MCRO_OLX_OPTION ); ?>[city_id]" value="<?php echo esc_attr( $mcro_olx_options['city_id'] ); ?>"></td></tr>
                    <tr><th scope="row"><label for="mcro_olx_district_id">Default district ID</label></th><td><input id="mcro_olx_district_id" type="number" name="<?php echo esc_attr( self::MCRO_OLX_OPTION ); ?>[district_id]" value="<?php echo esc_attr( $mcro_olx_options['district_id'] ); ?>"></td></tr>
                    <tr><th scope="row"><?php echo esc_html__( 'Uninstall cleanup', 'marketplace-connector-ro-for-woocommerce' ); ?></th><td><label><input type="checkbox" name="<?php echo esc_attr( self::MCRO_OLX_OPTION ); ?>[cleanup_data]" value="1" <?php checked( $mcro_olx_options['cleanup_data'], '1' ); ?>> <?php echo esc_html__( 'Remove plugin options, category mappings and OLX advert meta on uninstall.', 'marketplace-connector-ro-for-woocommerce' ); ?></label></td></tr>
                </table>
                <?php submit_button( esc_html__( 'Save settings', 'marketplace-connector-ro-for-woocommerce' ) ); ?>
            </form>
        </div>
        <?php
    }
}
