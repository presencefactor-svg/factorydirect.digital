<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCRO_OLX_Product_Sync {
    const MCRO_OLX_ADVERT_ID_META = '_mcro_olx_advert_id';
    const MCRO_OLX_STATUS_META    = '_mcro_olx_status';
    const MCRO_OLX_LAST_ERROR_META= '_mcro_olx_last_error';
    const MCRO_OLX_SYNC_NONCE     = 'mcro_olx_sync_product_nonce_action';

    private $mcro_olx_settings;
    private $mcro_olx_category_map;
    private $mcro_olx_api_client;

    public function __construct( MCRO_OLX_Settings $mcro_olx_settings, MCRO_OLX_Category_Map $mcro_olx_category_map ) {
        $this->mcro_olx_settings     = $mcro_olx_settings;
        $this->mcro_olx_category_map = $mcro_olx_category_map;
        $this->mcro_olx_api_client   = new MCRO_OLX_API_Client( $mcro_olx_settings );
    }

    public function mcro_olx_register_hooks() {
        add_action( 'add_meta_boxes_product', array( $this, 'mcro_olx_add_product_metabox' ) );
        add_action( 'admin_post_mcro_olx_sync_product', array( $this, 'mcro_olx_handle_manual_sync' ) );
        add_filter( 'bulk_actions-edit-product', array( $this, 'mcro_olx_register_bulk_actions' ) );
        add_filter( 'handle_bulk_actions-edit-product', array( $this, 'mcro_olx_handle_bulk_actions' ), 10, 3 );
    }

    public function mcro_olx_add_product_metabox() {
        add_meta_box(
            'mcro_olx_product_sync',
            esc_html__( 'Marketplace Connector RO Sync', 'marketplace-connector-ro-for-woocommerce' ),
            array( $this, 'mcro_olx_render_product_metabox' ),
            'product',
            'side',
            'default'
        );
    }

    public function mcro_olx_render_product_metabox( $mcro_olx_post ) {
        if ( ! current_user_can( 'edit_product', $mcro_olx_post->ID ) ) {
            return;
        }
        $mcro_olx_advert_id = get_post_meta( $mcro_olx_post->ID, self::MCRO_OLX_ADVERT_ID_META, true );
        $mcro_olx_status    = get_post_meta( $mcro_olx_post->ID, self::MCRO_OLX_STATUS_META, true );
        $mcro_olx_error     = get_post_meta( $mcro_olx_post->ID, self::MCRO_OLX_LAST_ERROR_META, true );
        $mcro_olx_url       = wp_nonce_url(
            admin_url( 'admin-post.php?action=mcro_olx_sync_product&product_id=' . absint( $mcro_olx_post->ID ) ),
            self::MCRO_OLX_SYNC_NONCE,
            'mcro_olx_nonce'
        );
        echo '<p><strong>' . esc_html__( 'Advert ID:', 'marketplace-connector-ro-for-woocommerce' ) . '</strong> ' . esc_html( $mcro_olx_advert_id ? $mcro_olx_advert_id : '-' ) . '</p>';
        echo '<p><strong>' . esc_html__( 'Status:', 'marketplace-connector-ro-for-woocommerce' ) . '</strong> ' . esc_html( $mcro_olx_status ? $mcro_olx_status : '-' ) . '</p>';
        if ( $mcro_olx_error ) {
            echo '<p class="description" style="color:#b32d2e;">' . esc_html( $mcro_olx_error ) . '</p>';
        }
        echo '<p><a class="button button-primary" href="' . esc_url( $mcro_olx_url ) . '">' . esc_html__( 'Sync to OLX', 'marketplace-connector-ro-for-woocommerce' ) . '</a></p>';
    }

    public function mcro_olx_handle_manual_sync() {
        $mcro_olx_product_id = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0;
        if ( ! $mcro_olx_product_id || ! current_user_can( 'edit_product', $mcro_olx_product_id ) ) {
            wp_die( esc_html__( 'You do not have permission to sync this product.', 'marketplace-connector-ro-for-woocommerce' ) );
        }
        check_admin_referer( self::MCRO_OLX_SYNC_NONCE, 'mcro_olx_nonce' );

        $mcro_olx_result = $this->mcro_olx_sync_product( $mcro_olx_product_id );
        $mcro_olx_args   = is_wp_error( $mcro_olx_result )
            ? array( 'mcro_olx_error' => rawurlencode( $mcro_olx_result->get_error_message() ) )
            : array( 'mcro_olx_message' => rawurlencode( esc_html__( 'Product synced to OLX.ro.', 'marketplace-connector-ro-for-woocommerce' ) ) );

        wp_safe_redirect( add_query_arg( $mcro_olx_args, get_edit_post_link( $mcro_olx_product_id, 'url' ) ) );
        exit;
    }

    public function mcro_olx_register_bulk_actions( $mcro_olx_actions ) {
        $mcro_olx_actions['mcro_olx_bulk_sync'] = esc_html__( 'Sync to Marketplace Connector RO', 'marketplace-connector-ro-for-woocommerce' );
        return $mcro_olx_actions;
    }

    public function mcro_olx_handle_bulk_actions( $mcro_olx_redirect, $mcro_olx_action, $mcro_olx_product_ids ) {
        if ( 'mcro_olx_bulk_sync' !== $mcro_olx_action ) {
            return $mcro_olx_redirect;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return $mcro_olx_redirect;
        }
        // WordPress core verifies the bulk action nonce before this filter is called.
        $mcro_olx_success = 0;
        $mcro_olx_failed  = 0;
        foreach ( array_map( 'absint', (array) $mcro_olx_product_ids ) as $mcro_olx_product_id ) {
            $mcro_olx_result = $this->mcro_olx_sync_product( $mcro_olx_product_id );
            is_wp_error( $mcro_olx_result ) ? $mcro_olx_failed++ : $mcro_olx_success++;
        }
        return add_query_arg( array( 'mcro_olx_success' => $mcro_olx_success, 'mcro_olx_failed' => $mcro_olx_failed ), $mcro_olx_redirect );
    }

    public function mcro_olx_sync_product( $mcro_olx_product_id ) {
        if ( ! function_exists( 'wc_get_product' ) ) {
            return new WP_Error( 'mcro_olx_missing_wc', esc_html__( 'WooCommerce is not active.', 'marketplace-connector-ro-for-woocommerce' ) );
        }

        $mcro_olx_product = wc_get_product( absint( $mcro_olx_product_id ) );
        if ( ! $mcro_olx_product ) {
            return new WP_Error( 'mcro_olx_missing_product', esc_html__( 'Product not found.', 'marketplace-connector-ro-for-woocommerce' ) );
        }

        $mcro_olx_payload = $this->mcro_olx_build_advert_payload( $mcro_olx_product );
        if ( is_wp_error( $mcro_olx_payload ) ) {
            return $mcro_olx_payload;
        }

        /** Hook for PRO/custom payload changes: variations, custom attributes, GPS, delivery, safety regulations. */
        $mcro_olx_payload = apply_filters( 'mcro_olx_advert_payload', $mcro_olx_payload, $mcro_olx_product );
        do_action( 'mcro_olx_before_manual_sync', $mcro_olx_product->get_id(), $mcro_olx_payload );

        $mcro_olx_existing_advert_id = get_post_meta( $mcro_olx_product->get_id(), self::MCRO_OLX_ADVERT_ID_META, true );
        $mcro_olx_response = $mcro_olx_existing_advert_id ? $this->mcro_olx_api_client->mcro_olx_update_v2_advert( $mcro_olx_existing_advert_id, $mcro_olx_payload ) : $this->mcro_olx_api_client->mcro_olx_post_v2_advert( $mcro_olx_payload );
        if ( is_wp_error( $mcro_olx_response ) ) {
            update_post_meta( $mcro_olx_product->get_id(), self::MCRO_OLX_LAST_ERROR_META, sanitize_text_field( $mcro_olx_response->get_error_message() ) );
            return $mcro_olx_response;
        }

        if ( isset( $mcro_olx_response['id'] ) ) {
            update_post_meta( $mcro_olx_product->get_id(), self::MCRO_OLX_ADVERT_ID_META, absint( $mcro_olx_response['id'] ) );
        }
        if ( isset( $mcro_olx_response['status'] ) ) {
            update_post_meta( $mcro_olx_product->get_id(), self::MCRO_OLX_STATUS_META, sanitize_text_field( $mcro_olx_response['status'] ) );
        }
        delete_post_meta( $mcro_olx_product->get_id(), self::MCRO_OLX_LAST_ERROR_META );
        do_action( 'mcro_olx_after_manual_sync', $mcro_olx_product->get_id(), $mcro_olx_response );

        return $mcro_olx_response;
    }

    private function mcro_olx_build_advert_payload( WC_Product $mcro_olx_product ) {
        $mcro_olx_options     = $this->mcro_olx_settings->mcro_olx_get_options();
        $mcro_olx_market      = $this->mcro_olx_settings->mcro_olx_get_market_config( $mcro_olx_options['market'] );
        $mcro_olx_category_id = $this->mcro_olx_category_map->mcro_olx_get_olx_category_id_for_product( $mcro_olx_product->get_id() );

        if ( ! $mcro_olx_category_id ) {
            return new WP_Error( 'mcro_olx_missing_category', esc_html__( 'Missing OLX category mapping for this product.', 'marketplace-connector-ro-for-woocommerce' ) );
        }
        if ( empty( $mcro_olx_options['city_id'] ) || empty( $mcro_olx_options['contact_name'] ) ) {
            return new WP_Error( 'mcro_olx_missing_required_settings', esc_html__( 'Missing default city ID or contact name in Marketplace Connector RO settings.', 'marketplace-connector-ro-for-woocommerce' ) );
        }

        $mcro_olx_title = sanitize_text_field( wp_strip_all_tags( $mcro_olx_product->get_name() ) );
        $mcro_olx_desc  = wp_kses_post( $mcro_olx_product->get_description() ? $mcro_olx_product->get_description() : $mcro_olx_product->get_short_description() );
        $mcro_olx_price = (float) wc_get_price_to_display( $mcro_olx_product );
        $mcro_olx_currency = $mcro_olx_options['currency'] ? $mcro_olx_options['currency'] : $mcro_olx_market['currency'];

        $mcro_olx_images = array();
        $mcro_olx_image_ids = array_filter( array_unique( array_merge( array( $mcro_olx_product->get_image_id() ), $mcro_olx_product->get_gallery_image_ids() ) ) );
        foreach ( array_slice( $mcro_olx_image_ids, 0, 8 ) as $mcro_olx_image_id ) {
            $mcro_olx_image_url = wp_get_attachment_url( absint( $mcro_olx_image_id ) );
            if ( $mcro_olx_image_url && $this->mcro_olx_is_public_image_url( $mcro_olx_image_url ) ) {
                $mcro_olx_images[] = array( 'url' => esc_url_raw( $mcro_olx_image_url ) );
            }
        }

        $mcro_olx_payload = array(
            'title'           => $mcro_olx_title,
            'description'     => $mcro_olx_desc,
            'category_id'     => absint( $mcro_olx_category_id ),
            'advertiser_type' => sanitize_text_field( $mcro_olx_options['advertiser_type'] ),
            'external_id'     => (string) $mcro_olx_product->get_id(),
            'contact'         => array(
                'name'  => sanitize_text_field( $mcro_olx_options['contact_name'] ),
                'phone' => sanitize_text_field( $mcro_olx_options['contact_phone'] ),
            ),
            'location'        => array_filter(
                array(
                    'city_id'     => absint( $mcro_olx_options['city_id'] ),
                    'district_id' => ! empty( $mcro_olx_options['district_id'] ) ? absint( $mcro_olx_options['district_id'] ) : null,
                )
            ),
            'images'          => $mcro_olx_images,
            'price'           => array(
                'value'      => $mcro_olx_price,
                'currency'   => sanitize_text_field( $mcro_olx_currency ),
                'negotiable' => false,
                'trade'      => false,
                'budget'     => false,
            ),
            'attributes'      => $this->mcro_olx_category_map->mcro_olx_get_attributes_for_product( $mcro_olx_product->get_id() ),
        );

        return $mcro_olx_payload;
    }

    private function mcro_olx_is_public_image_url( $mcro_olx_image_url ) {
        $mcro_olx_host = wp_parse_url( $mcro_olx_image_url, PHP_URL_HOST );
        if ( ! $mcro_olx_host ) {
            return false;
        }
        $mcro_olx_host = strtolower( $mcro_olx_host );
        if ( 'localhost' === $mcro_olx_host || '.local' === substr( $mcro_olx_host, -6 ) || '.test' === substr( $mcro_olx_host, -5 ) ) {
            return false;
        }
        if ( filter_var( $mcro_olx_host, FILTER_VALIDATE_IP ) ) {
            return ! preg_match( '/^(127\.|10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[0-1])\.)/', $mcro_olx_host );
        }
        return true;
    }
}
