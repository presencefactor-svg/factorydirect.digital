<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class MCRO_OLX_Plugin {
    private static $mcro_olx_instance = null;

    private $mcro_olx_settings;
    private $mcro_olx_category_map;
    private $mcro_olx_product_sync;

    public static function mcro_olx_instance() {
        if ( null === self::$mcro_olx_instance ) {
            self::$mcro_olx_instance = new self();
        }
        return self::$mcro_olx_instance;
    }

    private function __construct() {
        $this->mcro_olx_settings     = new MCRO_OLX_Settings();
        $this->mcro_olx_category_map = new MCRO_OLX_Category_Map();
        $this->mcro_olx_product_sync = new MCRO_OLX_Product_Sync( $this->mcro_olx_settings, $this->mcro_olx_category_map );

        add_action( 'admin_menu', array( $this, 'mcro_olx_admin_menu' ) );
        add_action( 'admin_init', array( $this->mcro_olx_settings, 'mcro_olx_register_settings' ) );
        add_action( 'admin_init', array( $this->mcro_olx_category_map, 'mcro_olx_handle_category_map_save' ) );
        add_action( 'admin_post_mcro_olx_oauth_start', array( $this->mcro_olx_settings, 'mcro_olx_handle_oauth_start' ) );
        add_action( 'admin_post_mcro_olx_oauth_callback', array( $this->mcro_olx_settings, 'mcro_olx_handle_oauth_callback' ) );

        $this->mcro_olx_product_sync->mcro_olx_register_hooks();

        /**
         * Extension hook: keep this free plugin manual-only; add automation in add-ons if needed.
         */
        do_action( 'mcro_olx_lite_loaded', $this );
    }

    public function mcro_olx_admin_menu() {
        add_menu_page(
            esc_html__( 'Marketplace Connector RO for WooCommerce', 'marketplace-connector-ro-for-woocommerce' ),
            esc_html__( 'Marketplace Connector RO for WooCommerce', 'marketplace-connector-ro-for-woocommerce' ),
            'manage_woocommerce',
            'mcro_olx-settings',
            array( $this->mcro_olx_settings, 'mcro_olx_render_settings_page' ),
            'dashicons-store',
            56
        );

        add_submenu_page(
            'mcro_olx-settings',
            esc_html__( 'Category Mapping', 'marketplace-connector-ro-for-woocommerce' ),
            esc_html__( 'Category Mapping', 'marketplace-connector-ro-for-woocommerce' ),
            'manage_woocommerce',
            'mcro_olx-category-map',
            array( $this->mcro_olx_category_map, 'mcro_olx_render_category_map_page' )
        );
    }

    public function mcro_olx_get_product_sync() {
        return $this->mcro_olx_product_sync;
    }

}
