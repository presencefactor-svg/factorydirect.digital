<?php
/**
 * Plugin Name: Marketplace Connector RO for WooCommerce
 * Plugin URI: https://factorydirect.digital/woo/
 * Description: Manual WooCommerce product synchronization with the OLX.ro Partner API v2 for Romania.
 * Version: 1.0.0
 * Author: Factory Direct Multimedia
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: marketplace-connector-ro-for-woocommerce
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * WC requires at least: 7.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'MCRO_OLX_LITE_VERSION', '1.0.0' );
define( 'MCRO_OLX_LITE_FILE', __FILE__ );
define( 'MCRO_OLX_LITE_PATH', plugin_dir_path( __FILE__ ) );
define( 'MCRO_OLX_LITE_URL', plugin_dir_url( __FILE__ ) );

require_once MCRO_OLX_LITE_PATH . 'includes/class-eur-olx-api-client.php';
require_once MCRO_OLX_LITE_PATH . 'includes/class-eur-olx-settings.php';
require_once MCRO_OLX_LITE_PATH . 'includes/class-eur-olx-category-map.php';
require_once MCRO_OLX_LITE_PATH . 'includes/class-eur-olx-product-sync.php';
require_once MCRO_OLX_LITE_PATH . 'includes/class-eur-olx-plugin.php';

/**
 * Bootstrap plugin. Global function is prefixed for WordPress.org compatibility.
 *
 * @return MCRO_OLX_Plugin
 */
function mcro_olx_lite() {
    return MCRO_OLX_Plugin::mcro_olx_instance();
}

add_action( 'plugins_loaded', 'mcro_olx_lite' );
