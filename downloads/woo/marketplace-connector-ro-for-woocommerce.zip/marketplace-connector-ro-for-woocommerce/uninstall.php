<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

$options = get_option( 'mcro_olx_options', array() );
if ( ! is_array( $options ) || empty( $options['cleanup_data'] ) || '1' !== $options['cleanup_data'] ) {
    return;
}

delete_option( 'mcro_olx_options' );
delete_option( 'mcro_olx_category_map' );
delete_option( 'mcro_olx_last_oauth_debug' );
delete_transient( 'mcro_olx_ro_category_suggestions' );

$meta_keys = array( '_mcro_olx_advert_id', '_mcro_olx_status', '_mcro_olx_last_error' );
foreach ( $meta_keys as $meta_key ) {
    delete_post_meta_by_key( $meta_key );
}
wp_clear_scheduled_hook( 'mcro_olx_pro_cron_sync' );
