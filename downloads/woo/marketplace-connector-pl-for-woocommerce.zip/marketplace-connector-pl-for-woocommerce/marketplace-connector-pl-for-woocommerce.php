<?php
/**
 * Plugin Name: Marketplace Connector PL for WooCommerce
 * Plugin URI: https://factorydirect.digital/woo/
 * Description: Manual WooCommerce product synchronization with the OLX.pl Partner API v2 for Poland.
 * Version: 1.0.0
 * Author: Factory Direct Multimedia
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: marketplace-connector-pl-for-woocommerce
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * WC requires at least: 7.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'MCPL_OLX_LITE_VERSION', '1.0.0' );
define( 'MCPL_OLX_LITE_FILE', __FILE__ );
define( 'MCPL_OLX_LITE_PATH', plugin_dir_path( __FILE__ ) );
define( 'MCPL_OLX_LITE_URL', plugin_dir_url( __FILE__ ) );

require_once MCPL_OLX_LITE_PATH . 'includes/class-eur-olx-api-client.php';
require_once MCPL_OLX_LITE_PATH . 'includes/class-eur-olx-settings.php';
require_once MCPL_OLX_LITE_PATH . 'includes/class-eur-olx-category-map.php';
require_once MCPL_OLX_LITE_PATH . 'includes/class-eur-olx-product-sync.php';
require_once MCPL_OLX_LITE_PATH . 'includes/class-eur-olx-plugin.php';

/**
 * Bootstrap plugin. Global function is prefixed for WordPress.org compatibility.
 *
 * @return MCPL_OLX_Plugin
 */
function mcpl_olx_lite() {
    return MCPL_OLX_Plugin::mcpl_olx_instance();
}

add_action( 'plugins_loaded', 'mcpl_olx_lite' );
