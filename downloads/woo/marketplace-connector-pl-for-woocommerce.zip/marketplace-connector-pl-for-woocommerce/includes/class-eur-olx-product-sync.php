<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCPL_OLX_Product_Sync {
    const MCPL_OLX_ADVERT_ID_META = '_mcpl_olx_advert_id';
    const MCPL_OLX_STATUS_META    = '_mcpl_olx_status';
    const MCPL_OLX_LAST_ERROR_META= '_mcpl_olx_last_error';
    const MCPL_OLX_SYNC_NONCE     = 'mcpl_olx_sync_product_nonce_action';

    private $mcpl_olx_settings;
    private $mcpl_olx_category_map;
    private $mcpl_olx_api_client;

    public function __construct( MCPL_OLX_Settings $mcpl_olx_settings, MCPL_OLX_Category_Map $mcpl_olx_category_map ) {
        $this->mcpl_olx_settings     = $mcpl_olx_settings;
        $this->mcpl_olx_category_map = $mcpl_olx_category_map;
        $this->mcpl_olx_api_client   = new MCPL_OLX_API_Client( $mcpl_olx_settings );
    }

    public function mcpl_olx_register_hooks() {
        add_action( 'add_meta_boxes_product', array( $this, 'mcpl_olx_add_product_metabox' ) );
        add_action( 'admin_post_mcpl_olx_sync_product', array( $this, 'mcpl_olx_handle_manual_sync' ) );
        add_filter( 'bulk_actions-edit-product', array( $this, 'mcpl_olx_register_bulk_actions' ) );
        add_filter( 'handle_bulk_actions-edit-product', array( $this, 'mcpl_olx_handle_bulk_actions' ), 10, 3 );
    }

    public function mcpl_olx_add_product_metabox() {
        add_meta_box(
            'mcpl_olx_product_sync',
            esc_html__( 'Marketplace Connector PL Sync', 'marketplace-connector-pl-for-woocommerce' ),
            array( $this, 'mcpl_olx_render_product_metabox' ),
            'product',
            'side',
            'default'
        );
    }

    public function mcpl_olx_render_product_metabox( $mcpl_olx_post ) {
        if ( ! current_user_can( 'edit_product', $mcpl_olx_post->ID ) ) {
            return;
        }
        $mcpl_olx_advert_id = get_post_meta( $mcpl_olx_post->ID, self::MCPL_OLX_ADVERT_ID_META, true );
        $mcpl_olx_status    = get_post_meta( $mcpl_olx_post->ID, self::MCPL_OLX_STATUS_META, true );
        $mcpl_olx_error     = get_post_meta( $mcpl_olx_post->ID, self::MCPL_OLX_LAST_ERROR_META, true );
        $mcpl_olx_url       = wp_nonce_url(
            admin_url( 'admin-post.php?action=mcpl_olx_sync_product&product_id=' . absint( $mcpl_olx_post->ID ) ),
            self::MCPL_OLX_SYNC_NONCE,
            'mcpl_olx_nonce'
        );
        echo '<p><strong>' . esc_html__( 'Advert ID:', 'marketplace-connector-pl-for-woocommerce' ) . '</strong> ' . esc_html( $mcpl_olx_advert_id ? $mcpl_olx_advert_id : '-' ) . '</p>';
        echo '<p><strong>' . esc_html__( 'Status:', 'marketplace-connector-pl-for-woocommerce' ) . '</strong> ' . esc_html( $mcpl_olx_status ? $mcpl_olx_status : '-' ) . '</p>';
        if ( $mcpl_olx_error ) {
            echo '<p class="description" style="color:#b32d2e;">' . esc_html( $mcpl_olx_error ) . '</p>';
        }
        echo '<p><a class="button button-primary" href="' . esc_url( $mcpl_olx_url ) . '">' . esc_html__( 'Sync to OLX', 'marketplace-connector-pl-for-woocommerce' ) . '</a></p>';
    }

    public function mcpl_olx_handle_manual_sync() {
        $mcpl_olx_product_id = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0;
        if ( ! $mcpl_olx_product_id || ! current_user_can( 'edit_product', $mcpl_olx_product_id ) ) {
            wp_die( esc_html__( 'You do not have permission to sync this product.', 'marketplace-connector-pl-for-woocommerce' ) );
        }
        check_admin_referer( self::MCPL_OLX_SYNC_NONCE, 'mcpl_olx_nonce' );

        $mcpl_olx_result = $this->mcpl_olx_sync_product( $mcpl_olx_product_id );
        $mcpl_olx_args   = is_wp_error( $mcpl_olx_result )
            ? array( 'mcpl_olx_error' => rawurlencode( $mcpl_olx_result->get_error_message() ) )
            : array( 'mcpl_olx_message' => rawurlencode( esc_html__( 'Product synced to OLX.pl.', 'marketplace-connector-pl-for-woocommerce' ) ) );

        wp_safe_redirect( add_query_arg( $mcpl_olx_args, get_edit_post_link( $mcpl_olx_product_id, 'url' ) ) );
        exit;
    }

    public function mcpl_olx_register_bulk_actions( $mcpl_olx_actions ) {
        $mcpl_olx_actions['mcpl_olx_bulk_sync'] = esc_html__( 'Sync to Marketplace Connector PL', 'marketplace-connector-pl-for-woocommerce' );
        return $mcpl_olx_actions;
    }

    public function mcpl_olx_handle_bulk_actions( $mcpl_olx_redirect, $mcpl_olx_action, $mcpl_olx_product_ids ) {
        if ( 'mcpl_olx_bulk_sync' !== $mcpl_olx_action ) {
            return $mcpl_olx_redirect;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return $mcpl_olx_redirect;
        }
        // WordPress core verifies the bulk action nonce before this filter is called.
        $mcpl_olx_success = 0;
        $mcpl_olx_failed  = 0;
        foreach ( array_map( 'absint', (array) $mcpl_olx_product_ids ) as $mcpl_olx_product_id ) {
            $mcpl_olx_result = $this->mcpl_olx_sync_product( $mcpl_olx_product_id );
            is_wp_error( $mcpl_olx_result ) ? $mcpl_olx_failed++ : $mcpl_olx_success++;
        }
        return add_query_arg( array( 'mcpl_olx_success' => $mcpl_olx_success, 'mcpl_olx_failed' => $mcpl_olx_failed ), $mcpl_olx_redirect );
    }

    public function mcpl_olx_sync_product( $mcpl_olx_product_id ) {
        if ( ! function_exists( 'wc_get_product' ) ) {
            return new WP_Error( 'mcpl_olx_missing_wc', esc_html__( 'WooCommerce is not active.', 'marketplace-connector-pl-for-woocommerce' ) );
        }

        $mcpl_olx_product = wc_get_product( absint( $mcpl_olx_product_id ) );
        if ( ! $mcpl_olx_product ) {
            return new WP_Error( 'mcpl_olx_missing_product', esc_html__( 'Product not found.', 'marketplace-connector-pl-for-woocommerce' ) );
        }

        $mcpl_olx_payload = $this->mcpl_olx_build_advert_payload( $mcpl_olx_product );
        if ( is_wp_error( $mcpl_olx_payload ) ) {
            return $mcpl_olx_payload;
        }

        /** Hook for PRO/custom payload changes: variations, custom attributes, GPS, delivery, safety regulations. */
        $mcpl_olx_payload = apply_filters( 'mcpl_olx_advert_payload', $mcpl_olx_payload, $mcpl_olx_product );
        do_action( 'mcpl_olx_before_manual_sync', $mcpl_olx_product->get_id(), $mcpl_olx_payload );

        $mcpl_olx_existing_advert_id = get_post_meta( $mcpl_olx_product->get_id(), self::MCPL_OLX_ADVERT_ID_META, true );
        $mcpl_olx_response = $mcpl_olx_existing_advert_id ? $this->mcpl_olx_api_client->mcpl_olx_update_v2_advert( $mcpl_olx_existing_advert_id, $mcpl_olx_payload ) : $this->mcpl_olx_api_client->mcpl_olx_post_v2_advert( $mcpl_olx_payload );
        if ( is_wp_error( $mcpl_olx_response ) ) {
            update_post_meta( $mcpl_olx_product->get_id(), self::MCPL_OLX_LAST_ERROR_META, sanitize_text_field( $mcpl_olx_response->get_error_message() ) );
            return $mcpl_olx_response;
        }

        if ( isset( $mcpl_olx_response['id'] ) ) {
            update_post_meta( $mcpl_olx_product->get_id(), self::MCPL_OLX_ADVERT_ID_META, absint( $mcpl_olx_response['id'] ) );
        }
        if ( isset( $mcpl_olx_response['status'] ) ) {
            update_post_meta( $mcpl_olx_product->get_id(), self::MCPL_OLX_STATUS_META, sanitize_text_field( $mcpl_olx_response['status'] ) );
        }
        delete_post_meta( $mcpl_olx_product->get_id(), self::MCPL_OLX_LAST_ERROR_META );
        do_action( 'mcpl_olx_after_manual_sync', $mcpl_olx_product->get_id(), $mcpl_olx_response );

        return $mcpl_olx_response;
    }

    private function mcpl_olx_build_advert_payload( WC_Product $mcpl_olx_product ) {
        $mcpl_olx_options     = $this->mcpl_olx_settings->mcpl_olx_get_options();
        $mcpl_olx_market      = $this->mcpl_olx_settings->mcpl_olx_get_market_config( $mcpl_olx_options['market'] );
        $mcpl_olx_category_id = $this->mcpl_olx_category_map->mcpl_olx_get_olx_category_id_for_product( $mcpl_olx_product->get_id() );

        if ( ! $mcpl_olx_category_id ) {
            return new WP_Error( 'mcpl_olx_missing_category', esc_html__( 'Missing OLX category mapping for this product.', 'marketplace-connector-pl-for-woocommerce' ) );
        }
        if ( empty( $mcpl_olx_options['city_id'] ) || empty( $mcpl_olx_options['contact_name'] ) ) {
            return new WP_Error( 'mcpl_olx_missing_required_settings', esc_html__( 'Missing default city ID or contact name in Marketplace Connector PL settings.', 'marketplace-connector-pl-for-woocommerce' ) );
        }

        $mcpl_olx_title = sanitize_text_field( wp_strip_all_tags( $mcpl_olx_product->get_name() ) );
        $mcpl_olx_desc  = wp_kses_post( $mcpl_olx_product->get_description() ? $mcpl_olx_product->get_description() : $mcpl_olx_product->get_short_description() );
        $mcpl_olx_price = (float) wc_get_price_to_display( $mcpl_olx_product );
        $mcpl_olx_currency = $mcpl_olx_options['currency'] ? $mcpl_olx_options['currency'] : $mcpl_olx_market['currency'];

        $mcpl_olx_images = array();
        $mcpl_olx_image_ids = array_filter( array_unique( array_merge( array( $mcpl_olx_product->get_image_id() ), $mcpl_olx_product->get_gallery_image_ids() ) ) );
        foreach ( array_slice( $mcpl_olx_image_ids, 0, 8 ) as $mcpl_olx_image_id ) {
            $mcpl_olx_image_url = wp_get_attachment_url( absint( $mcpl_olx_image_id ) );
            if ( $mcpl_olx_image_url && $this->mcpl_olx_is_public_image_url( $mcpl_olx_image_url ) ) {
                $mcpl_olx_images[] = array( 'url' => esc_url_raw( $mcpl_olx_image_url ) );
            }
        }

        $mcpl_olx_payload = array(
            'title'           => $mcpl_olx_title,
            'description'     => $mcpl_olx_desc,
            'category_id'     => absint( $mcpl_olx_category_id ),
            'advertiser_type' => sanitize_text_field( $mcpl_olx_options['advertiser_type'] ),
            'external_id'     => (string) $mcpl_olx_product->get_id(),
            'contact'         => array(
                'name'  => sanitize_text_field( $mcpl_olx_options['contact_name'] ),
                'phone' => sanitize_text_field( $mcpl_olx_options['contact_phone'] ),
            ),
            'location'        => array_filter(
                array(
                    'city_id'     => absint( $mcpl_olx_options['city_id'] ),
                    'district_id' => ! empty( $mcpl_olx_options['district_id'] ) ? absint( $mcpl_olx_options['district_id'] ) : null,
                )
            ),
            'images'          => $mcpl_olx_images,
            'price'           => array(
                'value'      => $mcpl_olx_price,
                'currency'   => sanitize_text_field( $mcpl_olx_currency ),
                'negotiable' => false,
                'trade'      => false,
                'budget'     => false,
            ),
            'attributes'      => $this->mcpl_olx_category_map->mcpl_olx_get_attributes_for_product( $mcpl_olx_product->get_id() ),
        );

        return $mcpl_olx_payload;
    }

    private function mcpl_olx_is_public_image_url( $mcpl_olx_image_url ) {
        $mcpl_olx_host = wp_parse_url( $mcpl_olx_image_url, PHP_URL_HOST );
        if ( ! $mcpl_olx_host ) {
            return false;
        }
        $mcpl_olx_host = strtolower( $mcpl_olx_host );
        if ( 'localhost' === $mcpl_olx_host || '.local' === substr( $mcpl_olx_host, -6 ) || '.test' === substr( $mcpl_olx_host, -5 ) ) {
            return false;
        }
        if ( filter_var( $mcpl_olx_host, FILTER_VALIDATE_IP ) ) {
            return ! preg_match( '/^(127\.|10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[0-1])\.)/', $mcpl_olx_host );
        }
        return true;
    }
}
