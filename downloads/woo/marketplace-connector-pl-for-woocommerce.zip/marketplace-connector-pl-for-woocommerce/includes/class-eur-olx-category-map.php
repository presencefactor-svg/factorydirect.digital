<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCPL_OLX_Category_Map {
    const MCPL_OLX_CATEGORY_MAP_OPTION = 'mcpl_olx_category_map';
    const MCPL_OLX_CATEGORY_MAP_NONCE = 'mcpl_olx_category_map_nonce_action';

    public function mcpl_olx_get_map() {
        $mcpl_olx_map = get_option( self::MCPL_OLX_CATEGORY_MAP_OPTION, array() );
        return is_array( $mcpl_olx_map ) ? $mcpl_olx_map : array();
    }

    public function mcpl_olx_get_mapping_for_product( $mcpl_olx_product_id ) {
        $mcpl_olx_map   = $this->mcpl_olx_get_map();
        $mcpl_olx_terms = wp_get_post_terms( absint( $mcpl_olx_product_id ), 'product_cat' );
        if ( is_wp_error( $mcpl_olx_terms ) ) {
            return array();
        }
        foreach ( $mcpl_olx_terms as $mcpl_olx_term ) {
            $mcpl_olx_term_id = (string) absint( $mcpl_olx_term->term_id );
            if ( empty( $mcpl_olx_map[ $mcpl_olx_term_id ] ) ) {
                continue;
            }
            if ( is_array( $mcpl_olx_map[ $mcpl_olx_term_id ] ) ) {
                return $mcpl_olx_map[ $mcpl_olx_term_id ];
            }
            return array( 'category_id' => absint( $mcpl_olx_map[ $mcpl_olx_term_id ] ) );
        }
        return array();
    }

    public function mcpl_olx_get_olx_category_id_for_product( $mcpl_olx_product_id ) {
        $mcpl_olx_mapping = $this->mcpl_olx_get_mapping_for_product( $mcpl_olx_product_id );
        return ! empty( $mcpl_olx_mapping['category_id'] ) ? absint( $mcpl_olx_mapping['category_id'] ) : '';
    }

    public function mcpl_olx_get_attributes_for_product( $mcpl_olx_product_id ) {
        $mcpl_olx_mapping    = $this->mcpl_olx_get_mapping_for_product( $mcpl_olx_product_id );
        $mcpl_olx_attributes = array();
        $mcpl_olx_state      = ! empty( $mcpl_olx_mapping['state'] ) ? sanitize_key( $mcpl_olx_mapping['state'] ) : 'new';
        if ( $mcpl_olx_state ) {
            $mcpl_olx_attributes[] = array( 'code' => 'state', 'value' => $mcpl_olx_state );
        }
        if ( ! empty( $mcpl_olx_mapping['attributes'] ) && is_array( $mcpl_olx_mapping['attributes'] ) ) {
            foreach ( $mcpl_olx_mapping['attributes'] as $mcpl_olx_attribute ) {
                if ( empty( $mcpl_olx_attribute['code'] ) || ! isset( $mcpl_olx_attribute['value'] ) ) {
                    continue;
                }
                $mcpl_olx_code  = sanitize_key( $mcpl_olx_attribute['code'] );
                $mcpl_olx_value = sanitize_text_field( (string) $mcpl_olx_attribute['value'] );
                if ( $mcpl_olx_code && '' !== $mcpl_olx_value ) {
                    $mcpl_olx_attributes[] = array( 'code' => $mcpl_olx_code, 'value' => $mcpl_olx_value );
                }
            }
        }
        return $this->mcpl_olx_dedupe_attributes( $mcpl_olx_attributes );
    }

    public function mcpl_olx_handle_category_map_save() {
        if ( empty( $_POST['mcpl_olx_category_map_submit'] ) ) {
            return;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to save category mapping.', 'marketplace-connector-pl-for-woocommerce' ) );
        }
        check_admin_referer( self::MCPL_OLX_CATEGORY_MAP_NONCE, 'mcpl_olx_category_map_nonce' );

        $mcpl_olx_raw_map = isset( $_POST['mcpl_olx_category_map'] ) && is_array( $_POST['mcpl_olx_category_map'] ) ? map_deep( wp_unslash( $_POST['mcpl_olx_category_map'] ), 'sanitize_text_field' ) : array();
        $mcpl_olx_clean   = array();
        foreach ( $mcpl_olx_raw_map as $mcpl_olx_woo_cat_id => $mcpl_olx_row ) {
            $mcpl_olx_woo_cat_id = absint( $mcpl_olx_woo_cat_id );
            if ( ! $mcpl_olx_woo_cat_id || ! is_array( $mcpl_olx_row ) ) {
                continue;
            }
            $mcpl_olx_olx_cat_id = ! empty( $mcpl_olx_row['category_id'] ) ? absint( $mcpl_olx_row['category_id'] ) : 0;
            if ( ! $mcpl_olx_olx_cat_id ) {
                continue;
            }
            $mcpl_olx_clean[ (string) $mcpl_olx_woo_cat_id ] = array(
                'category_id'   => $mcpl_olx_olx_cat_id,
                'category_path' => isset( $mcpl_olx_row['category_path'] ) ? sanitize_text_field( $mcpl_olx_row['category_path'] ) : '',
                'state'         => isset( $mcpl_olx_row['state'] ) ? sanitize_key( $mcpl_olx_row['state'] ) : 'new',
                'attributes'    => $this->mcpl_olx_parse_attribute_lines( isset( $mcpl_olx_row['attributes'] ) ? (string) $mcpl_olx_row['attributes'] : '' ),
            );
        }
        update_option( self::MCPL_OLX_CATEGORY_MAP_OPTION, $mcpl_olx_clean, false );
        add_settings_error( 'mcpl_olx_category_map', 'mcpl_olx_category_map_saved', esc_html__( 'Category mapping saved.', 'marketplace-connector-pl-for-woocommerce' ), 'updated' );
    }

    public function mcpl_olx_render_category_map_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'marketplace-connector-pl-for-woocommerce' ) );
        }
        $mcpl_olx_map        = $this->mcpl_olx_get_map();
        $mcpl_olx_categories = $this->mcpl_olx_get_pl_category_suggestions();
        $mcpl_olx_terms      = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Marketplace Connector PL Category Mapping', 'marketplace-connector-pl-for-woocommerce' ); ?></h1>
            <p class="description"><?php echo esc_html__( 'Map WooCommerce categories to OLX.pl category IDs and define required category attributes such as condition/state. Category ID fields include live OLX.pl API suggestions when OAuth is connected. Additional attributes use one code=value pair per line, for example brand=Samsung.', 'marketplace-connector-pl-for-woocommerce' ); ?></p>
            <?php if ( ! empty( $mcpl_olx_categories ) ) : ?>
                <datalist id="mcpl_olx_pl_categories">
                    <?php foreach ( $mcpl_olx_categories as $mcpl_olx_category ) : ?>
                        <option value="<?php echo esc_attr( $mcpl_olx_category['id'] ); ?>" label="<?php echo esc_attr( $mcpl_olx_category['name'] ); ?>"></option>
                    <?php endforeach; ?>
                </datalist>
            <?php endif; ?>
            <?php settings_errors( 'mcpl_olx_category_map' ); ?>
            <form method="post">
                <?php wp_nonce_field( self::MCPL_OLX_CATEGORY_MAP_NONCE, 'mcpl_olx_category_map_nonce' ); ?>
                <input type="hidden" name="mcpl_olx_category_map_submit" value="1">
                <table class="widefat striped">
                    <thead><tr><th><?php echo esc_html__( 'WooCommerce category', 'marketplace-connector-pl-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'OLX.pl category ID', 'marketplace-connector-pl-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Category note/path', 'marketplace-connector-pl-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Condition', 'marketplace-connector-pl-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Extra attributes', 'marketplace-connector-pl-for-woocommerce' ); ?></th></tr></thead>
                    <tbody>
                    <?php if ( ! is_wp_error( $mcpl_olx_terms ) ) : ?>
                        <?php foreach ( $mcpl_olx_terms as $mcpl_olx_term ) : ?>
                            <?php
                            $mcpl_olx_row = isset( $mcpl_olx_map[ (string) $mcpl_olx_term->term_id ] ) ? $mcpl_olx_map[ (string) $mcpl_olx_term->term_id ] : array();
                            if ( ! is_array( $mcpl_olx_row ) ) {
                                $mcpl_olx_row = array( 'category_id' => absint( $mcpl_olx_row ) );
                            }
                            $mcpl_olx_value = ! empty( $mcpl_olx_row['category_id'] ) ? absint( $mcpl_olx_row['category_id'] ) : '';
                            $mcpl_olx_state = ! empty( $mcpl_olx_row['state'] ) ? sanitize_key( $mcpl_olx_row['state'] ) : 'new';
                            ?>
                            <tr>
                                <td><?php echo esc_html( $mcpl_olx_term->name ); ?></td>
                                <td><input type="number" min="1" list="mcpl_olx_pl_categories" name="mcpl_olx_category_map[<?php echo esc_attr( $mcpl_olx_term->term_id ); ?>][category_id]" value="<?php echo esc_attr( $mcpl_olx_value ); ?>" class="small-text"></td>
                                <td><input type="text" name="mcpl_olx_category_map[<?php echo esc_attr( $mcpl_olx_term->term_id ); ?>][category_path]" value="<?php echo esc_attr( isset( $mcpl_olx_row['category_path'] ) ? $mcpl_olx_row['category_path'] : '' ); ?>" class="regular-text" placeholder="<?php echo esc_attr__( 'e.g. Home / Lighting', 'marketplace-connector-pl-for-woocommerce' ); ?>"></td>
                                <td><select name="mcpl_olx_category_map[<?php echo esc_attr( $mcpl_olx_term->term_id ); ?>][state]"><option value="new" <?php selected( $mcpl_olx_state, 'new' ); ?>><?php echo esc_html__( 'New', 'marketplace-connector-pl-for-woocommerce' ); ?></option><option value="used" <?php selected( $mcpl_olx_state, 'used' ); ?>><?php echo esc_html__( 'Used', 'marketplace-connector-pl-for-woocommerce' ); ?></option></select></td>
                                <td><textarea rows="3" cols="32" name="mcpl_olx_category_map[<?php echo esc_attr( $mcpl_olx_term->term_id ); ?>][attributes]" placeholder="brand=Samsung&#10;model=A54"><?php echo esc_textarea( $this->mcpl_olx_format_attribute_lines( isset( $mcpl_olx_row['attributes'] ) && is_array( $mcpl_olx_row['attributes'] ) ? $mcpl_olx_row['attributes'] : array() ) ); ?></textarea></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
                <?php submit_button( esc_html__( 'Save mapping', 'marketplace-connector-pl-for-woocommerce' ) ); ?>
            </form>
        </div>
        <?php
    }


    private function mcpl_olx_get_pl_category_suggestions() {
        $mcpl_olx_cached = get_transient( 'mcpl_olx_pl_category_suggestions' );
        if ( is_array( $mcpl_olx_cached ) ) {
            return $mcpl_olx_cached;
        }
        $mcpl_olx_options = get_option( 'mcpl_olx_options', array() );
        if ( empty( $mcpl_olx_options['access_token'] ) ) {
            return array();
        }
        $mcpl_olx_response = wp_remote_get(
            'https://www.olx.pl/api/partner/categories?limit=1000',
            array(
                'timeout' => 20,
                'headers' => array(
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer ' . $mcpl_olx_options['access_token'],
                    'Version'       => '2.0',
                ),
            )
        );
        if ( is_wp_error( $mcpl_olx_response ) || 200 !== (int) wp_remote_retrieve_response_code( $mcpl_olx_response ) ) {
            return array();
        }
        $mcpl_olx_json = json_decode( (string) wp_remote_retrieve_body( $mcpl_olx_response ), true );
        $mcpl_olx_rows = isset( $mcpl_olx_json['data'] ) && is_array( $mcpl_olx_json['data'] ) ? $mcpl_olx_json['data'] : array();
        $mcpl_olx_categories = array();
        foreach ( $mcpl_olx_rows as $mcpl_olx_row ) {
            if ( empty( $mcpl_olx_row['id'] ) || empty( $mcpl_olx_row['name'] ) ) {
                continue;
            }
            $mcpl_olx_categories[] = array(
                'id'   => absint( $mcpl_olx_row['id'] ),
                'name' => sanitize_text_field( (string) $mcpl_olx_row['name'] ),
            );
        }
        set_transient( 'mcpl_olx_pl_category_suggestions', $mcpl_olx_categories, DAY_IN_SECONDS );
        return $mcpl_olx_categories;
    }

    private function mcpl_olx_parse_attribute_lines( $mcpl_olx_raw ) {
        $mcpl_olx_attributes = array();
        foreach ( preg_split( '/\r\n|\r|\n/', (string) $mcpl_olx_raw ) as $mcpl_olx_line ) {
            $mcpl_olx_line = trim( $mcpl_olx_line );
            if ( '' === $mcpl_olx_line || false === strpos( $mcpl_olx_line, '=' ) ) {
                continue;
            }
            list( $mcpl_olx_code, $mcpl_olx_value ) = array_map( 'trim', explode( '=', $mcpl_olx_line, 2 ) );
            $mcpl_olx_code  = sanitize_key( $mcpl_olx_code );
            $mcpl_olx_value = sanitize_text_field( $mcpl_olx_value );
            if ( $mcpl_olx_code && '' !== $mcpl_olx_value ) {
                $mcpl_olx_attributes[] = array( 'code' => $mcpl_olx_code, 'value' => $mcpl_olx_value );
            }
        }
        return $this->mcpl_olx_dedupe_attributes( $mcpl_olx_attributes );
    }

    private function mcpl_olx_format_attribute_lines( array $mcpl_olx_attributes ) {
        $mcpl_olx_lines = array();
        foreach ( $mcpl_olx_attributes as $mcpl_olx_attribute ) {
            if ( ! empty( $mcpl_olx_attribute['code'] ) && isset( $mcpl_olx_attribute['value'] ) ) {
                $mcpl_olx_lines[] = sanitize_key( $mcpl_olx_attribute['code'] ) . '=' . sanitize_text_field( (string) $mcpl_olx_attribute['value'] );
            }
        }
        return implode( "\n", $mcpl_olx_lines );
    }

    private function mcpl_olx_dedupe_attributes( array $mcpl_olx_attributes ) {
        $mcpl_olx_seen = array();
        $mcpl_olx_clean = array();
        foreach ( $mcpl_olx_attributes as $mcpl_olx_attribute ) {
            if ( empty( $mcpl_olx_attribute['code'] ) || ! isset( $mcpl_olx_attribute['value'] ) ) {
                continue;
            }
            $mcpl_olx_code = sanitize_key( $mcpl_olx_attribute['code'] );
            if ( ! $mcpl_olx_code || isset( $mcpl_olx_seen[ $mcpl_olx_code ] ) ) {
                continue;
            }
            $mcpl_olx_seen[ $mcpl_olx_code ] = true;
            $mcpl_olx_clean[] = array( 'code' => $mcpl_olx_code, 'value' => sanitize_text_field( (string) $mcpl_olx_attribute['value'] ) );
        }
        return $mcpl_olx_clean;
    }
}
