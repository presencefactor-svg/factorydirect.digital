<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCPL_OLX_API_Client {
    private $mcpl_olx_settings;

    public function __construct( MCPL_OLX_Settings $mcpl_olx_settings ) {
        $this->mcpl_olx_settings = $mcpl_olx_settings;
    }

    public function mcpl_olx_request( $mcpl_olx_method, $mcpl_olx_path, $mcpl_olx_body = null ) {
        $mcpl_olx_options = $this->mcpl_olx_settings->mcpl_olx_get_options();
        if ( ( empty( $mcpl_olx_options['access_token'] ) && ! empty( $mcpl_olx_options['refresh_token'] ) ) || ( ! empty( $mcpl_olx_options['token_expires_at'] ) && absint( $mcpl_olx_options['token_expires_at'] ) < time() + 120 ) ) {
            $mcpl_olx_refreshed = $this->mcpl_olx_refresh_access_token();
            if ( ! is_wp_error( $mcpl_olx_refreshed ) ) {
                $mcpl_olx_options = $this->mcpl_olx_settings->mcpl_olx_get_options();
            }
        }

        $mcpl_olx_market = $this->mcpl_olx_settings->mcpl_olx_get_market_config( $mcpl_olx_options['market'] );
        $mcpl_olx_token  = trim( (string) $mcpl_olx_options['access_token'] );

        if ( '' === $mcpl_olx_token ) {
            return new WP_Error( 'mcpl_olx_missing_token', esc_html__( 'Missing OAuth access token.', 'marketplace-connector-pl-for-woocommerce' ) );
        }

        $mcpl_olx_url = trailingslashit( $mcpl_olx_market['base_url'] ) . ltrim( $mcpl_olx_path, '/' );
        $mcpl_olx_args = array(
            'method'  => strtoupper( sanitize_key( $mcpl_olx_method ) ),
            'timeout' => 45,
            'headers' => array(
                'Accept'        => 'application/json',
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $mcpl_olx_token,
                'Version'       => '2.0',
            ),
        );

        if ( null !== $mcpl_olx_body ) {
            $mcpl_olx_args['body'] = wp_json_encode( $mcpl_olx_body );
        }

        $mcpl_olx_args = apply_filters( 'mcpl_olx_api_request_args', $mcpl_olx_args, $mcpl_olx_path, $mcpl_olx_body );
        $mcpl_olx_response = wp_remote_request( esc_url_raw( $mcpl_olx_url ), $mcpl_olx_args );
        return $this->mcpl_olx_parse_response( $mcpl_olx_response );
    }

    public function mcpl_olx_post_v2_advert( array $mcpl_olx_payload ) {
        return $this->mcpl_olx_request( 'POST', '/adverts', $mcpl_olx_payload );
    }

    public function mcpl_olx_update_v2_advert( $mcpl_olx_advert_id, array $mcpl_olx_payload ) {
        return $this->mcpl_olx_request( 'PUT', '/adverts/' . absint( $mcpl_olx_advert_id ), $mcpl_olx_payload );
    }

    public function mcpl_olx_refresh_access_token() {
        $mcpl_olx_options = $this->mcpl_olx_settings->mcpl_olx_get_options();
        if ( empty( $mcpl_olx_options['client_id'] ) || empty( $mcpl_olx_options['client_secret'] ) || empty( $mcpl_olx_options['refresh_token'] ) ) {
            return new WP_Error( 'mcpl_olx_refresh_missing_credentials', esc_html__( 'Missing OAuth refresh credentials.', 'marketplace-connector-pl-for-woocommerce' ) );
        }

        $mcpl_olx_market = $this->mcpl_olx_settings->mcpl_olx_get_market_config( $mcpl_olx_options['market'] );
        $mcpl_olx_response = wp_remote_post(
            esc_url_raw( $mcpl_olx_market['token_url'] ),
            array(
                'timeout' => 45,
                'headers' => array( 'Accept' => 'application/json' ),
                'body'    => array(
                    'grant_type'    => 'refresh_token',
                    'client_id'     => $mcpl_olx_options['client_id'],
                    'client_secret' => $mcpl_olx_options['client_secret'],
                    'refresh_token' => $mcpl_olx_options['refresh_token'],
                ),
            )
        );

        $mcpl_olx_json = $this->mcpl_olx_parse_response( $mcpl_olx_response );
        if ( is_wp_error( $mcpl_olx_json ) ) {
            return $mcpl_olx_json;
        }
        $this->mcpl_olx_settings->mcpl_olx_save_tokens_from_response( $mcpl_olx_json );
        return $mcpl_olx_json;
    }

    private function mcpl_olx_parse_response( $mcpl_olx_response ) {
        if ( is_wp_error( $mcpl_olx_response ) ) {
            return $mcpl_olx_response;
        }
        $mcpl_olx_code = (int) wp_remote_retrieve_response_code( $mcpl_olx_response );
        $mcpl_olx_raw  = (string) wp_remote_retrieve_body( $mcpl_olx_response );
        $mcpl_olx_json = json_decode( $mcpl_olx_raw, true );
        if ( $mcpl_olx_code < 200 || $mcpl_olx_code >= 300 ) {
            return new WP_Error(
                'mcpl_olx_api_error',
                sprintf(
                    /* translators: 1: HTTP status code, 2: response body */
                    esc_html__( 'OLX API error %1$d: %2$s', 'marketplace-connector-pl-for-woocommerce' ),
                    $mcpl_olx_code,
                    is_array( $mcpl_olx_json ) ? wp_json_encode( $mcpl_olx_json ) : $mcpl_olx_raw
                )
            );
        }
        if ( is_array( $mcpl_olx_json ) && array_key_exists( 'data', $mcpl_olx_json ) ) {
            return is_array( $mcpl_olx_json['data'] ) ? $mcpl_olx_json['data'] : array( 'data' => $mcpl_olx_json['data'] );
        }
        return is_array( $mcpl_olx_json ) ? $mcpl_olx_json : array( 'raw' => $mcpl_olx_raw );
    }
}
