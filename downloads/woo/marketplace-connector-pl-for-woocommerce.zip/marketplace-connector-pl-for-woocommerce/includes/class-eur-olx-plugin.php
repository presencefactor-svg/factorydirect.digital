<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class MCPL_OLX_Plugin {
    private static $mcpl_olx_instance = null;

    private $mcpl_olx_settings;
    private $mcpl_olx_category_map;
    private $mcpl_olx_product_sync;

    public static function mcpl_olx_instance() {
        if ( null === self::$mcpl_olx_instance ) {
            self::$mcpl_olx_instance = new self();
        }
        return self::$mcpl_olx_instance;
    }

    private function __construct() {
        $this->mcpl_olx_settings     = new MCPL_OLX_Settings();
        $this->mcpl_olx_category_map = new MCPL_OLX_Category_Map();
        $this->mcpl_olx_product_sync = new MCPL_OLX_Product_Sync( $this->mcpl_olx_settings, $this->mcpl_olx_category_map );

        add_action( 'admin_menu', array( $this, 'mcpl_olx_admin_menu' ) );
        add_action( 'admin_init', array( $this->mcpl_olx_settings, 'mcpl_olx_register_settings' ) );
        add_action( 'admin_init', array( $this->mcpl_olx_category_map, 'mcpl_olx_handle_category_map_save' ) );
        add_action( 'admin_post_mcpl_olx_oauth_start', array( $this->mcpl_olx_settings, 'mcpl_olx_handle_oauth_start' ) );
        add_action( 'admin_post_mcpl_olx_oauth_callback', array( $this->mcpl_olx_settings, 'mcpl_olx_handle_oauth_callback' ) );

        $this->mcpl_olx_product_sync->mcpl_olx_register_hooks();

        /**
         * Extension hook: keep this free plugin manual-only; add automation in add-ons if needed.
         */
        do_action( 'mcpl_olx_lite_loaded', $this );
    }

    public function mcpl_olx_admin_menu() {
        add_menu_page(
            esc_html__( 'Marketplace Connector PL for WooCommerce', 'marketplace-connector-pl-for-woocommerce' ),
            esc_html__( 'Marketplace Connector PL for WooCommerce', 'marketplace-connector-pl-for-woocommerce' ),
            'manage_woocommerce',
            'mcpl_olx-settings',
            array( $this->mcpl_olx_settings, 'mcpl_olx_render_settings_page' ),
            'dashicons-store',
            56
        );

        add_submenu_page(
            'mcpl_olx-settings',
            esc_html__( 'Category Mapping', 'marketplace-connector-pl-for-woocommerce' ),
            esc_html__( 'Category Mapping', 'marketplace-connector-pl-for-woocommerce' ),
            'manage_woocommerce',
            'mcpl_olx-category-map',
            array( $this->mcpl_olx_category_map, 'mcpl_olx_render_category_map_page' )
        );
    }

    public function mcpl_olx_get_product_sync() {
        return $this->mcpl_olx_product_sync;
    }

}
