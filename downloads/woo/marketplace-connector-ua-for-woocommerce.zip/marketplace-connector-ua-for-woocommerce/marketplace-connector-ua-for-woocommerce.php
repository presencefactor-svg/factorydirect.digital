<?php
/**
 * Plugin Name: Marketplace Connector UA for WooCommerce
 * Plugin URI: https://factorydirect.digital/woo/
 * Description: Manual WooCommerce product synchronization with the OLX.ua Partner API v2 for Ukraine.
 * Version: 1.0.0
 * Author: Factory Direct Multimedia
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: marketplace-connector-ua-for-woocommerce
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * WC requires at least: 7.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'MCUA_OLX_LITE_VERSION', '1.0.0' );
define( 'MCUA_OLX_LITE_FILE', __FILE__ );
define( 'MCUA_OLX_LITE_PATH', plugin_dir_path( __FILE__ ) );
define( 'MCUA_OLX_LITE_URL', plugin_dir_url( __FILE__ ) );

require_once MCUA_OLX_LITE_PATH . 'includes/class-eur-olx-api-client.php';
require_once MCUA_OLX_LITE_PATH . 'includes/class-eur-olx-settings.php';
require_once MCUA_OLX_LITE_PATH . 'includes/class-eur-olx-category-map.php';
require_once MCUA_OLX_LITE_PATH . 'includes/class-eur-olx-product-sync.php';
require_once MCUA_OLX_LITE_PATH . 'includes/class-eur-olx-plugin.php';

/**
 * Bootstrap plugin. Global function is prefixed for WordPress.org compatibility.
 *
 * @return MCUA_OLX_Plugin
 */
function mcua_olx_lite() {
    return MCUA_OLX_Plugin::mcua_olx_instance();
}

add_action( 'plugins_loaded', 'mcua_olx_lite' );
