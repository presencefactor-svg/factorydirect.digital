=== Marketplace Connector UA for WooCommerce ===
Contributors: factorydirectmultimedia
Tags: woocommerce, olx, ukraine, ecommerce, marketplace
Requires at least: 6.0
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Manual WooCommerce product synchronization with the OLX.ua Partner API v2 for Ukraine.

== Description ==

Marketplace Connector UA for WooCommerce lets store administrators manually send WooCommerce product data to the OLX.ua marketplace.

This plugin is not affiliated with, endorsed by, or sponsored by OLX Group.

Features:
* OAuth 2.0 authorization-code connection flow with Bearer token API requests.
* Market-based OLX.ua Partner API v2 base URLs.
* Client ID and Client Secret settings.
* Basic WooCommerce category to OLX category ID mapping.
* Manual product sync from the product edit screen.
* Bulk manual sync action from the WooCommerce Products list.
* Developer hooks for custom payload attributes, validation, logging and future extensions.

== External Services ==

This plugin connects to OLX.ua Partner API to create adverts from WooCommerce products.

When a store administrator clicks manual sync or uses the bulk sync action, this plugin may send the following product/store data to the OLX.ua marketplace: product title, description, price, currency, WooCommerce product URL, category mapping, location identifiers, contact name, contact phone number and image URLs.

The plugin uses the OLX.ua API endpoint https://www.olx.ua/api/partner with the OLX Partner API v2 `Version: 2.0` header and OAuth bearer authorization.

Service provider: OLX Group
API documentation: https://developer.olx.ua/api/doc
OLX Group privacy statement: https://www.olxgroup.com/privacy-statement/
OLX Group terms of use: https://www.olxgroup.com/terms-of-use-2/

== Privacy ==

No product data is sent automatically by this free version. Data is sent only when an authorized store administrator starts a manual product sync or bulk sync action. OAuth tokens are stored in WordPress options and are used only for OLX API requests.

== Security ==

All persistent options use the `mcua_olx_` prefix. Admin forms use nonces and capability checks. Saved input is sanitized and admin output is escaped using WordPress APIs.

== Uninstall ==

By default, plugin data is preserved on uninstall to avoid losing OLX advert IDs and mappings. Administrators can enable the "Remove plugin data on uninstall" setting before uninstalling to delete plugin options, category mappings and OLX advert metadata.

== Changelog ==

= 1.0.0 =
* Initial UA package for Ukraine.
