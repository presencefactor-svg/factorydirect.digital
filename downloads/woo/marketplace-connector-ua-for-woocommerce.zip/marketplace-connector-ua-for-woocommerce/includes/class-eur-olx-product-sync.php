<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCUA_OLX_Product_Sync {
    const MCUA_OLX_ADVERT_ID_META = '_mcua_olx_advert_id';
    const MCUA_OLX_STATUS_META    = '_mcua_olx_status';
    const MCUA_OLX_LAST_ERROR_META= '_mcua_olx_last_error';
    const MCUA_OLX_SYNC_NONCE     = 'mcua_olx_sync_product_nonce_action';

    private $mcua_olx_settings;
    private $mcua_olx_category_map;
    private $mcua_olx_api_client;

    public function __construct( MCUA_OLX_Settings $mcua_olx_settings, MCUA_OLX_Category_Map $mcua_olx_category_map ) {
        $this->mcua_olx_settings     = $mcua_olx_settings;
        $this->mcua_olx_category_map = $mcua_olx_category_map;
        $this->mcua_olx_api_client   = new MCUA_OLX_API_Client( $mcua_olx_settings );
    }

    public function mcua_olx_register_hooks() {
        add_action( 'add_meta_boxes_product', array( $this, 'mcua_olx_add_product_metabox' ) );
        add_action( 'admin_post_mcua_olx_sync_product', array( $this, 'mcua_olx_handle_manual_sync' ) );
        add_filter( 'bulk_actions-edit-product', array( $this, 'mcua_olx_register_bulk_actions' ) );
        add_filter( 'handle_bulk_actions-edit-product', array( $this, 'mcua_olx_handle_bulk_actions' ), 10, 3 );
    }

    public function mcua_olx_add_product_metabox() {
        add_meta_box(
            'mcua_olx_product_sync',
            esc_html__( 'Marketplace Connector UA Sync', 'marketplace-connector-ua-for-woocommerce' ),
            array( $this, 'mcua_olx_render_product_metabox' ),
            'product',
            'side',
            'default'
        );
    }

    public function mcua_olx_render_product_metabox( $mcua_olx_post ) {
        if ( ! current_user_can( 'edit_product', $mcua_olx_post->ID ) ) {
            return;
        }
        $mcua_olx_advert_id = get_post_meta( $mcua_olx_post->ID, self::MCUA_OLX_ADVERT_ID_META, true );
        $mcua_olx_status    = get_post_meta( $mcua_olx_post->ID, self::MCUA_OLX_STATUS_META, true );
        $mcua_olx_error     = get_post_meta( $mcua_olx_post->ID, self::MCUA_OLX_LAST_ERROR_META, true );
        $mcua_olx_url       = wp_nonce_url(
            admin_url( 'admin-post.php?action=mcua_olx_sync_product&product_id=' . absint( $mcua_olx_post->ID ) ),
            self::MCUA_OLX_SYNC_NONCE,
            'mcua_olx_nonce'
        );
        echo '<p><strong>' . esc_html__( 'Advert ID:', 'marketplace-connector-ua-for-woocommerce' ) . '</strong> ' . esc_html( $mcua_olx_advert_id ? $mcua_olx_advert_id : '-' ) . '</p>';
        echo '<p><strong>' . esc_html__( 'Status:', 'marketplace-connector-ua-for-woocommerce' ) . '</strong> ' . esc_html( $mcua_olx_status ? $mcua_olx_status : '-' ) . '</p>';
        if ( $mcua_olx_error ) {
            echo '<p class="description" style="color:#b32d2e;">' . esc_html( $mcua_olx_error ) . '</p>';
        }
        echo '<p><a class="button button-primary" href="' . esc_url( $mcua_olx_url ) . '">' . esc_html__( 'Sync to OLX', 'marketplace-connector-ua-for-woocommerce' ) . '</a></p>';
    }

    public function mcua_olx_handle_manual_sync() {
        $mcua_olx_product_id = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0;
        if ( ! $mcua_olx_product_id || ! current_user_can( 'edit_product', $mcua_olx_product_id ) ) {
            wp_die( esc_html__( 'You do not have permission to sync this product.', 'marketplace-connector-ua-for-woocommerce' ) );
        }
        check_admin_referer( self::MCUA_OLX_SYNC_NONCE, 'mcua_olx_nonce' );

        $mcua_olx_result = $this->mcua_olx_sync_product( $mcua_olx_product_id );
        $mcua_olx_args   = is_wp_error( $mcua_olx_result )
            ? array( 'mcua_olx_error' => rawurlencode( $mcua_olx_result->get_error_message() ) )
            : array( 'mcua_olx_message' => rawurlencode( esc_html__( 'Product synced to OLX.ua.', 'marketplace-connector-ua-for-woocommerce' ) ) );

        wp_safe_redirect( add_query_arg( $mcua_olx_args, get_edit_post_link( $mcua_olx_product_id, 'url' ) ) );
        exit;
    }

    public function mcua_olx_register_bulk_actions( $mcua_olx_actions ) {
        $mcua_olx_actions['mcua_olx_bulk_sync'] = esc_html__( 'Sync to Marketplace Connector UA', 'marketplace-connector-ua-for-woocommerce' );
        return $mcua_olx_actions;
    }

    public function mcua_olx_handle_bulk_actions( $mcua_olx_redirect, $mcua_olx_action, $mcua_olx_product_ids ) {
        if ( 'mcua_olx_bulk_sync' !== $mcua_olx_action ) {
            return $mcua_olx_redirect;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return $mcua_olx_redirect;
        }
        // WordPress core verifies the bulk action nonce before this filter is called.
        $mcua_olx_success = 0;
        $mcua_olx_failed  = 0;
        foreach ( array_map( 'absint', (array) $mcua_olx_product_ids ) as $mcua_olx_product_id ) {
            $mcua_olx_result = $this->mcua_olx_sync_product( $mcua_olx_product_id );
            is_wp_error( $mcua_olx_result ) ? $mcua_olx_failed++ : $mcua_olx_success++;
        }
        return add_query_arg( array( 'mcua_olx_success' => $mcua_olx_success, 'mcua_olx_failed' => $mcua_olx_failed ), $mcua_olx_redirect );
    }

    public function mcua_olx_sync_product( $mcua_olx_product_id ) {
        if ( ! function_exists( 'wc_get_product' ) ) {
            return new WP_Error( 'mcua_olx_missing_wc', esc_html__( 'WooCommerce is not active.', 'marketplace-connector-ua-for-woocommerce' ) );
        }

        $mcua_olx_product = wc_get_product( absint( $mcua_olx_product_id ) );
        if ( ! $mcua_olx_product ) {
            return new WP_Error( 'mcua_olx_missing_product', esc_html__( 'Product not found.', 'marketplace-connector-ua-for-woocommerce' ) );
        }

        $mcua_olx_payload = $this->mcua_olx_build_advert_payload( $mcua_olx_product );
        if ( is_wp_error( $mcua_olx_payload ) ) {
            return $mcua_olx_payload;
        }

        /** Hook for PRO/custom payload changes: variations, custom attributes, GPS, delivery, safety regulations. */
        $mcua_olx_payload = apply_filters( 'mcua_olx_advert_payload', $mcua_olx_payload, $mcua_olx_product );
        do_action( 'mcua_olx_before_manual_sync', $mcua_olx_product->get_id(), $mcua_olx_payload );

        $mcua_olx_existing_advert_id = get_post_meta( $mcua_olx_product->get_id(), self::MCUA_OLX_ADVERT_ID_META, true );
        $mcua_olx_response = $mcua_olx_existing_advert_id ? $this->mcua_olx_api_client->mcua_olx_update_v2_advert( $mcua_olx_existing_advert_id, $mcua_olx_payload ) : $this->mcua_olx_api_client->mcua_olx_post_v2_advert( $mcua_olx_payload );
        if ( is_wp_error( $mcua_olx_response ) ) {
            update_post_meta( $mcua_olx_product->get_id(), self::MCUA_OLX_LAST_ERROR_META, sanitize_text_field( $mcua_olx_response->get_error_message() ) );
            return $mcua_olx_response;
        }

        if ( isset( $mcua_olx_response['id'] ) ) {
            update_post_meta( $mcua_olx_product->get_id(), self::MCUA_OLX_ADVERT_ID_META, absint( $mcua_olx_response['id'] ) );
        }
        if ( isset( $mcua_olx_response['status'] ) ) {
            update_post_meta( $mcua_olx_product->get_id(), self::MCUA_OLX_STATUS_META, sanitize_text_field( $mcua_olx_response['status'] ) );
        }
        delete_post_meta( $mcua_olx_product->get_id(), self::MCUA_OLX_LAST_ERROR_META );
        do_action( 'mcua_olx_after_manual_sync', $mcua_olx_product->get_id(), $mcua_olx_response );

        return $mcua_olx_response;
    }

    private function mcua_olx_build_advert_payload( WC_Product $mcua_olx_product ) {
        $mcua_olx_options     = $this->mcua_olx_settings->mcua_olx_get_options();
        $mcua_olx_market      = $this->mcua_olx_settings->mcua_olx_get_market_config( $mcua_olx_options['market'] );
        $mcua_olx_category_id = $this->mcua_olx_category_map->mcua_olx_get_olx_category_id_for_product( $mcua_olx_product->get_id() );

        if ( ! $mcua_olx_category_id ) {
            return new WP_Error( 'mcua_olx_missing_category', esc_html__( 'Missing OLX category mapping for this product.', 'marketplace-connector-ua-for-woocommerce' ) );
        }
        if ( empty( $mcua_olx_options['city_id'] ) || empty( $mcua_olx_options['contact_name'] ) ) {
            return new WP_Error( 'mcua_olx_missing_required_settings', esc_html__( 'Missing default city ID or contact name in Marketplace Connector UA settings.', 'marketplace-connector-ua-for-woocommerce' ) );
        }

        $mcua_olx_title = sanitize_text_field( wp_strip_all_tags( $mcua_olx_product->get_name() ) );
        $mcua_olx_desc  = wp_kses_post( $mcua_olx_product->get_description() ? $mcua_olx_product->get_description() : $mcua_olx_product->get_short_description() );
        $mcua_olx_price = (float) wc_get_price_to_display( $mcua_olx_product );
        $mcua_olx_currency = $mcua_olx_options['currency'] ? $mcua_olx_options['currency'] : $mcua_olx_market['currency'];

        $mcua_olx_images = array();
        $mcua_olx_image_ids = array_filter( array_unique( array_merge( array( $mcua_olx_product->get_image_id() ), $mcua_olx_product->get_gallery_image_ids() ) ) );
        foreach ( array_slice( $mcua_olx_image_ids, 0, 8 ) as $mcua_olx_image_id ) {
            $mcua_olx_image_url = wp_get_attachment_url( absint( $mcua_olx_image_id ) );
            if ( $mcua_olx_image_url && $this->mcua_olx_is_public_image_url( $mcua_olx_image_url ) ) {
                $mcua_olx_images[] = array( 'url' => esc_url_raw( $mcua_olx_image_url ) );
            }
        }

        $mcua_olx_payload = array(
            'title'           => $mcua_olx_title,
            'description'     => $mcua_olx_desc,
            'category_id'     => absint( $mcua_olx_category_id ),
            'advertiser_type' => sanitize_text_field( $mcua_olx_options['advertiser_type'] ),
            'external_id'     => (string) $mcua_olx_product->get_id(),
            'contact'         => array(
                'name'  => sanitize_text_field( $mcua_olx_options['contact_name'] ),
                'phone' => sanitize_text_field( $mcua_olx_options['contact_phone'] ),
            ),
            'location'        => array_filter(
                array(
                    'city_id'     => absint( $mcua_olx_options['city_id'] ),
                    'district_id' => ! empty( $mcua_olx_options['district_id'] ) ? absint( $mcua_olx_options['district_id'] ) : null,
                )
            ),
            'images'          => $mcua_olx_images,
            'price'           => array(
                'value'      => $mcua_olx_price,
                'currency'   => sanitize_text_field( $mcua_olx_currency ),
                'negotiable' => false,
                'trade'      => false,
                'budget'     => false,
            ),
            'attributes'      => $this->mcua_olx_category_map->mcua_olx_get_attributes_for_product( $mcua_olx_product->get_id() ),
        );

        return $mcua_olx_payload;
    }

    private function mcua_olx_is_public_image_url( $mcua_olx_image_url ) {
        $mcua_olx_host = wp_parse_url( $mcua_olx_image_url, PHP_URL_HOST );
        if ( ! $mcua_olx_host ) {
            return false;
        }
        $mcua_olx_host = strtolower( $mcua_olx_host );
        if ( 'localhost' === $mcua_olx_host || '.local' === substr( $mcua_olx_host, -6 ) || '.test' === substr( $mcua_olx_host, -5 ) ) {
            return false;
        }
        if ( filter_var( $mcua_olx_host, FILTER_VALIDATE_IP ) ) {
            return ! preg_match( '/^(127\.|10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[0-1])\.)/', $mcua_olx_host );
        }
        return true;
    }
}
