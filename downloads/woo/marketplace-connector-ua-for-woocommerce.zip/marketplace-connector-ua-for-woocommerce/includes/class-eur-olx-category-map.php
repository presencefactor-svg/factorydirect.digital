<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCUA_OLX_Category_Map {
    const MCUA_OLX_CATEGORY_MAP_OPTION = 'mcua_olx_category_map';
    const MCUA_OLX_CATEGORY_MAP_NONCE = 'mcua_olx_category_map_nonce_action';

    public function mcua_olx_get_map() {
        $mcua_olx_map = get_option( self::MCUA_OLX_CATEGORY_MAP_OPTION, array() );
        return is_array( $mcua_olx_map ) ? $mcua_olx_map : array();
    }

    public function mcua_olx_get_mapping_for_product( $mcua_olx_product_id ) {
        $mcua_olx_map   = $this->mcua_olx_get_map();
        $mcua_olx_terms = wp_get_post_terms( absint( $mcua_olx_product_id ), 'product_cat' );
        if ( is_wp_error( $mcua_olx_terms ) ) {
            return array();
        }
        foreach ( $mcua_olx_terms as $mcua_olx_term ) {
            $mcua_olx_term_id = (string) absint( $mcua_olx_term->term_id );
            if ( empty( $mcua_olx_map[ $mcua_olx_term_id ] ) ) {
                continue;
            }
            if ( is_array( $mcua_olx_map[ $mcua_olx_term_id ] ) ) {
                return $mcua_olx_map[ $mcua_olx_term_id ];
            }
            return array( 'category_id' => absint( $mcua_olx_map[ $mcua_olx_term_id ] ) );
        }
        return array();
    }

    public function mcua_olx_get_olx_category_id_for_product( $mcua_olx_product_id ) {
        $mcua_olx_mapping = $this->mcua_olx_get_mapping_for_product( $mcua_olx_product_id );
        return ! empty( $mcua_olx_mapping['category_id'] ) ? absint( $mcua_olx_mapping['category_id'] ) : '';
    }

    public function mcua_olx_get_attributes_for_product( $mcua_olx_product_id ) {
        $mcua_olx_mapping    = $this->mcua_olx_get_mapping_for_product( $mcua_olx_product_id );
        $mcua_olx_attributes = array();
        $mcua_olx_state      = ! empty( $mcua_olx_mapping['state'] ) ? sanitize_key( $mcua_olx_mapping['state'] ) : 'new';
        if ( $mcua_olx_state ) {
            $mcua_olx_attributes[] = array( 'code' => 'state', 'value' => $mcua_olx_state );
        }
        if ( ! empty( $mcua_olx_mapping['attributes'] ) && is_array( $mcua_olx_mapping['attributes'] ) ) {
            foreach ( $mcua_olx_mapping['attributes'] as $mcua_olx_attribute ) {
                if ( empty( $mcua_olx_attribute['code'] ) || ! isset( $mcua_olx_attribute['value'] ) ) {
                    continue;
                }
                $mcua_olx_code  = sanitize_key( $mcua_olx_attribute['code'] );
                $mcua_olx_value = sanitize_text_field( (string) $mcua_olx_attribute['value'] );
                if ( $mcua_olx_code && '' !== $mcua_olx_value ) {
                    $mcua_olx_attributes[] = array( 'code' => $mcua_olx_code, 'value' => $mcua_olx_value );
                }
            }
        }
        return $this->mcua_olx_dedupe_attributes( $mcua_olx_attributes );
    }

    public function mcua_olx_handle_category_map_save() {
        if ( empty( $_POST['mcua_olx_category_map_submit'] ) ) {
            return;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to save category mapping.', 'marketplace-connector-ua-for-woocommerce' ) );
        }
        check_admin_referer( self::MCUA_OLX_CATEGORY_MAP_NONCE, 'mcua_olx_category_map_nonce' );

        $mcua_olx_raw_map = isset( $_POST['mcua_olx_category_map'] ) && is_array( $_POST['mcua_olx_category_map'] ) ? map_deep( wp_unslash( $_POST['mcua_olx_category_map'] ), 'sanitize_text_field' ) : array();
        $mcua_olx_clean   = array();
        foreach ( $mcua_olx_raw_map as $mcua_olx_woo_cat_id => $mcua_olx_row ) {
            $mcua_olx_woo_cat_id = absint( $mcua_olx_woo_cat_id );
            if ( ! $mcua_olx_woo_cat_id || ! is_array( $mcua_olx_row ) ) {
                continue;
            }
            $mcua_olx_olx_cat_id = ! empty( $mcua_olx_row['category_id'] ) ? absint( $mcua_olx_row['category_id'] ) : 0;
            if ( ! $mcua_olx_olx_cat_id ) {
                continue;
            }
            $mcua_olx_clean[ (string) $mcua_olx_woo_cat_id ] = array(
                'category_id'   => $mcua_olx_olx_cat_id,
                'category_path' => isset( $mcua_olx_row['category_path'] ) ? sanitize_text_field( $mcua_olx_row['category_path'] ) : '',
                'state'         => isset( $mcua_olx_row['state'] ) ? sanitize_key( $mcua_olx_row['state'] ) : 'new',
                'attributes'    => $this->mcua_olx_parse_attribute_lines( isset( $mcua_olx_row['attributes'] ) ? (string) $mcua_olx_row['attributes'] : '' ),
            );
        }
        update_option( self::MCUA_OLX_CATEGORY_MAP_OPTION, $mcua_olx_clean, false );
        add_settings_error( 'mcua_olx_category_map', 'mcua_olx_category_map_saved', esc_html__( 'Category mapping saved.', 'marketplace-connector-ua-for-woocommerce' ), 'updated' );
    }

    public function mcua_olx_render_category_map_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'marketplace-connector-ua-for-woocommerce' ) );
        }
        $mcua_olx_map        = $this->mcua_olx_get_map();
        $mcua_olx_categories = $this->mcua_olx_get_ua_category_suggestions();
        $mcua_olx_terms      = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Marketplace Connector UA Category Mapping', 'marketplace-connector-ua-for-woocommerce' ); ?></h1>
            <p class="description"><?php echo esc_html__( 'Map WooCommerce categories to OLX.ua category IDs and define required category attributes such as condition/state. Category ID fields include live OLX.ua API suggestions when OAuth is connected. Additional attributes use one code=value pair per line, for example brand=Samsung.', 'marketplace-connector-ua-for-woocommerce' ); ?></p>
            <?php if ( ! empty( $mcua_olx_categories ) ) : ?>
                <datalist id="mcua_olx_ua_categories">
                    <?php foreach ( $mcua_olx_categories as $mcua_olx_category ) : ?>
                        <option value="<?php echo esc_attr( $mcua_olx_category['id'] ); ?>" label="<?php echo esc_attr( $mcua_olx_category['name'] ); ?>"></option>
                    <?php endforeach; ?>
                </datalist>
            <?php endif; ?>
            <?php settings_errors( 'mcua_olx_category_map' ); ?>
            <form method="post">
                <?php wp_nonce_field( self::MCUA_OLX_CATEGORY_MAP_NONCE, 'mcua_olx_category_map_nonce' ); ?>
                <input type="hidden" name="mcua_olx_category_map_submit" value="1">
                <table class="widefat striped">
                    <thead><tr><th><?php echo esc_html__( 'WooCommerce category', 'marketplace-connector-ua-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'OLX.ua category ID', 'marketplace-connector-ua-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Category note/path', 'marketplace-connector-ua-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Condition', 'marketplace-connector-ua-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Extra attributes', 'marketplace-connector-ua-for-woocommerce' ); ?></th></tr></thead>
                    <tbody>
                    <?php if ( ! is_wp_error( $mcua_olx_terms ) ) : ?>
                        <?php foreach ( $mcua_olx_terms as $mcua_olx_term ) : ?>
                            <?php
                            $mcua_olx_row = isset( $mcua_olx_map[ (string) $mcua_olx_term->term_id ] ) ? $mcua_olx_map[ (string) $mcua_olx_term->term_id ] : array();
                            if ( ! is_array( $mcua_olx_row ) ) {
                                $mcua_olx_row = array( 'category_id' => absint( $mcua_olx_row ) );
                            }
                            $mcua_olx_value = ! empty( $mcua_olx_row['category_id'] ) ? absint( $mcua_olx_row['category_id'] ) : '';
                            $mcua_olx_state = ! empty( $mcua_olx_row['state'] ) ? sanitize_key( $mcua_olx_row['state'] ) : 'new';
                            ?>
                            <tr>
                                <td><?php echo esc_html( $mcua_olx_term->name ); ?></td>
                                <td><input type="number" min="1" list="mcua_olx_ua_categories" name="mcua_olx_category_map[<?php echo esc_attr( $mcua_olx_term->term_id ); ?>][category_id]" value="<?php echo esc_attr( $mcua_olx_value ); ?>" class="small-text"></td>
                                <td><input type="text" name="mcua_olx_category_map[<?php echo esc_attr( $mcua_olx_term->term_id ); ?>][category_path]" value="<?php echo esc_attr( isset( $mcua_olx_row['category_path'] ) ? $mcua_olx_row['category_path'] : '' ); ?>" class="regular-text" placeholder="<?php echo esc_attr__( 'e.g. Home / Lighting', 'marketplace-connector-ua-for-woocommerce' ); ?>"></td>
                                <td><select name="mcua_olx_category_map[<?php echo esc_attr( $mcua_olx_term->term_id ); ?>][state]"><option value="new" <?php selected( $mcua_olx_state, 'new' ); ?>><?php echo esc_html__( 'New', 'marketplace-connector-ua-for-woocommerce' ); ?></option><option value="used" <?php selected( $mcua_olx_state, 'used' ); ?>><?php echo esc_html__( 'Used', 'marketplace-connector-ua-for-woocommerce' ); ?></option></select></td>
                                <td><textarea rows="3" cols="32" name="mcua_olx_category_map[<?php echo esc_attr( $mcua_olx_term->term_id ); ?>][attributes]" placeholder="brand=Samsung&#10;model=A54"><?php echo esc_textarea( $this->mcua_olx_format_attribute_lines( isset( $mcua_olx_row['attributes'] ) && is_array( $mcua_olx_row['attributes'] ) ? $mcua_olx_row['attributes'] : array() ) ); ?></textarea></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
                <?php submit_button( esc_html__( 'Save mapping', 'marketplace-connector-ua-for-woocommerce' ) ); ?>
            </form>
        </div>
        <?php
    }


    private function mcua_olx_get_ua_category_suggestions() {
        $mcua_olx_cached = get_transient( 'mcua_olx_ua_category_suggestions' );
        if ( is_array( $mcua_olx_cached ) ) {
            return $mcua_olx_cached;
        }
        $mcua_olx_options = get_option( 'mcua_olx_options', array() );
        if ( empty( $mcua_olx_options['access_token'] ) ) {
            return array();
        }
        $mcua_olx_response = wp_remote_get(
            'https://www.olx.ua/api/partner/categories?limit=1000',
            array(
                'timeout' => 20,
                'headers' => array(
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer ' . $mcua_olx_options['access_token'],
                    'Version'       => '2.0',
                ),
            )
        );
        if ( is_wp_error( $mcua_olx_response ) || 200 !== (int) wp_remote_retrieve_response_code( $mcua_olx_response ) ) {
            return array();
        }
        $mcua_olx_json = json_decode( (string) wp_remote_retrieve_body( $mcua_olx_response ), true );
        $mcua_olx_rows = isset( $mcua_olx_json['data'] ) && is_array( $mcua_olx_json['data'] ) ? $mcua_olx_json['data'] : array();
        $mcua_olx_categories = array();
        foreach ( $mcua_olx_rows as $mcua_olx_row ) {
            if ( empty( $mcua_olx_row['id'] ) || empty( $mcua_olx_row['name'] ) ) {
                continue;
            }
            $mcua_olx_categories[] = array(
                'id'   => absint( $mcua_olx_row['id'] ),
                'name' => sanitize_text_field( (string) $mcua_olx_row['name'] ),
            );
        }
        set_transient( 'mcua_olx_ua_category_suggestions', $mcua_olx_categories, DAY_IN_SECONDS );
        return $mcua_olx_categories;
    }

    private function mcua_olx_parse_attribute_lines( $mcua_olx_raw ) {
        $mcua_olx_attributes = array();
        foreach ( preg_split( '/\r\n|\r|\n/', (string) $mcua_olx_raw ) as $mcua_olx_line ) {
            $mcua_olx_line = trim( $mcua_olx_line );
            if ( '' === $mcua_olx_line || false === strpos( $mcua_olx_line, '=' ) ) {
                continue;
            }
            list( $mcua_olx_code, $mcua_olx_value ) = array_map( 'trim', explode( '=', $mcua_olx_line, 2 ) );
            $mcua_olx_code  = sanitize_key( $mcua_olx_code );
            $mcua_olx_value = sanitize_text_field( $mcua_olx_value );
            if ( $mcua_olx_code && '' !== $mcua_olx_value ) {
                $mcua_olx_attributes[] = array( 'code' => $mcua_olx_code, 'value' => $mcua_olx_value );
            }
        }
        return $this->mcua_olx_dedupe_attributes( $mcua_olx_attributes );
    }

    private function mcua_olx_format_attribute_lines( array $mcua_olx_attributes ) {
        $mcua_olx_lines = array();
        foreach ( $mcua_olx_attributes as $mcua_olx_attribute ) {
            if ( ! empty( $mcua_olx_attribute['code'] ) && isset( $mcua_olx_attribute['value'] ) ) {
                $mcua_olx_lines[] = sanitize_key( $mcua_olx_attribute['code'] ) . '=' . sanitize_text_field( (string) $mcua_olx_attribute['value'] );
            }
        }
        return implode( "\n", $mcua_olx_lines );
    }

    private function mcua_olx_dedupe_attributes( array $mcua_olx_attributes ) {
        $mcua_olx_seen = array();
        $mcua_olx_clean = array();
        foreach ( $mcua_olx_attributes as $mcua_olx_attribute ) {
            if ( empty( $mcua_olx_attribute['code'] ) || ! isset( $mcua_olx_attribute['value'] ) ) {
                continue;
            }
            $mcua_olx_code = sanitize_key( $mcua_olx_attribute['code'] );
            if ( ! $mcua_olx_code || isset( $mcua_olx_seen[ $mcua_olx_code ] ) ) {
                continue;
            }
            $mcua_olx_seen[ $mcua_olx_code ] = true;
            $mcua_olx_clean[] = array( 'code' => $mcua_olx_code, 'value' => sanitize_text_field( (string) $mcua_olx_attribute['value'] ) );
        }
        return $mcua_olx_clean;
    }
}
