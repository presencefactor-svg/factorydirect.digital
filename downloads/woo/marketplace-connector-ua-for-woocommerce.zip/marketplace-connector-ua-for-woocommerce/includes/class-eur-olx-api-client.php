<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCUA_OLX_API_Client {
    private $mcua_olx_settings;

    public function __construct( MCUA_OLX_Settings $mcua_olx_settings ) {
        $this->mcua_olx_settings = $mcua_olx_settings;
    }

    public function mcua_olx_request( $mcua_olx_method, $mcua_olx_path, $mcua_olx_body = null ) {
        $mcua_olx_options = $this->mcua_olx_settings->mcua_olx_get_options();
        if ( ( empty( $mcua_olx_options['access_token'] ) && ! empty( $mcua_olx_options['refresh_token'] ) ) || ( ! empty( $mcua_olx_options['token_expires_at'] ) && absint( $mcua_olx_options['token_expires_at'] ) < time() + 120 ) ) {
            $mcua_olx_refreshed = $this->mcua_olx_refresh_access_token();
            if ( ! is_wp_error( $mcua_olx_refreshed ) ) {
                $mcua_olx_options = $this->mcua_olx_settings->mcua_olx_get_options();
            }
        }

        $mcua_olx_market = $this->mcua_olx_settings->mcua_olx_get_market_config( $mcua_olx_options['market'] );
        $mcua_olx_token  = trim( (string) $mcua_olx_options['access_token'] );

        if ( '' === $mcua_olx_token ) {
            return new WP_Error( 'mcua_olx_missing_token', esc_html__( 'Missing OAuth access token.', 'marketplace-connector-ua-for-woocommerce' ) );
        }

        $mcua_olx_url = trailingslashit( $mcua_olx_market['base_url'] ) . ltrim( $mcua_olx_path, '/' );
        $mcua_olx_args = array(
            'method'  => strtoupper( sanitize_key( $mcua_olx_method ) ),
            'timeout' => 45,
            'headers' => array(
                'Accept'        => 'application/json',
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $mcua_olx_token,
                'Version'       => '2.0',
            ),
        );

        if ( null !== $mcua_olx_body ) {
            $mcua_olx_args['body'] = wp_json_encode( $mcua_olx_body );
        }

        $mcua_olx_args = apply_filters( 'mcua_olx_api_request_args', $mcua_olx_args, $mcua_olx_path, $mcua_olx_body );
        $mcua_olx_response = wp_remote_request( esc_url_raw( $mcua_olx_url ), $mcua_olx_args );
        return $this->mcua_olx_parse_response( $mcua_olx_response );
    }

    public function mcua_olx_post_v2_advert( array $mcua_olx_payload ) {
        return $this->mcua_olx_request( 'POST', '/adverts', $mcua_olx_payload );
    }

    public function mcua_olx_update_v2_advert( $mcua_olx_advert_id, array $mcua_olx_payload ) {
        return $this->mcua_olx_request( 'PUT', '/adverts/' . absint( $mcua_olx_advert_id ), $mcua_olx_payload );
    }

    public function mcua_olx_refresh_access_token() {
        $mcua_olx_options = $this->mcua_olx_settings->mcua_olx_get_options();
        if ( empty( $mcua_olx_options['client_id'] ) || empty( $mcua_olx_options['client_secret'] ) || empty( $mcua_olx_options['refresh_token'] ) ) {
            return new WP_Error( 'mcua_olx_refresh_missing_credentials', esc_html__( 'Missing OAuth refresh credentials.', 'marketplace-connector-ua-for-woocommerce' ) );
        }

        $mcua_olx_market = $this->mcua_olx_settings->mcua_olx_get_market_config( $mcua_olx_options['market'] );
        $mcua_olx_response = wp_remote_post(
            esc_url_raw( $mcua_olx_market['token_url'] ),
            array(
                'timeout' => 45,
                'headers' => array( 'Accept' => 'application/json' ),
                'body'    => array(
                    'grant_type'    => 'refresh_token',
                    'client_id'     => $mcua_olx_options['client_id'],
                    'client_secret' => $mcua_olx_options['client_secret'],
                    'refresh_token' => $mcua_olx_options['refresh_token'],
                ),
            )
        );

        $mcua_olx_json = $this->mcua_olx_parse_response( $mcua_olx_response );
        if ( is_wp_error( $mcua_olx_json ) ) {
            return $mcua_olx_json;
        }
        $this->mcua_olx_settings->mcua_olx_save_tokens_from_response( $mcua_olx_json );
        return $mcua_olx_json;
    }

    private function mcua_olx_parse_response( $mcua_olx_response ) {
        if ( is_wp_error( $mcua_olx_response ) ) {
            return $mcua_olx_response;
        }
        $mcua_olx_code = (int) wp_remote_retrieve_response_code( $mcua_olx_response );
        $mcua_olx_raw  = (string) wp_remote_retrieve_body( $mcua_olx_response );
        $mcua_olx_json = json_decode( $mcua_olx_raw, true );
        if ( $mcua_olx_code < 200 || $mcua_olx_code >= 300 ) {
            return new WP_Error(
                'mcua_olx_api_error',
                sprintf(
                    /* translators: 1: HTTP status code, 2: response body */
                    esc_html__( 'OLX API error %1$d: %2$s', 'marketplace-connector-ua-for-woocommerce' ),
                    $mcua_olx_code,
                    is_array( $mcua_olx_json ) ? wp_json_encode( $mcua_olx_json ) : $mcua_olx_raw
                )
            );
        }
        if ( is_array( $mcua_olx_json ) && array_key_exists( 'data', $mcua_olx_json ) ) {
            return is_array( $mcua_olx_json['data'] ) ? $mcua_olx_json['data'] : array( 'data' => $mcua_olx_json['data'] );
        }
        return is_array( $mcua_olx_json ) ? $mcua_olx_json : array( 'raw' => $mcua_olx_raw );
    }
}
