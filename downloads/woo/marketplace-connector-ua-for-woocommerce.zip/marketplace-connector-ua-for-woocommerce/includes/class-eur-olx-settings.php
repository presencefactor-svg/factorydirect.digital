<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCUA_OLX_Settings {
    const MCUA_OLX_OPTION = 'mcua_olx_options';
    const MCUA_OLX_NONCE_ACTION = 'mcua_olx_settings_nonce_action';
    const MCUA_OLX_OAUTH_STATE_TRANSIENT_PREFIX = 'mcua_olx_oauth_state_';

    public function mcua_olx_get_defaults() {
        return array(
            'market'           => 'ua',
            'client_id'        => '',
            'client_secret'    => '',
            'access_token'     => '',
            'refresh_token'    => '',
            'token_expires_at' => '',
            'currency'         => '',
            'advertiser_type'  => 'business',
            'contact_name'     => '',
            'contact_phone'    => '',
            'city_id'          => '',
            'district_id'      => '',
            'cleanup_data'     => '0',
        );
    }

    public function mcua_olx_get_options() {
        $mcua_olx_options = get_option( self::MCUA_OLX_OPTION, array() );
        return wp_parse_args( is_array( $mcua_olx_options ) ? $mcua_olx_options : array(), $this->mcua_olx_get_defaults() );
    }

    public function mcua_olx_register_settings() {
        register_setting(
            'mcua_olx_settings_group',
            self::MCUA_OLX_OPTION,
            array(
                'type'              => 'array',
                'sanitize_callback' => array( $this, 'mcua_olx_sanitize_options' ),
                'default'           => $this->mcua_olx_get_defaults(),
            )
        );
    }

    public function mcua_olx_sanitize_options( $mcua_olx_input ) {
        $mcua_olx_old = $this->mcua_olx_get_options();
        if ( ! isset( $_POST['mcua_olx_settings_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mcua_olx_settings_nonce'] ) ), self::MCUA_OLX_NONCE_ACTION ) ) {
            add_settings_error( 'mcua_olx_settings', 'mcua_olx_settings_nonce_failed', esc_html__( 'Security check failed. Settings were not saved.', 'marketplace-connector-ua-for-woocommerce' ), 'error' );
            return $mcua_olx_old;
        }

        $mcua_olx_input = is_array( $mcua_olx_input ) ? wp_unslash( $mcua_olx_input ) : array();
        $mcua_olx_allowed_markets = array( 'ua' );
        $mcua_olx_market = isset( $mcua_olx_input['market'] ) ? sanitize_key( $mcua_olx_input['market'] ) : 'ua';

        return array(
            'market'           => in_array( $mcua_olx_market, $mcua_olx_allowed_markets, true ) ? $mcua_olx_market : 'pl',
            'client_id'        => isset( $mcua_olx_input['client_id'] ) ? sanitize_text_field( $mcua_olx_input['client_id'] ) : '',
            'client_secret'    => isset( $mcua_olx_input['client_secret'] ) && '' !== $mcua_olx_input['client_secret'] ? sanitize_text_field( $mcua_olx_input['client_secret'] ) : $mcua_olx_old['client_secret'],
            'access_token'     => isset( $mcua_olx_input['access_token'] ) && '' !== $mcua_olx_input['access_token'] ? sanitize_textarea_field( $mcua_olx_input['access_token'] ) : $mcua_olx_old['access_token'],
            'refresh_token'    => isset( $mcua_olx_input['refresh_token'] ) && '' !== $mcua_olx_input['refresh_token'] ? sanitize_textarea_field( $mcua_olx_input['refresh_token'] ) : $mcua_olx_old['refresh_token'],
            'token_expires_at' => isset( $mcua_olx_input['token_expires_at'] ) ? absint( $mcua_olx_input['token_expires_at'] ) : absint( $mcua_olx_old['token_expires_at'] ),
            'currency'         => isset( $mcua_olx_input['currency'] ) ? strtoupper( sanitize_text_field( $mcua_olx_input['currency'] ) ) : '',
            'advertiser_type'  => isset( $mcua_olx_input['advertiser_type'] ) && in_array( $mcua_olx_input['advertiser_type'], array( 'private', 'business' ), true ) ? sanitize_key( $mcua_olx_input['advertiser_type'] ) : 'business',
            'contact_name'     => isset( $mcua_olx_input['contact_name'] ) ? sanitize_text_field( $mcua_olx_input['contact_name'] ) : '',
            'contact_phone'    => isset( $mcua_olx_input['contact_phone'] ) ? sanitize_text_field( $mcua_olx_input['contact_phone'] ) : '',
            'city_id'          => isset( $mcua_olx_input['city_id'] ) ? absint( $mcua_olx_input['city_id'] ) : '',
            'district_id'      => isset( $mcua_olx_input['district_id'] ) ? absint( $mcua_olx_input['district_id'] ) : '',
            'cleanup_data'     => ! empty( $mcua_olx_input['cleanup_data'] ) ? '1' : '0',
        );
    }

    public function mcua_olx_get_market_config( $mcua_olx_market = '' ) {
        $mcua_olx_market = $mcua_olx_market ? sanitize_key( $mcua_olx_market ) : $this->mcua_olx_get_options()['market'];
        $mcua_olx_markets = array(
            'ua' => array( 'label' => 'Ukraine', 'base_url' => 'https://www.olx.ua/api/partner', 'oauth_url' => 'https://www.olx.ua/oauth/authorize', 'token_url' => 'https://www.olx.ua/api/open/oauth/token', 'currency' => 'UAH' ),
        );
        $mcua_olx_markets = apply_filters( 'mcua_olx_market_configs', $mcua_olx_markets );
        return isset( $mcua_olx_markets[ $mcua_olx_market ] ) ? $mcua_olx_markets[ $mcua_olx_market ] : $mcua_olx_markets['ua'];
    }

    public function mcua_olx_get_oauth_redirect_uri() {
        return admin_url( 'admin-post.php?action=mcua_olx_oauth_callback' );
    }

    public function mcua_olx_handle_oauth_start() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to connect OLX.', 'marketplace-connector-ua-for-woocommerce' ) );
        }
        check_admin_referer( 'mcua_olx_oauth_start' );
        $mcua_olx_options = $this->mcua_olx_get_options();
        if ( empty( $mcua_olx_options['client_id'] ) ) {
            wp_safe_redirect( add_query_arg( 'mcua_olx_oauth_error', rawurlencode( __( 'Client ID is required before connecting.', 'marketplace-connector-ua-for-woocommerce' ) ), admin_url( 'admin.php?page=mcua_olx-settings' ) ) );
            exit;
        }
        $mcua_olx_market = $this->mcua_olx_get_market_config( $mcua_olx_options['market'] );
        $mcua_olx_state = wp_generate_password( 32, false, false );
        set_transient( self::MCUA_OLX_OAUTH_STATE_TRANSIENT_PREFIX . $mcua_olx_state, get_current_user_id(), 10 * MINUTE_IN_SECONDS );
        $mcua_olx_scopes = apply_filters( 'mcua_olx_oauth_scopes', array( 'v2', 'read', 'write' ) );
        $mcua_olx_auth_query = http_build_query(
            array(
                'response_type' => 'code',
                'client_id'     => $mcua_olx_options['client_id'],
                'redirect_uri'  => $this->mcua_olx_get_oauth_redirect_uri(),
                'scope'         => implode( ' ', array_map( 'sanitize_key', (array) $mcua_olx_scopes ) ),
                'state'         => $mcua_olx_state,
            ),
            '',
            '&',
            PHP_QUERY_RFC3986
        );
        $mcua_olx_auth_url = $mcua_olx_market['oauth_url'] . '?' . $mcua_olx_auth_query;
        update_option( 'mcua_olx_last_oauth_debug', array( 'phase' => 'start', 'redirect_uri' => $this->mcua_olx_get_oauth_redirect_uri(), 'auth_host' => wp_parse_url( $mcua_olx_market['oauth_url'], PHP_URL_HOST ), 'time' => time() ), false );
        wp_redirect( esc_url_raw( $mcua_olx_auth_url ) ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- External OAuth authorization URL is built from fixed OLX market configuration.
        exit;
    }

    public function mcua_olx_handle_oauth_callback() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to connect OLX.', 'marketplace-connector-ua-for-woocommerce' ) );
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- OAuth callbacks are validated via the provider state parameter.
        $mcua_olx_state = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- OAuth callbacks are validated via the provider state parameter.
        $mcua_olx_code  = isset( $_GET['code'] ) ? sanitize_text_field( wp_unslash( $_GET['code'] ) ) : '';
        $mcua_olx_saved = $mcua_olx_state ? get_transient( self::MCUA_OLX_OAUTH_STATE_TRANSIENT_PREFIX . $mcua_olx_state ) : false;
        update_option( 'mcua_olx_last_oauth_debug', array( 'phase' => 'callback_received', 'has_code' => $mcua_olx_code ? 'yes' : 'no', 'has_state' => $mcua_olx_state ? 'yes' : 'no', 'state_valid' => false === $mcua_olx_saved ? 'no' : 'yes', 'time' => time() ), false );
        if ( ! $mcua_olx_state || ! $mcua_olx_code || false === $mcua_olx_saved ) {
            wp_safe_redirect( add_query_arg( 'mcua_olx_oauth_error', rawurlencode( __( 'OAuth callback validation failed. The callback did not include a valid code/state pair.', 'marketplace-connector-ua-for-woocommerce' ) ), admin_url( 'admin.php?page=mcua_olx-settings' ) ) );
            exit;
        }
        delete_transient( self::MCUA_OLX_OAUTH_STATE_TRANSIENT_PREFIX . $mcua_olx_state );
        $mcua_olx_result = $this->mcua_olx_exchange_code_for_tokens( $mcua_olx_code );
        if ( ! is_wp_error( $mcua_olx_result ) ) {
            $mcua_olx_after_save = $this->mcua_olx_get_options();
            if ( empty( $mcua_olx_after_save['access_token'] ) ) {
                $mcua_olx_result = new WP_Error( 'mcua_olx_oauth_token_not_saved', esc_html__( 'OAuth completed but the access token was not saved. Re-save Client Secret and connect again.', 'marketplace-connector-ua-for-woocommerce' ) );
            }
        }
        $mcua_olx_arg = is_wp_error( $mcua_olx_result ) ? array( 'mcua_olx_oauth_error' => rawurlencode( $mcua_olx_result->get_error_message() ) ) : array( 'mcua_olx_oauth_connected' => '1' );
        wp_safe_redirect( add_query_arg( $mcua_olx_arg, admin_url( 'admin.php?page=mcua_olx-settings' ) ) );
        exit;
    }

    private function mcua_olx_exchange_code_for_tokens( $mcua_olx_code ) {
        $mcua_olx_options = $this->mcua_olx_get_options();
        $mcua_olx_market = $this->mcua_olx_get_market_config( $mcua_olx_options['market'] );
        if ( empty( $mcua_olx_options['client_id'] ) || empty( $mcua_olx_options['client_secret'] ) ) {
            return new WP_Error( 'mcua_olx_oauth_missing_client', esc_html__( 'Client ID and Client Secret are required.', 'marketplace-connector-ua-for-woocommerce' ) );
        }
        $mcua_olx_response = wp_remote_post(
            esc_url_raw( $mcua_olx_market['token_url'] ),
            array(
                'timeout' => 45,
                'headers' => array( 'Accept' => 'application/json' ),
                'body'    => array(
                    'grant_type'    => 'authorization_code',
                    'client_id'     => $mcua_olx_options['client_id'],
                    'client_secret' => $mcua_olx_options['client_secret'],
                    'redirect_uri'  => $this->mcua_olx_get_oauth_redirect_uri(),
                    'code'          => $mcua_olx_code,
                ),
            )
        );
        if ( is_wp_error( $mcua_olx_response ) ) {
            return $mcua_olx_response;
        }
        $mcua_olx_code_http = (int) wp_remote_retrieve_response_code( $mcua_olx_response );
        $mcua_olx_raw = (string) wp_remote_retrieve_body( $mcua_olx_response );
        $mcua_olx_json = json_decode( $mcua_olx_raw, true );
        $mcua_olx_debug_body = $mcua_olx_raw;
        $mcua_olx_debug_body = preg_replace( '/"access_token"\s*:\s*"[^"]+"/', '"access_token":"[REDACTED]"', $mcua_olx_debug_body );
        $mcua_olx_debug_body = preg_replace( '/"refresh_token"\s*:\s*"[^"]+"/', '"refresh_token":"[REDACTED]"', $mcua_olx_debug_body );
        update_option( 'mcua_olx_last_oauth_debug', array( 'phase' => 'token_response', 'http' => $mcua_olx_code_http, 'json' => is_array( $mcua_olx_json ) ? 'yes' : 'no', 'has_access_token' => is_array( $mcua_olx_json ) && ! empty( $mcua_olx_json['access_token'] ) ? 'yes' : 'no', 'has_refresh_token' => is_array( $mcua_olx_json ) && ! empty( $mcua_olx_json['refresh_token'] ) ? 'yes' : 'no', 'body' => substr( sanitize_textarea_field( $mcua_olx_debug_body ), 0, 800 ), 'time' => time() ), false );
        if ( $mcua_olx_code_http < 200 || $mcua_olx_code_http >= 300 || ! is_array( $mcua_olx_json ) ) {
            /* translators: %s: Redacted response body returned by the OAuth token endpoint. */
            return new WP_Error( 'mcua_olx_oauth_token_error', sprintf( esc_html__( 'OAuth token exchange failed: %s', 'marketplace-connector-ua-for-woocommerce' ), $mcua_olx_raw ) );
        }
        if ( empty( $mcua_olx_json['access_token'] ) ) {
            return new WP_Error( 'mcua_olx_oauth_missing_access_token', esc_html__( 'OAuth token exchange completed but OLX did not return an access token. Check the callback URI and application approval.', 'marketplace-connector-ua-for-woocommerce' ) );
        }
        $this->mcua_olx_save_tokens_from_response( $mcua_olx_json );
        return $mcua_olx_json;
    }

    public function mcua_olx_save_tokens_from_response( array $mcua_olx_response ) {
        $mcua_olx_options = $this->mcua_olx_get_options();
        if ( ! empty( $mcua_olx_response['access_token'] ) ) {
            $mcua_olx_options['access_token'] = sanitize_textarea_field( $mcua_olx_response['access_token'] );
        }
        if ( ! empty( $mcua_olx_response['refresh_token'] ) ) {
            $mcua_olx_options['refresh_token'] = sanitize_textarea_field( $mcua_olx_response['refresh_token'] );
        }
        if ( ! empty( $mcua_olx_response['expires_in'] ) ) {
            $mcua_olx_options['token_expires_at'] = time() + absint( $mcua_olx_response['expires_in'] );
        }
        // OAuth callback is an internal trusted write; bypass the settings-form nonce sanitizer for this update.
        remove_filter( 'sanitize_option_' . self::MCUA_OLX_OPTION, array( $this, 'mcua_olx_sanitize_options' ), 10 );
        update_option( self::MCUA_OLX_OPTION, $mcua_olx_options, false );
        add_filter( 'sanitize_option_' . self::MCUA_OLX_OPTION, array( $this, 'mcua_olx_sanitize_options' ), 10, 1 );
        $mcua_olx_persisted = $this->mcua_olx_get_options();
        update_option( 'mcua_olx_last_oauth_debug', array( 'phase' => 'tokens_saved', 'access_len' => ! empty( $mcua_olx_persisted['access_token'] ) ? strlen( $mcua_olx_persisted['access_token'] ) : 0, 'refresh_len' => ! empty( $mcua_olx_persisted['refresh_token'] ) ? strlen( $mcua_olx_persisted['refresh_token'] ) : 0, 'expires_at' => ! empty( $mcua_olx_persisted['token_expires_at'] ) ? absint( $mcua_olx_persisted['token_expires_at'] ) : 0, 'time' => time() ), false );
    }

    public function mcua_olx_render_settings_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'marketplace-connector-ua-for-woocommerce' ) );
        }
        $mcua_olx_options = $this->mcua_olx_get_options();
        $mcua_olx_market_config = $this->mcua_olx_get_market_config( $mcua_olx_options['market'] );
        $mcua_olx_connect_url = wp_nonce_url( admin_url( 'admin-post.php?action=mcua_olx_oauth_start' ), 'mcua_olx_oauth_start' );
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Marketplace Connector UA for WooCommerce', 'marketplace-connector-ua-for-woocommerce' ); ?></h1>
            <p><?php echo esc_html__( 'Manual WooCommerce product synchronization for the OLX.ua marketplace. This plugin is not affiliated with, endorsed by, or sponsored by OLX Group.', 'marketplace-connector-ua-for-woocommerce' ); ?></p>
            <?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Admin notice flag after OAuth redirect. ?>
            <?php if ( isset( $_GET['mcua_olx_oauth_connected'] ) && ! empty( $mcua_olx_options['access_token'] ) ) : ?>
                <div class="notice notice-success"><p><?php echo esc_html__( 'OLX OAuth connection completed and token saved.', 'marketplace-connector-ua-for-woocommerce' ); ?></p></div>
            <?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Admin notice flag after OAuth redirect. ?>
            <?php elseif ( isset( $_GET['mcua_olx_oauth_connected'] ) ) : ?>
                <div class="notice notice-warning"><p><?php echo esc_html__( 'OLX returned to this page, but no access token is saved yet. Please use the exact callback URI and complete the Connect with OLX flow again.', 'marketplace-connector-ua-for-woocommerce' ); ?></p></div>
            <?php endif; ?>
            <?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Admin notice flag after OAuth redirect. ?>
            <?php if ( isset( $_GET['mcua_olx_oauth_error'] ) ) : ?>
                <?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Admin notice flag after OAuth redirect. ?>
                <div class="notice notice-error"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['mcua_olx_oauth_error'] ) ) ); ?></p></div>
            <?php endif; ?>
            <?php $mcua_olx_oauth_debug = get_option( 'mcua_olx_last_oauth_debug', array() ); ?>
            <?php if ( ! empty( $mcua_olx_oauth_debug ) && is_array( $mcua_olx_oauth_debug ) ) : ?>
                <div class="notice notice-info"><p><strong><?php echo esc_html__( 'Last OAuth debug:', 'marketplace-connector-ua-for-woocommerce' ); ?></strong> <?php echo esc_html( wp_json_encode( $mcua_olx_oauth_debug ) ); ?></p></div>
            <?php endif; ?>
            <form method="post" action="options.php">
                <?php settings_fields( 'mcua_olx_settings_group' ); ?>
                <?php wp_nonce_field( self::MCUA_OLX_NONCE_ACTION, 'mcua_olx_settings_nonce' ); ?>
                <table class="form-table" role="presentation">
                    <tr><th scope="row"><label for="mcua_olx_market"><?php echo esc_html__( 'Market', 'marketplace-connector-ua-for-woocommerce' ); ?></label></th><td><select id="mcua_olx_market" name="<?php echo esc_attr( self::MCUA_OLX_OPTION ); ?>[market]"><?php foreach ( array( 'ua' => 'Ukraine' ) as $mcua_olx_key => $mcua_olx_label ) : ?><option value="<?php echo esc_attr( $mcua_olx_key ); ?>" <?php selected( $mcua_olx_options['market'], $mcua_olx_key ); ?>><?php echo esc_html( $mcua_olx_label ); ?></option><?php endforeach; ?></select><p class="description"><?php echo esc_html( sprintf( 'Current API base: %s', $mcua_olx_market_config['base_url'] ) ); ?></p></td></tr>
                    <tr><th scope="row"><label for="mcua_olx_client_id">Client ID</label></th><td><input id="mcua_olx_client_id" class="regular-text" name="<?php echo esc_attr( self::MCUA_OLX_OPTION ); ?>[client_id]" value="<?php echo esc_attr( $mcua_olx_options['client_id'] ); ?>"></td></tr>
                    <tr><th scope="row"><label for="mcua_olx_client_secret">Client Secret</label></th><td><input id="mcua_olx_client_secret" type="password" class="regular-text" name="<?php echo esc_attr( self::MCUA_OLX_OPTION ); ?>[client_secret]" value="" placeholder="<?php echo esc_attr__( 'Leave empty to keep saved value', 'marketplace-connector-ua-for-woocommerce' ); ?>"></td></tr>
                    <tr><th scope="row"><?php echo esc_html__( 'OAuth connection', 'marketplace-connector-ua-for-woocommerce' ); ?></th><td><a class="button" href="<?php echo esc_url( $mcua_olx_connect_url ); ?>"><?php echo esc_html__( 'Connect with OLX', 'marketplace-connector-ua-for-woocommerce' ); ?></a><p class="description"><?php echo esc_html__( 'Save Client ID and Client Secret first, then connect. Manual token fields below remain available for advanced troubleshooting.', 'marketplace-connector-ua-for-woocommerce' ); ?></p></td></tr>
                    <tr><th scope="row"><label for="mcua_olx_access_token">Access Token</label></th><td><textarea id="mcua_olx_access_token" class="large-text" rows="3" name="<?php echo esc_attr( self::MCUA_OLX_OPTION ); ?>[access_token]" placeholder="<?php echo esc_attr__( 'Leave empty to keep saved value', 'marketplace-connector-ua-for-woocommerce' ); ?>"></textarea></td></tr>
                    <tr><th scope="row"><label for="mcua_olx_refresh_token">Refresh Token</label></th><td><textarea id="mcua_olx_refresh_token" class="large-text" rows="3" name="<?php echo esc_attr( self::MCUA_OLX_OPTION ); ?>[refresh_token]" placeholder="<?php echo esc_attr__( 'Leave empty to keep saved value', 'marketplace-connector-ua-for-woocommerce' ); ?>"></textarea></td></tr>
                    <tr><th scope="row"><label for="mcua_olx_currency">Currency</label></th><td><input id="mcua_olx_currency" name="<?php echo esc_attr( self::MCUA_OLX_OPTION ); ?>[currency]" value="<?php echo esc_attr( $mcua_olx_options['currency'] ); ?>" placeholder="<?php echo esc_attr( $mcua_olx_market_config['currency'] ); ?>"></td></tr>
                    <tr><th scope="row">Advertiser type</th><td><select name="<?php echo esc_attr( self::MCUA_OLX_OPTION ); ?>[advertiser_type]"><option value="business" <?php selected( $mcua_olx_options['advertiser_type'], 'business' ); ?>>business</option><option value="private" <?php selected( $mcua_olx_options['advertiser_type'], 'private' ); ?>>private</option></select></td></tr>
                    <tr><th scope="row"><label for="mcua_olx_contact_name">Contact name</label></th><td><input id="mcua_olx_contact_name" class="regular-text" name="<?php echo esc_attr( self::MCUA_OLX_OPTION ); ?>[contact_name]" value="<?php echo esc_attr( $mcua_olx_options['contact_name'] ); ?>"></td></tr>
                    <tr><th scope="row"><label for="mcua_olx_contact_phone">Contact phone</label></th><td><input id="mcua_olx_contact_phone" class="regular-text" name="<?php echo esc_attr( self::MCUA_OLX_OPTION ); ?>[contact_phone]" value="<?php echo esc_attr( $mcua_olx_options['contact_phone'] ); ?>"></td></tr>
                    <tr><th scope="row"><label for="mcua_olx_city_id">Default city ID</label></th><td><input id="mcua_olx_city_id" type="number" name="<?php echo esc_attr( self::MCUA_OLX_OPTION ); ?>[city_id]" value="<?php echo esc_attr( $mcua_olx_options['city_id'] ); ?>"></td></tr>
                    <tr><th scope="row"><label for="mcua_olx_district_id">Default district ID</label></th><td><input id="mcua_olx_district_id" type="number" name="<?php echo esc_attr( self::MCUA_OLX_OPTION ); ?>[district_id]" value="<?php echo esc_attr( $mcua_olx_options['district_id'] ); ?>"></td></tr>
                    <tr><th scope="row"><?php echo esc_html__( 'Uninstall cleanup', 'marketplace-connector-ua-for-woocommerce' ); ?></th><td><label><input type="checkbox" name="<?php echo esc_attr( self::MCUA_OLX_OPTION ); ?>[cleanup_data]" value="1" <?php checked( $mcua_olx_options['cleanup_data'], '1' ); ?>> <?php echo esc_html__( 'Remove plugin options, category mappings and OLX advert meta on uninstall.', 'marketplace-connector-ua-for-woocommerce' ); ?></label></td></tr>
                </table>
                <?php submit_button( esc_html__( 'Save settings', 'marketplace-connector-ua-for-woocommerce' ) ); ?>
            </form>
        </div>
        <?php
    }
}
