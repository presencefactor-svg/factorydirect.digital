<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class MCUA_OLX_Plugin {
    private static $mcua_olx_instance = null;

    private $mcua_olx_settings;
    private $mcua_olx_category_map;
    private $mcua_olx_product_sync;

    public static function mcua_olx_instance() {
        if ( null === self::$mcua_olx_instance ) {
            self::$mcua_olx_instance = new self();
        }
        return self::$mcua_olx_instance;
    }

    private function __construct() {
        $this->mcua_olx_settings     = new MCUA_OLX_Settings();
        $this->mcua_olx_category_map = new MCUA_OLX_Category_Map();
        $this->mcua_olx_product_sync = new MCUA_OLX_Product_Sync( $this->mcua_olx_settings, $this->mcua_olx_category_map );

        add_action( 'admin_menu', array( $this, 'mcua_olx_admin_menu' ) );
        add_action( 'admin_init', array( $this->mcua_olx_settings, 'mcua_olx_register_settings' ) );
        add_action( 'admin_init', array( $this->mcua_olx_category_map, 'mcua_olx_handle_category_map_save' ) );
        add_action( 'admin_post_mcua_olx_oauth_start', array( $this->mcua_olx_settings, 'mcua_olx_handle_oauth_start' ) );
        add_action( 'admin_post_mcua_olx_oauth_callback', array( $this->mcua_olx_settings, 'mcua_olx_handle_oauth_callback' ) );

        $this->mcua_olx_product_sync->mcua_olx_register_hooks();

        /**
         * Extension hook: keep this free plugin manual-only; add automation in add-ons if needed.
         */
        do_action( 'mcua_olx_lite_loaded', $this );
    }

    public function mcua_olx_admin_menu() {
        add_menu_page(
            esc_html__( 'Marketplace Connector UA for WooCommerce', 'marketplace-connector-ua-for-woocommerce' ),
            esc_html__( 'Marketplace Connector UA for WooCommerce', 'marketplace-connector-ua-for-woocommerce' ),
            'manage_woocommerce',
            'mcua_olx-settings',
            array( $this->mcua_olx_settings, 'mcua_olx_render_settings_page' ),
            'dashicons-store',
            56
        );

        add_submenu_page(
            'mcua_olx-settings',
            esc_html__( 'Category Mapping', 'marketplace-connector-ua-for-woocommerce' ),
            esc_html__( 'Category Mapping', 'marketplace-connector-ua-for-woocommerce' ),
            'manage_woocommerce',
            'mcua_olx-category-map',
            array( $this->mcua_olx_category_map, 'mcua_olx_render_category_map_page' )
        );
    }

    public function mcua_olx_get_product_sync() {
        return $this->mcua_olx_product_sync;
    }

}
