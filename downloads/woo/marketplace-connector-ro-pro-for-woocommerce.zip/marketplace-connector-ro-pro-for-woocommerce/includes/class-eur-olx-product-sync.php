<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCROP_OLX_Product_Sync {
    const MCROP_OLX_ADVERT_ID_META = '_mcrop_olx_advert_id';
    const MCROP_OLX_STATUS_META    = '_mcrop_olx_status';
    const MCROP_OLX_LAST_ERROR_META= '_mcrop_olx_last_error';
    const MCROP_OLX_SYNC_NONCE     = 'mcrop_olx_sync_product_nonce_action';

    private $mcrop_olx_settings;
    private $mcrop_olx_category_map;
    private $mcrop_olx_api_client;

    public function __construct( MCROP_OLX_Settings $mcrop_olx_settings, MCROP_OLX_Category_Map $mcrop_olx_category_map ) {
        $this->mcrop_olx_settings     = $mcrop_olx_settings;
        $this->mcrop_olx_category_map = $mcrop_olx_category_map;
        $this->mcrop_olx_api_client   = new MCROP_OLX_API_Client( $mcrop_olx_settings );
    }

    public function mcrop_olx_register_hooks() {
        add_action( 'add_meta_boxes_product', array( $this, 'mcrop_olx_add_product_metabox' ) );
        add_action( 'admin_post_mcrop_olx_sync_product', array( $this, 'mcrop_olx_handle_manual_sync' ) );
        add_filter( 'bulk_actions-edit-product', array( $this, 'mcrop_olx_register_bulk_actions' ) );
        add_filter( 'handle_bulk_actions-edit-product', array( $this, 'mcrop_olx_handle_bulk_actions' ), 10, 3 );
    }

    public function mcrop_olx_add_product_metabox() {
        add_meta_box(
            'mcrop_olx_product_sync',
            esc_html__( 'Marketplace Connector RO PRO Sync', 'marketplace-connector-ro-pro-for-woocommerce' ),
            array( $this, 'mcrop_olx_render_product_metabox' ),
            'product',
            'side',
            'default'
        );
    }

    public function mcrop_olx_render_product_metabox( $mcrop_olx_post ) {
        if ( ! current_user_can( 'edit_product', $mcrop_olx_post->ID ) ) {
            return;
        }
        $mcrop_olx_advert_id = get_post_meta( $mcrop_olx_post->ID, self::MCROP_OLX_ADVERT_ID_META, true );
        $mcrop_olx_status    = get_post_meta( $mcrop_olx_post->ID, self::MCROP_OLX_STATUS_META, true );
        $mcrop_olx_error     = get_post_meta( $mcrop_olx_post->ID, self::MCROP_OLX_LAST_ERROR_META, true );
        $mcrop_olx_url       = wp_nonce_url(
            admin_url( 'admin-post.php?action=mcrop_olx_sync_product&product_id=' . absint( $mcrop_olx_post->ID ) ),
            self::MCROP_OLX_SYNC_NONCE,
            'mcrop_olx_nonce'
        );
        echo '<p><strong>' . esc_html__( 'Advert ID:', 'marketplace-connector-ro-pro-for-woocommerce' ) . '</strong> ' . esc_html( $mcrop_olx_advert_id ? $mcrop_olx_advert_id : '-' ) . '</p>';
        echo '<p><strong>' . esc_html__( 'Status:', 'marketplace-connector-ro-pro-for-woocommerce' ) . '</strong> ' . esc_html( $mcrop_olx_status ? $mcrop_olx_status : '-' ) . '</p>';
        if ( $mcrop_olx_error ) {
            echo '<p class="description" style="color:#b32d2e;">' . esc_html( $mcrop_olx_error ) . '</p>';
        }
        echo '<p><a class="button button-primary" href="' . esc_url( $mcrop_olx_url ) . '">' . esc_html__( 'Sync to OLX', 'marketplace-connector-ro-pro-for-woocommerce' ) . '</a></p>';
    }

    public function mcrop_olx_handle_manual_sync() {
        $mcrop_olx_product_id = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0;
        if ( ! $mcrop_olx_product_id || ! current_user_can( 'edit_product', $mcrop_olx_product_id ) ) {
            wp_die( esc_html__( 'You do not have permission to sync this product.', 'marketplace-connector-ro-pro-for-woocommerce' ) );
        }
        check_admin_referer( self::MCROP_OLX_SYNC_NONCE, 'mcrop_olx_nonce' );

        $mcrop_olx_result = $this->mcrop_olx_sync_product( $mcrop_olx_product_id );
        $mcrop_olx_args   = is_wp_error( $mcrop_olx_result )
            ? array( 'mcrop_olx_error' => rawurlencode( $mcrop_olx_result->get_error_message() ) )
            : array( 'mcrop_olx_message' => rawurlencode( esc_html__( 'Product synced to OLX.ro.', 'marketplace-connector-ro-pro-for-woocommerce' ) ) );

        wp_safe_redirect( add_query_arg( $mcrop_olx_args, get_edit_post_link( $mcrop_olx_product_id, 'url' ) ) );
        exit;
    }

    public function mcrop_olx_register_bulk_actions( $mcrop_olx_actions ) {
        $mcrop_olx_actions['mcrop_olx_bulk_sync'] = esc_html__( 'Sync to Marketplace Connector RO PRO', 'marketplace-connector-ro-pro-for-woocommerce' );
        return $mcrop_olx_actions;
    }

    public function mcrop_olx_handle_bulk_actions( $mcrop_olx_redirect, $mcrop_olx_action, $mcrop_olx_product_ids ) {
        if ( 'mcrop_olx_bulk_sync' !== $mcrop_olx_action ) {
            return $mcrop_olx_redirect;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return $mcrop_olx_redirect;
        }
        // WordPress core verifies the bulk action nonce before this filter is called.
        $mcrop_olx_success = 0;
        $mcrop_olx_failed  = 0;
        foreach ( array_map( 'absint', (array) $mcrop_olx_product_ids ) as $mcrop_olx_product_id ) {
            $mcrop_olx_result = $this->mcrop_olx_sync_product( $mcrop_olx_product_id );
            is_wp_error( $mcrop_olx_result ) ? $mcrop_olx_failed++ : $mcrop_olx_success++;
        }
        return add_query_arg( array( 'mcrop_olx_success' => $mcrop_olx_success, 'mcrop_olx_failed' => $mcrop_olx_failed ), $mcrop_olx_redirect );
    }

    public function mcrop_olx_sync_product( $mcrop_olx_product_id ) {
        if ( ! function_exists( 'wc_get_product' ) ) {
            return new WP_Error( 'mcrop_olx_missing_wc', esc_html__( 'WooCommerce is not active.', 'marketplace-connector-ro-pro-for-woocommerce' ) );
        }

        $mcrop_olx_product = wc_get_product( absint( $mcrop_olx_product_id ) );
        if ( ! $mcrop_olx_product ) {
            return new WP_Error( 'mcrop_olx_missing_product', esc_html__( 'Product not found.', 'marketplace-connector-ro-pro-for-woocommerce' ) );
        }

        $mcrop_olx_payload = $this->mcrop_olx_build_advert_payload( $mcrop_olx_product );
        if ( is_wp_error( $mcrop_olx_payload ) ) {
            return $mcrop_olx_payload;
        }

        /** Hook for PRO/custom payload changes: variations, custom attributes, GPS, delivery, safety regulations. */
        $mcrop_olx_payload = apply_filters( 'mcrop_olx_advert_payload', $mcrop_olx_payload, $mcrop_olx_product );
        do_action( 'mcrop_olx_before_manual_sync', $mcrop_olx_product->get_id(), $mcrop_olx_payload );

        $mcrop_olx_existing_advert_id = get_post_meta( $mcrop_olx_product->get_id(), self::MCROP_OLX_ADVERT_ID_META, true );
        $mcrop_olx_response = $mcrop_olx_existing_advert_id ? $this->mcrop_olx_api_client->mcrop_olx_update_v2_advert( $mcrop_olx_existing_advert_id, $mcrop_olx_payload ) : $this->mcrop_olx_api_client->mcrop_olx_post_v2_advert( $mcrop_olx_payload );
        if ( is_wp_error( $mcrop_olx_response ) ) {
            update_post_meta( $mcrop_olx_product->get_id(), self::MCROP_OLX_LAST_ERROR_META, sanitize_text_field( $mcrop_olx_response->get_error_message() ) );
            return $mcrop_olx_response;
        }

        if ( isset( $mcrop_olx_response['id'] ) ) {
            update_post_meta( $mcrop_olx_product->get_id(), self::MCROP_OLX_ADVERT_ID_META, absint( $mcrop_olx_response['id'] ) );
        }
        if ( isset( $mcrop_olx_response['status'] ) ) {
            update_post_meta( $mcrop_olx_product->get_id(), self::MCROP_OLX_STATUS_META, sanitize_text_field( $mcrop_olx_response['status'] ) );
        }
        delete_post_meta( $mcrop_olx_product->get_id(), self::MCROP_OLX_LAST_ERROR_META );
        do_action( 'mcrop_olx_after_manual_sync', $mcrop_olx_product->get_id(), $mcrop_olx_response );

        return $mcrop_olx_response;
    }

    private function mcrop_olx_build_advert_payload( WC_Product $mcrop_olx_product ) {
        $mcrop_olx_options     = $this->mcrop_olx_settings->mcrop_olx_get_options();
        $mcrop_olx_market      = $this->mcrop_olx_settings->mcrop_olx_get_market_config( $mcrop_olx_options['market'] );
        $mcrop_olx_category_id = $this->mcrop_olx_category_map->mcrop_olx_get_olx_category_id_for_product( $mcrop_olx_product->get_id() );

        if ( ! $mcrop_olx_category_id ) {
            return new WP_Error( 'mcrop_olx_missing_category', esc_html__( 'Missing OLX category mapping for this product.', 'marketplace-connector-ro-pro-for-woocommerce' ) );
        }
        if ( empty( $mcrop_olx_options['city_id'] ) || empty( $mcrop_olx_options['contact_name'] ) ) {
            return new WP_Error( 'mcrop_olx_missing_required_settings', esc_html__( 'Missing default city ID or contact name in Marketplace Connector RO PRO settings.', 'marketplace-connector-ro-pro-for-woocommerce' ) );
        }

        $mcrop_olx_title = sanitize_text_field( wp_strip_all_tags( $mcrop_olx_product->get_name() ) );
        $mcrop_olx_desc  = wp_kses_post( $mcrop_olx_product->get_description() ? $mcrop_olx_product->get_description() : $mcrop_olx_product->get_short_description() );
        $mcrop_olx_price = (float) wc_get_price_to_display( $mcrop_olx_product );
        $mcrop_olx_currency = $mcrop_olx_options['currency'] ? $mcrop_olx_options['currency'] : $mcrop_olx_market['currency'];

        $mcrop_olx_images = array();
        $mcrop_olx_image_ids = array_filter( array_unique( array_merge( array( $mcrop_olx_product->get_image_id() ), $mcrop_olx_product->get_gallery_image_ids() ) ) );
        foreach ( array_slice( $mcrop_olx_image_ids, 0, 8 ) as $mcrop_olx_image_id ) {
            $mcrop_olx_image_url = wp_get_attachment_url( absint( $mcrop_olx_image_id ) );
            if ( $mcrop_olx_image_url && $this->mcrop_olx_is_public_image_url( $mcrop_olx_image_url ) ) {
                $mcrop_olx_images[] = array( 'url' => esc_url_raw( $mcrop_olx_image_url ) );
            }
        }

        $mcrop_olx_payload = array(
            'title'           => $mcrop_olx_title,
            'description'     => $mcrop_olx_desc,
            'category_id'     => absint( $mcrop_olx_category_id ),
            'advertiser_type' => sanitize_text_field( $mcrop_olx_options['advertiser_type'] ),
            'external_id'     => (string) $mcrop_olx_product->get_id(),
            'contact'         => array(
                'name'  => sanitize_text_field( $mcrop_olx_options['contact_name'] ),
                'phone' => sanitize_text_field( $mcrop_olx_options['contact_phone'] ),
            ),
            'location'        => array_filter(
                array(
                    'city_id'     => absint( $mcrop_olx_options['city_id'] ),
                    'district_id' => ! empty( $mcrop_olx_options['district_id'] ) ? absint( $mcrop_olx_options['district_id'] ) : null,
                )
            ),
            'images'          => $mcrop_olx_images,
            'price'           => array(
                'value'      => $mcrop_olx_price,
                'currency'   => sanitize_text_field( $mcrop_olx_currency ),
                'negotiable' => false,
                'trade'      => false,
                'budget'     => false,
            ),
            'attributes'      => $this->mcrop_olx_category_map->mcrop_olx_get_attributes_for_product( $mcrop_olx_product->get_id() ),
        );

        return $mcrop_olx_payload;
    }

    private function mcrop_olx_is_public_image_url( $mcrop_olx_image_url ) {
        $mcrop_olx_host = wp_parse_url( $mcrop_olx_image_url, PHP_URL_HOST );
        if ( ! $mcrop_olx_host ) {
            return false;
        }
        $mcrop_olx_host = strtolower( $mcrop_olx_host );
        if ( 'localhost' === $mcrop_olx_host || '.local' === substr( $mcrop_olx_host, -6 ) || '.test' === substr( $mcrop_olx_host, -5 ) ) {
            return false;
        }
        if ( filter_var( $mcrop_olx_host, FILTER_VALIDATE_IP ) ) {
            return ! preg_match( '/^(127\.|10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[0-1])\.)/', $mcrop_olx_host );
        }
        return true;
    }
}
