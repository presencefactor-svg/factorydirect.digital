<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCROP_OLX_Category_Map {
    const MCROP_OLX_CATEGORY_MAP_OPTION = 'mcrop_olx_category_map';
    const MCROP_OLX_CATEGORY_MAP_NONCE = 'mcrop_olx_category_map_nonce_action';

    public function mcrop_olx_get_map() {
        $mcrop_olx_map = get_option( self::MCROP_OLX_CATEGORY_MAP_OPTION, array() );
        return is_array( $mcrop_olx_map ) ? $mcrop_olx_map : array();
    }

    public function mcrop_olx_get_mapping_for_product( $mcrop_olx_product_id ) {
        $mcrop_olx_map   = $this->mcrop_olx_get_map();
        $mcrop_olx_terms = wp_get_post_terms( absint( $mcrop_olx_product_id ), 'product_cat' );
        if ( is_wp_error( $mcrop_olx_terms ) ) {
            return array();
        }
        foreach ( $mcrop_olx_terms as $mcrop_olx_term ) {
            $mcrop_olx_term_id = (string) absint( $mcrop_olx_term->term_id );
            if ( empty( $mcrop_olx_map[ $mcrop_olx_term_id ] ) ) {
                continue;
            }
            if ( is_array( $mcrop_olx_map[ $mcrop_olx_term_id ] ) ) {
                return $mcrop_olx_map[ $mcrop_olx_term_id ];
            }
            return array( 'category_id' => absint( $mcrop_olx_map[ $mcrop_olx_term_id ] ) );
        }
        return array();
    }

    public function mcrop_olx_get_olx_category_id_for_product( $mcrop_olx_product_id ) {
        $mcrop_olx_mapping = $this->mcrop_olx_get_mapping_for_product( $mcrop_olx_product_id );
        return ! empty( $mcrop_olx_mapping['category_id'] ) ? absint( $mcrop_olx_mapping['category_id'] ) : '';
    }

    public function mcrop_olx_get_attributes_for_product( $mcrop_olx_product_id ) {
        $mcrop_olx_mapping    = $this->mcrop_olx_get_mapping_for_product( $mcrop_olx_product_id );
        $mcrop_olx_attributes = array();
        $mcrop_olx_state      = ! empty( $mcrop_olx_mapping['state'] ) ? sanitize_key( $mcrop_olx_mapping['state'] ) : 'new';
        if ( $mcrop_olx_state ) {
            $mcrop_olx_attributes[] = array( 'code' => 'state', 'value' => $mcrop_olx_state );
        }
        if ( ! empty( $mcrop_olx_mapping['attributes'] ) && is_array( $mcrop_olx_mapping['attributes'] ) ) {
            foreach ( $mcrop_olx_mapping['attributes'] as $mcrop_olx_attribute ) {
                if ( empty( $mcrop_olx_attribute['code'] ) || ! isset( $mcrop_olx_attribute['value'] ) ) {
                    continue;
                }
                $mcrop_olx_code  = sanitize_key( $mcrop_olx_attribute['code'] );
                $mcrop_olx_value = sanitize_text_field( (string) $mcrop_olx_attribute['value'] );
                if ( $mcrop_olx_code && '' !== $mcrop_olx_value ) {
                    $mcrop_olx_attributes[] = array( 'code' => $mcrop_olx_code, 'value' => $mcrop_olx_value );
                }
            }
        }
        return $this->mcrop_olx_dedupe_attributes( $mcrop_olx_attributes );
    }

    public function mcrop_olx_handle_category_map_save() {
        if ( empty( $_POST['mcrop_olx_category_map_submit'] ) ) {
            return;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to save category mapping.', 'marketplace-connector-ro-pro-for-woocommerce' ) );
        }
        check_admin_referer( self::MCROP_OLX_CATEGORY_MAP_NONCE, 'mcrop_olx_category_map_nonce' );

        $mcrop_olx_raw_map = isset( $_POST['mcrop_olx_category_map'] ) && is_array( $_POST['mcrop_olx_category_map'] ) ? map_deep( wp_unslash( $_POST['mcrop_olx_category_map'] ), 'sanitize_text_field' ) : array();
        $mcrop_olx_clean   = array();
        foreach ( $mcrop_olx_raw_map as $mcrop_olx_woo_cat_id => $mcrop_olx_row ) {
            $mcrop_olx_woo_cat_id = absint( $mcrop_olx_woo_cat_id );
            if ( ! $mcrop_olx_woo_cat_id || ! is_array( $mcrop_olx_row ) ) {
                continue;
            }
            $mcrop_olx_olx_cat_id = ! empty( $mcrop_olx_row['category_id'] ) ? absint( $mcrop_olx_row['category_id'] ) : 0;
            if ( ! $mcrop_olx_olx_cat_id ) {
                continue;
            }
            $mcrop_olx_clean[ (string) $mcrop_olx_woo_cat_id ] = array(
                'category_id'   => $mcrop_olx_olx_cat_id,
                'category_path' => isset( $mcrop_olx_row['category_path'] ) ? sanitize_text_field( $mcrop_olx_row['category_path'] ) : '',
                'state'         => isset( $mcrop_olx_row['state'] ) ? sanitize_key( $mcrop_olx_row['state'] ) : 'new',
                'attributes'    => $this->mcrop_olx_parse_attribute_lines( isset( $mcrop_olx_row['attributes'] ) ? (string) $mcrop_olx_row['attributes'] : '' ),
            );
        }
        update_option( self::MCROP_OLX_CATEGORY_MAP_OPTION, $mcrop_olx_clean, false );
        add_settings_error( 'mcrop_olx_category_map', 'mcrop_olx_category_map_saved', esc_html__( 'Category mapping saved.', 'marketplace-connector-ro-pro-for-woocommerce' ), 'updated' );
    }

    public function mcrop_olx_render_category_map_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'marketplace-connector-ro-pro-for-woocommerce' ) );
        }
        $mcrop_olx_map        = $this->mcrop_olx_get_map();
        $mcrop_olx_categories = $this->mcrop_olx_get_ro_category_suggestions();
        $mcrop_olx_terms      = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Marketplace Connector RO PRO Category Mapping', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></h1>
            <p class="description"><?php echo esc_html__( 'Map WooCommerce categories to OLX.ro category IDs and define required category attributes such as condition/state. Category ID fields include live OLX.ro API suggestions when OAuth is connected. Additional attributes use one code=value pair per line, for example brand=Samsung.', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></p>
            <?php if ( ! empty( $mcrop_olx_categories ) ) : ?>
                <datalist id="mcrop_olx_ro_categories">
                    <?php foreach ( $mcrop_olx_categories as $mcrop_olx_category ) : ?>
                        <option value="<?php echo esc_attr( $mcrop_olx_category['id'] ); ?>" label="<?php echo esc_attr( $mcrop_olx_category['name'] ); ?>"></option>
                    <?php endforeach; ?>
                </datalist>
            <?php endif; ?>
            <?php settings_errors( 'mcrop_olx_category_map' ); ?>
            <form method="post">
                <?php wp_nonce_field( self::MCROP_OLX_CATEGORY_MAP_NONCE, 'mcrop_olx_category_map_nonce' ); ?>
                <input type="hidden" name="mcrop_olx_category_map_submit" value="1">
                <table class="widefat striped">
                    <thead><tr><th><?php echo esc_html__( 'WooCommerce category', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'OLX.ro category ID', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Category note/path', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Condition', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Extra attributes', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></th></tr></thead>
                    <tbody>
                    <?php if ( ! is_wp_error( $mcrop_olx_terms ) ) : ?>
                        <?php foreach ( $mcrop_olx_terms as $mcrop_olx_term ) : ?>
                            <?php
                            $mcrop_olx_row = isset( $mcrop_olx_map[ (string) $mcrop_olx_term->term_id ] ) ? $mcrop_olx_map[ (string) $mcrop_olx_term->term_id ] : array();
                            if ( ! is_array( $mcrop_olx_row ) ) {
                                $mcrop_olx_row = array( 'category_id' => absint( $mcrop_olx_row ) );
                            }
                            $mcrop_olx_value = ! empty( $mcrop_olx_row['category_id'] ) ? absint( $mcrop_olx_row['category_id'] ) : '';
                            $mcrop_olx_state = ! empty( $mcrop_olx_row['state'] ) ? sanitize_key( $mcrop_olx_row['state'] ) : 'new';
                            ?>
                            <tr>
                                <td><?php echo esc_html( $mcrop_olx_term->name ); ?></td>
                                <td><input type="number" min="1" list="mcrop_olx_ro_categories" name="mcrop_olx_category_map[<?php echo esc_attr( $mcrop_olx_term->term_id ); ?>][category_id]" value="<?php echo esc_attr( $mcrop_olx_value ); ?>" class="small-text"></td>
                                <td><input type="text" name="mcrop_olx_category_map[<?php echo esc_attr( $mcrop_olx_term->term_id ); ?>][category_path]" value="<?php echo esc_attr( isset( $mcrop_olx_row['category_path'] ) ? $mcrop_olx_row['category_path'] : '' ); ?>" class="regular-text" placeholder="<?php echo esc_attr__( 'e.g. Home / Lighting', 'marketplace-connector-ro-pro-for-woocommerce' ); ?>"></td>
                                <td><select name="mcrop_olx_category_map[<?php echo esc_attr( $mcrop_olx_term->term_id ); ?>][state]"><option value="new" <?php selected( $mcrop_olx_state, 'new' ); ?>><?php echo esc_html__( 'New', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></option><option value="used" <?php selected( $mcrop_olx_state, 'used' ); ?>><?php echo esc_html__( 'Used', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></option></select></td>
                                <td><textarea rows="3" cols="32" name="mcrop_olx_category_map[<?php echo esc_attr( $mcrop_olx_term->term_id ); ?>][attributes]" placeholder="brand=Samsung&#10;model=A54"><?php echo esc_textarea( $this->mcrop_olx_format_attribute_lines( isset( $mcrop_olx_row['attributes'] ) && is_array( $mcrop_olx_row['attributes'] ) ? $mcrop_olx_row['attributes'] : array() ) ); ?></textarea></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
                <?php submit_button( esc_html__( 'Save mapping', 'marketplace-connector-ro-pro-for-woocommerce' ) ); ?>
            </form>
        </div>
        <?php
    }


    private function mcrop_olx_get_ro_category_suggestions() {
        $mcrop_olx_cached = get_transient( 'mcrop_olx_ro_category_suggestions' );
        if ( is_array( $mcrop_olx_cached ) ) {
            return $mcrop_olx_cached;
        }
        $mcrop_olx_options = get_option( 'mcrop_olx_options', array() );
        if ( empty( $mcrop_olx_options['access_token'] ) ) {
            return array();
        }
        $mcrop_olx_response = wp_remote_get(
            'https://www.olx.ro/api/partner/categories?limit=1000',
            array(
                'timeout' => 20,
                'headers' => array(
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer ' . $mcrop_olx_options['access_token'],
                    'Version'       => '2.0',
                ),
            )
        );
        if ( is_wp_error( $mcrop_olx_response ) || 200 !== (int) wp_remote_retrieve_response_code( $mcrop_olx_response ) ) {
            return array();
        }
        $mcrop_olx_json = json_decode( (string) wp_remote_retrieve_body( $mcrop_olx_response ), true );
        $mcrop_olx_rows = isset( $mcrop_olx_json['data'] ) && is_array( $mcrop_olx_json['data'] ) ? $mcrop_olx_json['data'] : array();
        $mcrop_olx_categories = array();
        foreach ( $mcrop_olx_rows as $mcrop_olx_row ) {
            if ( empty( $mcrop_olx_row['id'] ) || empty( $mcrop_olx_row['name'] ) ) {
                continue;
            }
            $mcrop_olx_categories[] = array(
                'id'   => absint( $mcrop_olx_row['id'] ),
                'name' => sanitize_text_field( (string) $mcrop_olx_row['name'] ),
            );
        }
        set_transient( 'mcrop_olx_ro_category_suggestions', $mcrop_olx_categories, DAY_IN_SECONDS );
        return $mcrop_olx_categories;
    }

    private function mcrop_olx_parse_attribute_lines( $mcrop_olx_raw ) {
        $mcrop_olx_attributes = array();
        foreach ( preg_split( '/\r\n|\r|\n/', (string) $mcrop_olx_raw ) as $mcrop_olx_line ) {
            $mcrop_olx_line = trim( $mcrop_olx_line );
            if ( '' === $mcrop_olx_line || false === strpos( $mcrop_olx_line, '=' ) ) {
                continue;
            }
            list( $mcrop_olx_code, $mcrop_olx_value ) = array_map( 'trim', explode( '=', $mcrop_olx_line, 2 ) );
            $mcrop_olx_code  = sanitize_key( $mcrop_olx_code );
            $mcrop_olx_value = sanitize_text_field( $mcrop_olx_value );
            if ( $mcrop_olx_code && '' !== $mcrop_olx_value ) {
                $mcrop_olx_attributes[] = array( 'code' => $mcrop_olx_code, 'value' => $mcrop_olx_value );
            }
        }
        return $this->mcrop_olx_dedupe_attributes( $mcrop_olx_attributes );
    }

    private function mcrop_olx_format_attribute_lines( array $mcrop_olx_attributes ) {
        $mcrop_olx_lines = array();
        foreach ( $mcrop_olx_attributes as $mcrop_olx_attribute ) {
            if ( ! empty( $mcrop_olx_attribute['code'] ) && isset( $mcrop_olx_attribute['value'] ) ) {
                $mcrop_olx_lines[] = sanitize_key( $mcrop_olx_attribute['code'] ) . '=' . sanitize_text_field( (string) $mcrop_olx_attribute['value'] );
            }
        }
        return implode( "\n", $mcrop_olx_lines );
    }

    private function mcrop_olx_dedupe_attributes( array $mcrop_olx_attributes ) {
        $mcrop_olx_seen = array();
        $mcrop_olx_clean = array();
        foreach ( $mcrop_olx_attributes as $mcrop_olx_attribute ) {
            if ( empty( $mcrop_olx_attribute['code'] ) || ! isset( $mcrop_olx_attribute['value'] ) ) {
                continue;
            }
            $mcrop_olx_code = sanitize_key( $mcrop_olx_attribute['code'] );
            if ( ! $mcrop_olx_code || isset( $mcrop_olx_seen[ $mcrop_olx_code ] ) ) {
                continue;
            }
            $mcrop_olx_seen[ $mcrop_olx_code ] = true;
            $mcrop_olx_clean[] = array( 'code' => $mcrop_olx_code, 'value' => sanitize_text_field( (string) $mcrop_olx_attribute['value'] ) );
        }
        return $mcrop_olx_clean;
    }
}
