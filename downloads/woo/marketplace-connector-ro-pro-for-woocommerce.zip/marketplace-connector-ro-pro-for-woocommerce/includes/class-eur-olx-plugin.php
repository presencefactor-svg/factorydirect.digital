<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class MCROP_OLX_Plugin {
    private static $mcrop_olx_instance = null;

    private $mcrop_olx_settings;
    private $mcrop_olx_category_map;
    private $mcrop_olx_product_sync;

    public static function mcrop_olx_instance() {
        if ( null === self::$mcrop_olx_instance ) {
            self::$mcrop_olx_instance = new self();
        }
        return self::$mcrop_olx_instance;
    }

    private function __construct() {
        $this->mcrop_olx_settings     = new MCROP_OLX_Settings();
        $this->mcrop_olx_category_map = new MCROP_OLX_Category_Map();
        $this->mcrop_olx_product_sync = new MCROP_OLX_Product_Sync( $this->mcrop_olx_settings, $this->mcrop_olx_category_map );

        add_action( 'admin_menu', array( $this, 'mcrop_olx_admin_menu' ) );
        add_action( 'admin_init', array( $this->mcrop_olx_settings, 'mcrop_olx_register_settings' ) );
        add_action( 'admin_init', array( $this->mcrop_olx_category_map, 'mcrop_olx_handle_category_map_save' ) );
        add_action( 'admin_post_mcrop_olx_oauth_start', array( $this->mcrop_olx_settings, 'mcrop_olx_handle_oauth_start' ) );
        add_action( 'admin_post_mcrop_olx_oauth_callback', array( $this->mcrop_olx_settings, 'mcrop_olx_handle_oauth_callback' ) );

        $this->mcrop_olx_product_sync->mcrop_olx_register_hooks();

        /**
         * Extension hook: keep this PRO plugin automation-ready; add automation in add-ons if needed.
         */
        do_action( 'mcrop_olx_lite_loaded', $this );
        new MCROP_OLX_Pro_Automation( $this->mcrop_olx_settings, $this->mcrop_olx_product_sync );
    }

    public function mcrop_olx_admin_menu() {
        add_menu_page(
            esc_html__( 'Marketplace Connector RO PRO for WooCommerce', 'marketplace-connector-ro-pro-for-woocommerce' ),
            esc_html__( 'Marketplace Connector RO PRO for WooCommerce', 'marketplace-connector-ro-pro-for-woocommerce' ),
            'manage_woocommerce',
            'mcrop_olx-settings',
            array( $this->mcrop_olx_settings, 'mcrop_olx_render_settings_page' ),
            'dashicons-store',
            56
        );

        add_submenu_page(
            'mcrop_olx-settings',
            esc_html__( 'Category Mapping', 'marketplace-connector-ro-pro-for-woocommerce' ),
            esc_html__( 'Category Mapping', 'marketplace-connector-ro-pro-for-woocommerce' ),
            'manage_woocommerce',
            'mcrop_olx-category-map',
            array( $this->mcrop_olx_category_map, 'mcrop_olx_render_category_map_page' )
        );
    }

    public function mcrop_olx_get_product_sync() {
        return $this->mcrop_olx_product_sync;
    }

}
