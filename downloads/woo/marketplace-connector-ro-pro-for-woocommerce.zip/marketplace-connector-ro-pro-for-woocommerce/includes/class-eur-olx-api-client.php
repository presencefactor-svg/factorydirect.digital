<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCROP_OLX_API_Client {
    private $mcrop_olx_settings;

    public function __construct( MCROP_OLX_Settings $mcrop_olx_settings ) {
        $this->mcrop_olx_settings = $mcrop_olx_settings;
    }

    public function mcrop_olx_request( $mcrop_olx_method, $mcrop_olx_path, $mcrop_olx_body = null ) {
        $mcrop_olx_options = $this->mcrop_olx_settings->mcrop_olx_get_options();
        if ( ( empty( $mcrop_olx_options['access_token'] ) && ! empty( $mcrop_olx_options['refresh_token'] ) ) || ( ! empty( $mcrop_olx_options['token_expires_at'] ) && absint( $mcrop_olx_options['token_expires_at'] ) < time() + 120 ) ) {
            $mcrop_olx_refreshed = $this->mcrop_olx_refresh_access_token();
            if ( ! is_wp_error( $mcrop_olx_refreshed ) ) {
                $mcrop_olx_options = $this->mcrop_olx_settings->mcrop_olx_get_options();
            }
        }

        $mcrop_olx_market = $this->mcrop_olx_settings->mcrop_olx_get_market_config( $mcrop_olx_options['market'] );
        $mcrop_olx_token  = trim( (string) $mcrop_olx_options['access_token'] );

        if ( '' === $mcrop_olx_token ) {
            return new WP_Error( 'mcrop_olx_missing_token', esc_html__( 'Missing OAuth access token.', 'marketplace-connector-ro-pro-for-woocommerce' ) );
        }

        $mcrop_olx_url = trailingslashit( $mcrop_olx_market['base_url'] ) . ltrim( $mcrop_olx_path, '/' );
        $mcrop_olx_args = array(
            'method'  => strtoupper( sanitize_key( $mcrop_olx_method ) ),
            'timeout' => 45,
            'headers' => array(
                'Accept'        => 'application/json',
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $mcrop_olx_token,
                'Version'       => '2.0',
            ),
        );

        if ( null !== $mcrop_olx_body ) {
            $mcrop_olx_args['body'] = wp_json_encode( $mcrop_olx_body );
        }

        $mcrop_olx_args = apply_filters( 'mcrop_olx_api_request_args', $mcrop_olx_args, $mcrop_olx_path, $mcrop_olx_body );
        $mcrop_olx_response = wp_remote_request( esc_url_raw( $mcrop_olx_url ), $mcrop_olx_args );
        return $this->mcrop_olx_parse_response( $mcrop_olx_response );
    }

    public function mcrop_olx_post_v2_advert( array $mcrop_olx_payload ) {
        return $this->mcrop_olx_request( 'POST', '/adverts', $mcrop_olx_payload );
    }

    public function mcrop_olx_update_v2_advert( $mcrop_olx_advert_id, array $mcrop_olx_payload ) {
        return $this->mcrop_olx_request( 'PUT', '/adverts/' . absint( $mcrop_olx_advert_id ), $mcrop_olx_payload );
    }

    public function mcrop_olx_refresh_access_token() {
        $mcrop_olx_options = $this->mcrop_olx_settings->mcrop_olx_get_options();
        if ( empty( $mcrop_olx_options['client_id'] ) || empty( $mcrop_olx_options['client_secret'] ) || empty( $mcrop_olx_options['refresh_token'] ) ) {
            return new WP_Error( 'mcrop_olx_refresh_missing_credentials', esc_html__( 'Missing OAuth refresh credentials.', 'marketplace-connector-ro-pro-for-woocommerce' ) );
        }

        $mcrop_olx_market = $this->mcrop_olx_settings->mcrop_olx_get_market_config( $mcrop_olx_options['market'] );
        $mcrop_olx_response = wp_remote_post(
            esc_url_raw( $mcrop_olx_market['token_url'] ),
            array(
                'timeout' => 45,
                'headers' => array( 'Accept' => 'application/json' ),
                'body'    => array(
                    'grant_type'    => 'refresh_token',
                    'client_id'     => $mcrop_olx_options['client_id'],
                    'client_secret' => $mcrop_olx_options['client_secret'],
                    'refresh_token' => $mcrop_olx_options['refresh_token'],
                ),
            )
        );

        $mcrop_olx_json = $this->mcrop_olx_parse_response( $mcrop_olx_response );
        if ( is_wp_error( $mcrop_olx_json ) ) {
            return $mcrop_olx_json;
        }
        $this->mcrop_olx_settings->mcrop_olx_save_tokens_from_response( $mcrop_olx_json );
        return $mcrop_olx_json;
    }

    private function mcrop_olx_parse_response( $mcrop_olx_response ) {
        if ( is_wp_error( $mcrop_olx_response ) ) {
            return $mcrop_olx_response;
        }
        $mcrop_olx_code = (int) wp_remote_retrieve_response_code( $mcrop_olx_response );
        $mcrop_olx_raw  = (string) wp_remote_retrieve_body( $mcrop_olx_response );
        $mcrop_olx_json = json_decode( $mcrop_olx_raw, true );
        if ( $mcrop_olx_code < 200 || $mcrop_olx_code >= 300 ) {
            return new WP_Error(
                'mcrop_olx_api_error',
                sprintf(
                    /* translators: 1: HTTP status code, 2: response body */
                    esc_html__( 'OLX API error %1$d: %2$s', 'marketplace-connector-ro-pro-for-woocommerce' ),
                    $mcrop_olx_code,
                    is_array( $mcrop_olx_json ) ? wp_json_encode( $mcrop_olx_json ) : $mcrop_olx_raw
                )
            );
        }
        if ( is_array( $mcrop_olx_json ) && array_key_exists( 'data', $mcrop_olx_json ) ) {
            return is_array( $mcrop_olx_json['data'] ) ? $mcrop_olx_json['data'] : array( 'data' => $mcrop_olx_json['data'] );
        }
        return is_array( $mcrop_olx_json ) ? $mcrop_olx_json : array( 'raw' => $mcrop_olx_raw );
    }
}
