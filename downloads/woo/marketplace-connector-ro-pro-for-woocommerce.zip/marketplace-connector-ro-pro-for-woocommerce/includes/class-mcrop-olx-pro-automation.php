<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCROP_OLX_Pro_Automation {
    const MCROP_OLX_CRON_HOOK = 'mcrop_olx_pro_cron_sync';

    private $mcrop_olx_settings;
    private $mcrop_olx_product_sync;

    public function __construct( MCROP_OLX_Settings $mcrop_olx_settings, MCROP_OLX_Product_Sync $mcrop_olx_product_sync ) {
        $this->mcrop_olx_settings     = $mcrop_olx_settings;
        $this->mcrop_olx_product_sync = $mcrop_olx_product_sync;

        add_filter( 'cron_schedules', array( $this, 'mcrop_olx_cron_schedules' ) );
        add_action( 'init', array( $this, 'mcrop_olx_maybe_schedule_cron' ) );
        add_action( self::MCROP_OLX_CRON_HOOK, array( $this, 'mcrop_olx_run_cron_sync' ) );
        add_action( 'save_post_product', array( $this, 'mcrop_olx_auto_sync_on_save' ), 20, 2 );
        add_action( 'woocommerce_product_set_stock_status', array( $this, 'mcrop_olx_stock_status_sync' ), 20, 3 );
    }

    public function mcrop_olx_cron_schedules( $schedules ) {
        if ( ! isset( $schedules['mcrop_olx_hourly'] ) ) {
            $schedules['mcrop_olx_hourly'] = array(
                'interval' => HOUR_IN_SECONDS,
                'display'  => esc_html__( 'Marketplace Connector PRO hourly', 'marketplace-connector-ro-pro-for-woocommerce' ),
            );
        }
        return $schedules;
    }

    public function mcrop_olx_maybe_schedule_cron() {
        $options = $this->mcrop_olx_settings->mcrop_olx_get_options();
        $enabled = ! empty( $options['pro_cron_sync'] ) && '1' === $options['pro_cron_sync'];
        $next = wp_next_scheduled( self::MCROP_OLX_CRON_HOOK );
        if ( $enabled && ! $next ) {
            wp_schedule_event( time() + 300, 'mcrop_olx_hourly', self::MCROP_OLX_CRON_HOOK );
        } elseif ( ! $enabled && $next ) {
            wp_clear_scheduled_hook( self::MCROP_OLX_CRON_HOOK );
        }
    }

    public function mcrop_olx_auto_sync_on_save( $post_id, $post ) {
        $options = $this->mcrop_olx_settings->mcrop_olx_get_options();
        if ( empty( $options['pro_auto_sync_on_save'] ) || '1' !== $options['pro_auto_sync_on_save'] ) {
            return;
        }
        if ( wp_is_post_revision( $post_id ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) {
            return;
        }
        if ( ! $post || 'publish' !== $post->post_status || ! current_user_can( 'edit_product', $post_id ) ) {
            return;
        }
        $this->mcrop_olx_product_sync->mcrop_olx_sync_product( absint( $post_id ) );
    }

    public function mcrop_olx_stock_status_sync( $product_id, $stock_status, $product ) {
        $options = $this->mcrop_olx_settings->mcrop_olx_get_options();
        if ( empty( $options['pro_stock_status_sync'] ) || '1' !== $options['pro_stock_status_sync'] ) {
            return;
        }
        $product_id = absint( $product_id );
        if ( ! $product_id || ! get_post_meta( $product_id, MCROP_OLX_Product_Sync::MCROP_OLX_ADVERT_ID_META, true ) ) {
            return;
        }
        $this->mcrop_olx_product_sync->mcrop_olx_sync_product( $product_id );
    }

    public function mcrop_olx_run_cron_sync() {
        $options = $this->mcrop_olx_settings->mcrop_olx_get_options();
        if ( empty( $options['pro_cron_sync'] ) || '1' !== $options['pro_cron_sync'] || ! function_exists( 'wc_get_products' ) ) {
            return;
        }
        $limit = ! empty( $options['pro_cron_limit'] ) ? absint( $options['pro_cron_limit'] ) : 20;
        $ids = wc_get_products( array(
            'status'     => 'publish',
            'limit'      => max( 1, min( 200, $limit ) ),
            'return'     => 'ids',
            'meta_key'   => MCROP_OLX_Product_Sync::MCROP_OLX_ADVERT_ID_META,
            'meta_compare' => 'EXISTS',
        ) );
        foreach ( array_map( 'absint', $ids ) as $product_id ) {
            $this->mcrop_olx_product_sync->mcrop_olx_sync_product( $product_id );
        }
    }
}
