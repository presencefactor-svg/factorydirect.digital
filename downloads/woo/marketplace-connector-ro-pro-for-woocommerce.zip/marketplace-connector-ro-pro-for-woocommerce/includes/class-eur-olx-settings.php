<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCROP_OLX_Settings {
    const MCROP_OLX_OPTION = 'mcrop_olx_options';
    const MCROP_OLX_NONCE_ACTION = 'mcrop_olx_settings_nonce_action';
    const MCROP_OLX_OAUTH_STATE_TRANSIENT_PREFIX = 'mcrop_olx_oauth_state_';

    public function mcrop_olx_get_defaults() {
        return array(
            'market'           => 'ro',
            'client_id'        => '',
            'client_secret'    => '',
            'access_token'     => '',
            'refresh_token'    => '',
            'token_expires_at' => '',
            'currency'         => '',
            'advertiser_type'  => 'business',
            'contact_name'     => '',
            'contact_phone'    => '',
            'city_id'          => '',
            'district_id'      => '',
            'pro_auto_sync_on_save' => '0',
            'pro_stock_status_sync' => '0',
            'pro_cron_sync'         => '0',
            'pro_cron_limit'        => 20,
            'cleanup_data'     => '0',
        );
    }

    public function mcrop_olx_get_options() {
        $mcrop_olx_options = get_option( self::MCROP_OLX_OPTION, array() );
        return wp_parse_args( is_array( $mcrop_olx_options ) ? $mcrop_olx_options : array(), $this->mcrop_olx_get_defaults() );
    }

    public function mcrop_olx_register_settings() {
        register_setting(
            'mcrop_olx_settings_group',
            self::MCROP_OLX_OPTION,
            array(
                'type'              => 'array',
                'sanitize_callback' => array( $this, 'mcrop_olx_sanitize_options' ),
                'default'           => $this->mcrop_olx_get_defaults(),
            )
        );
    }

    public function mcrop_olx_sanitize_options( $mcrop_olx_input ) {
        $mcrop_olx_old = $this->mcrop_olx_get_options();
        if ( ! isset( $_POST['mcrop_olx_settings_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mcrop_olx_settings_nonce'] ) ), self::MCROP_OLX_NONCE_ACTION ) ) {
            add_settings_error( 'mcrop_olx_settings', 'mcrop_olx_settings_nonce_failed', esc_html__( 'Security check failed. Settings were not saved.', 'marketplace-connector-ro-pro-for-woocommerce' ), 'error' );
            return $mcrop_olx_old;
        }

        $mcrop_olx_input = is_array( $mcrop_olx_input ) ? wp_unslash( $mcrop_olx_input ) : array();
        $mcrop_olx_allowed_markets = array( 'ro' );
        $mcrop_olx_market = isset( $mcrop_olx_input['market'] ) ? sanitize_key( $mcrop_olx_input['market'] ) : 'ro';

        return array(
            'market'           => in_array( $mcrop_olx_market, $mcrop_olx_allowed_markets, true ) ? $mcrop_olx_market : 'pl',
            'client_id'        => isset( $mcrop_olx_input['client_id'] ) ? sanitize_text_field( $mcrop_olx_input['client_id'] ) : '',
            'client_secret'    => isset( $mcrop_olx_input['client_secret'] ) && '' !== $mcrop_olx_input['client_secret'] ? sanitize_text_field( $mcrop_olx_input['client_secret'] ) : $mcrop_olx_old['client_secret'],
            'access_token'     => isset( $mcrop_olx_input['access_token'] ) && '' !== $mcrop_olx_input['access_token'] ? sanitize_textarea_field( $mcrop_olx_input['access_token'] ) : $mcrop_olx_old['access_token'],
            'refresh_token'    => isset( $mcrop_olx_input['refresh_token'] ) && '' !== $mcrop_olx_input['refresh_token'] ? sanitize_textarea_field( $mcrop_olx_input['refresh_token'] ) : $mcrop_olx_old['refresh_token'],
            'token_expires_at' => isset( $mcrop_olx_input['token_expires_at'] ) ? absint( $mcrop_olx_input['token_expires_at'] ) : absint( $mcrop_olx_old['token_expires_at'] ),
            'currency'         => isset( $mcrop_olx_input['currency'] ) ? strtoupper( sanitize_text_field( $mcrop_olx_input['currency'] ) ) : '',
            'advertiser_type'  => isset( $mcrop_olx_input['advertiser_type'] ) && in_array( $mcrop_olx_input['advertiser_type'], array( 'private', 'business' ), true ) ? sanitize_key( $mcrop_olx_input['advertiser_type'] ) : 'business',
            'contact_name'     => isset( $mcrop_olx_input['contact_name'] ) ? sanitize_text_field( $mcrop_olx_input['contact_name'] ) : '',
            'contact_phone'    => isset( $mcrop_olx_input['contact_phone'] ) ? sanitize_text_field( $mcrop_olx_input['contact_phone'] ) : '',
            'city_id'          => isset( $mcrop_olx_input['city_id'] ) ? absint( $mcrop_olx_input['city_id'] ) : '',
            'district_id'      => isset( $mcrop_olx_input['district_id'] ) ? absint( $mcrop_olx_input['district_id'] ) : '',
            'pro_auto_sync_on_save' => ! empty( $mcrop_olx_input['pro_auto_sync_on_save'] ) ? '1' : '0',
            'pro_stock_status_sync' => ! empty( $mcrop_olx_input['pro_stock_status_sync'] ) ? '1' : '0',
            'pro_cron_sync'         => ! empty( $mcrop_olx_input['pro_cron_sync'] ) ? '1' : '0',
            'pro_cron_limit'        => isset( $mcrop_olx_input['pro_cron_limit'] ) ? max( 1, min( 200, absint( $mcrop_olx_input['pro_cron_limit'] ) ) ) : 20,
            'cleanup_data'     => ! empty( $mcrop_olx_input['cleanup_data'] ) ? '1' : '0',
        );
    }

    public function mcrop_olx_get_market_config( $mcrop_olx_market = '' ) {
        $mcrop_olx_market = $mcrop_olx_market ? sanitize_key( $mcrop_olx_market ) : $this->mcrop_olx_get_options()['market'];
        $mcrop_olx_markets = array(
            'ro' => array( 'label' => 'Romania', 'base_url' => 'https://www.olx.ro/api/partner', 'oauth_url' => 'https://www.olx.ro/oauth/authorize', 'token_url' => 'https://www.olx.ro/api/open/oauth/token', 'currency' => 'RON' ),
        );
        $mcrop_olx_markets = apply_filters( 'mcrop_olx_market_configs', $mcrop_olx_markets );
        return isset( $mcrop_olx_markets[ $mcrop_olx_market ] ) ? $mcrop_olx_markets[ $mcrop_olx_market ] : $mcrop_olx_markets['ro'];
    }

    public function mcrop_olx_get_oauth_redirect_uri() {
        return admin_url( 'admin-post.php?action=mcrop_olx_oauth_callback' );
    }

    public function mcrop_olx_handle_oauth_start() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to connect OLX.', 'marketplace-connector-ro-pro-for-woocommerce' ) );
        }
        check_admin_referer( 'mcrop_olx_oauth_start' );
        $mcrop_olx_options = $this->mcrop_olx_get_options();
        if ( empty( $mcrop_olx_options['client_id'] ) ) {
            wp_safe_redirect( add_query_arg( 'mcrop_olx_oauth_error', rawurlencode( __( 'Client ID is required before connecting.', 'marketplace-connector-ro-pro-for-woocommerce' ) ), admin_url( 'admin.php?page=mcrop_olx-settings' ) ) );
            exit;
        }
        $mcrop_olx_market = $this->mcrop_olx_get_market_config( $mcrop_olx_options['market'] );
        $mcrop_olx_state = wp_generate_password( 32, false, false );
        set_transient( self::MCROP_OLX_OAUTH_STATE_TRANSIENT_PREFIX . $mcrop_olx_state, get_current_user_id(), 10 * MINUTE_IN_SECONDS );
        $mcrop_olx_scopes = apply_filters( 'mcrop_olx_oauth_scopes', array( 'v2', 'read', 'write' ) );
        $mcrop_olx_auth_query = http_build_query(
            array(
                'response_type' => 'code',
                'client_id'     => $mcrop_olx_options['client_id'],
                'redirect_uri'  => $this->mcrop_olx_get_oauth_redirect_uri(),
                'scope'         => implode( ' ', array_map( 'sanitize_key', (array) $mcrop_olx_scopes ) ),
                'state'         => $mcrop_olx_state,
            ),
            '',
            '&',
            PHP_QUERY_RFC3986
        );
        $mcrop_olx_auth_url = $mcrop_olx_market['oauth_url'] . '?' . $mcrop_olx_auth_query;
        update_option( 'mcrop_olx_last_oauth_debug', array( 'phase' => 'start', 'redirect_uri' => $this->mcrop_olx_get_oauth_redirect_uri(), 'auth_host' => wp_parse_url( $mcrop_olx_market['oauth_url'], PHP_URL_HOST ), 'time' => time() ), false );
        wp_redirect( esc_url_raw( $mcrop_olx_auth_url ) ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- External OAuth authorization URL is built from fixed OLX market configuration.
        exit;
    }

    public function mcrop_olx_handle_oauth_callback() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to connect OLX.', 'marketplace-connector-ro-pro-for-woocommerce' ) );
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- OAuth callbacks are validated via the provider state parameter.
        $mcrop_olx_state = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- OAuth callbacks are validated via the provider state parameter.
        $mcrop_olx_code  = isset( $_GET['code'] ) ? sanitize_text_field( wp_unslash( $_GET['code'] ) ) : '';
        $mcrop_olx_saved = $mcrop_olx_state ? get_transient( self::MCROP_OLX_OAUTH_STATE_TRANSIENT_PREFIX . $mcrop_olx_state ) : false;
        update_option( 'mcrop_olx_last_oauth_debug', array( 'phase' => 'callback_received', 'has_code' => $mcrop_olx_code ? 'yes' : 'no', 'has_state' => $mcrop_olx_state ? 'yes' : 'no', 'state_valid' => false === $mcrop_olx_saved ? 'no' : 'yes', 'time' => time() ), false );
        if ( ! $mcrop_olx_state || ! $mcrop_olx_code || false === $mcrop_olx_saved ) {
            wp_safe_redirect( add_query_arg( 'mcrop_olx_oauth_error', rawurlencode( __( 'OAuth callback validation failed. The callback did not include a valid code/state pair.', 'marketplace-connector-ro-pro-for-woocommerce' ) ), admin_url( 'admin.php?page=mcrop_olx-settings' ) ) );
            exit;
        }
        delete_transient( self::MCROP_OLX_OAUTH_STATE_TRANSIENT_PREFIX . $mcrop_olx_state );
        $mcrop_olx_result = $this->mcrop_olx_exchange_code_for_tokens( $mcrop_olx_code );
        if ( ! is_wp_error( $mcrop_olx_result ) ) {
            $mcrop_olx_after_save = $this->mcrop_olx_get_options();
            if ( empty( $mcrop_olx_after_save['access_token'] ) ) {
                $mcrop_olx_result = new WP_Error( 'mcrop_olx_oauth_token_not_saved', esc_html__( 'OAuth completed but the access token was not saved. Re-save Client Secret and connect again.', 'marketplace-connector-ro-pro-for-woocommerce' ) );
            }
        }
        $mcrop_olx_arg = is_wp_error( $mcrop_olx_result ) ? array( 'mcrop_olx_oauth_error' => rawurlencode( $mcrop_olx_result->get_error_message() ) ) : array( 'mcrop_olx_oauth_connected' => '1' );
        wp_safe_redirect( add_query_arg( $mcrop_olx_arg, admin_url( 'admin.php?page=mcrop_olx-settings' ) ) );
        exit;
    }

    private function mcrop_olx_exchange_code_for_tokens( $mcrop_olx_code ) {
        $mcrop_olx_options = $this->mcrop_olx_get_options();
        $mcrop_olx_market = $this->mcrop_olx_get_market_config( $mcrop_olx_options['market'] );
        if ( empty( $mcrop_olx_options['client_id'] ) || empty( $mcrop_olx_options['client_secret'] ) ) {
            return new WP_Error( 'mcrop_olx_oauth_missing_client', esc_html__( 'Client ID and Client Secret are required.', 'marketplace-connector-ro-pro-for-woocommerce' ) );
        }
        $mcrop_olx_response = wp_remote_post(
            esc_url_raw( $mcrop_olx_market['token_url'] ),
            array(
                'timeout' => 45,
                'headers' => array( 'Accept' => 'application/json' ),
                'body'    => array(
                    'grant_type'    => 'authorization_code',
                    'client_id'     => $mcrop_olx_options['client_id'],
                    'client_secret' => $mcrop_olx_options['client_secret'],
                    'redirect_uri'  => $this->mcrop_olx_get_oauth_redirect_uri(),
                    'code'          => $mcrop_olx_code,
                ),
            )
        );
        if ( is_wp_error( $mcrop_olx_response ) ) {
            return $mcrop_olx_response;
        }
        $mcrop_olx_code_http = (int) wp_remote_retrieve_response_code( $mcrop_olx_response );
        $mcrop_olx_raw = (string) wp_remote_retrieve_body( $mcrop_olx_response );
        $mcrop_olx_json = json_decode( $mcrop_olx_raw, true );
        $mcrop_olx_debug_body = $mcrop_olx_raw;
        $mcrop_olx_debug_body = preg_replace( '/"access_token"\s*:\s*"[^"]+"/', '"access_token":"[REDACTED]"', $mcrop_olx_debug_body );
        $mcrop_olx_debug_body = preg_replace( '/"refresh_token"\s*:\s*"[^"]+"/', '"refresh_token":"[REDACTED]"', $mcrop_olx_debug_body );
        update_option( 'mcrop_olx_last_oauth_debug', array( 'phase' => 'token_response', 'http' => $mcrop_olx_code_http, 'json' => is_array( $mcrop_olx_json ) ? 'yes' : 'no', 'has_access_token' => is_array( $mcrop_olx_json ) && ! empty( $mcrop_olx_json['access_token'] ) ? 'yes' : 'no', 'has_refresh_token' => is_array( $mcrop_olx_json ) && ! empty( $mcrop_olx_json['refresh_token'] ) ? 'yes' : 'no', 'body' => substr( sanitize_textarea_field( $mcrop_olx_debug_body ), 0, 800 ), 'time' => time() ), false );
        if ( $mcrop_olx_code_http < 200 || $mcrop_olx_code_http >= 300 || ! is_array( $mcrop_olx_json ) ) {
            /* translators: %s: Redacted response body returned by the OAuth token endpoint. */
            return new WP_Error( 'mcrop_olx_oauth_token_error', sprintf( esc_html__( 'OAuth token exchange failed: %s', 'marketplace-connector-ro-pro-for-woocommerce' ), $mcrop_olx_raw ) );
        }
        if ( empty( $mcrop_olx_json['access_token'] ) ) {
            return new WP_Error( 'mcrop_olx_oauth_missing_access_token', esc_html__( 'OAuth token exchange completed but OLX did not return an access token. Check the callback URI and application approval.', 'marketplace-connector-ro-pro-for-woocommerce' ) );
        }
        $this->mcrop_olx_save_tokens_from_response( $mcrop_olx_json );
        return $mcrop_olx_json;
    }

    public function mcrop_olx_save_tokens_from_response( array $mcrop_olx_response ) {
        $mcrop_olx_options = $this->mcrop_olx_get_options();
        if ( ! empty( $mcrop_olx_response['access_token'] ) ) {
            $mcrop_olx_options['access_token'] = sanitize_textarea_field( $mcrop_olx_response['access_token'] );
        }
        if ( ! empty( $mcrop_olx_response['refresh_token'] ) ) {
            $mcrop_olx_options['refresh_token'] = sanitize_textarea_field( $mcrop_olx_response['refresh_token'] );
        }
        if ( ! empty( $mcrop_olx_response['expires_in'] ) ) {
            $mcrop_olx_options['token_expires_at'] = time() + absint( $mcrop_olx_response['expires_in'] );
        }
        // OAuth callback is an internal trusted write; bypass the settings-form nonce sanitizer for this update.
        remove_filter( 'sanitize_option_' . self::MCROP_OLX_OPTION, array( $this, 'mcrop_olx_sanitize_options' ), 10 );
        update_option( self::MCROP_OLX_OPTION, $mcrop_olx_options, false );
        add_filter( 'sanitize_option_' . self::MCROP_OLX_OPTION, array( $this, 'mcrop_olx_sanitize_options' ), 10, 1 );
        $mcrop_olx_persisted = $this->mcrop_olx_get_options();
        update_option( 'mcrop_olx_last_oauth_debug', array( 'phase' => 'tokens_saved', 'access_len' => ! empty( $mcrop_olx_persisted['access_token'] ) ? strlen( $mcrop_olx_persisted['access_token'] ) : 0, 'refresh_len' => ! empty( $mcrop_olx_persisted['refresh_token'] ) ? strlen( $mcrop_olx_persisted['refresh_token'] ) : 0, 'expires_at' => ! empty( $mcrop_olx_persisted['token_expires_at'] ) ? absint( $mcrop_olx_persisted['token_expires_at'] ) : 0, 'time' => time() ), false );
    }

    public function mcrop_olx_render_settings_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'marketplace-connector-ro-pro-for-woocommerce' ) );
        }
        $mcrop_olx_options = $this->mcrop_olx_get_options();
        $mcrop_olx_market_config = $this->mcrop_olx_get_market_config( $mcrop_olx_options['market'] );
        $mcrop_olx_connect_url = wp_nonce_url( admin_url( 'admin-post.php?action=mcrop_olx_oauth_start' ), 'mcrop_olx_oauth_start' );
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Marketplace Connector RO PRO for WooCommerce', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></h1>
            <p><?php echo esc_html__( 'Automated and manual WooCommerce product synchronization for the OLX.ro marketplace. This plugin is not affiliated with, endorsed by, or sponsored by OLX Group.', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></p>
            <?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Admin notice flag after OAuth redirect. ?>
            <?php if ( isset( $_GET['mcrop_olx_oauth_connected'] ) && ! empty( $mcrop_olx_options['access_token'] ) ) : ?>
                <div class="notice notice-success"><p><?php echo esc_html__( 'OLX OAuth connection completed and token saved.', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></p></div>
            <?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Admin notice flag after OAuth redirect. ?>
            <?php elseif ( isset( $_GET['mcrop_olx_oauth_connected'] ) ) : ?>
                <div class="notice notice-warning"><p><?php echo esc_html__( 'OLX returned to this page, but no access token is saved yet. Please use the exact callback URI and complete the Connect with OLX flow again.', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></p></div>
            <?php endif; ?>
            <?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Admin notice flag after OAuth redirect. ?>
            <?php if ( isset( $_GET['mcrop_olx_oauth_error'] ) ) : ?>
                <?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Admin notice flag after OAuth redirect. ?>
                <div class="notice notice-error"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['mcrop_olx_oauth_error'] ) ) ); ?></p></div>
            <?php endif; ?>
            <?php $mcrop_olx_oauth_debug = get_option( 'mcrop_olx_last_oauth_debug', array() ); ?>
            <?php if ( ! empty( $mcrop_olx_oauth_debug ) && is_array( $mcrop_olx_oauth_debug ) ) : ?>
                <div class="notice notice-info"><p><strong><?php echo esc_html__( 'Last OAuth debug:', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></strong> <?php echo esc_html( wp_json_encode( $mcrop_olx_oauth_debug ) ); ?></p></div>
            <?php endif; ?>
            <form method="post" action="options.php">
                <?php settings_fields( 'mcrop_olx_settings_group' ); ?>
                <?php wp_nonce_field( self::MCROP_OLX_NONCE_ACTION, 'mcrop_olx_settings_nonce' ); ?>
                <table class="form-table" role="presentation">
                    <tr><th scope="row"><label for="mcrop_olx_market"><?php echo esc_html__( 'Market', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></label></th><td><select id="mcrop_olx_market" name="<?php echo esc_attr( self::MCROP_OLX_OPTION ); ?>[market]"><?php foreach ( array( 'ro' => 'Romania' ) as $mcrop_olx_key => $mcrop_olx_label ) : ?><option value="<?php echo esc_attr( $mcrop_olx_key ); ?>" <?php selected( $mcrop_olx_options['market'], $mcrop_olx_key ); ?>><?php echo esc_html( $mcrop_olx_label ); ?></option><?php endforeach; ?></select><p class="description"><?php echo esc_html( sprintf( 'Current API base: %s', $mcrop_olx_market_config['base_url'] ) ); ?></p></td></tr>
                    <tr><th scope="row"><label for="mcrop_olx_client_id">Client ID</label></th><td><input id="mcrop_olx_client_id" class="regular-text" name="<?php echo esc_attr( self::MCROP_OLX_OPTION ); ?>[client_id]" value="<?php echo esc_attr( $mcrop_olx_options['client_id'] ); ?>"></td></tr>
                    <tr><th scope="row"><label for="mcrop_olx_client_secret">Client Secret</label></th><td><input id="mcrop_olx_client_secret" type="password" class="regular-text" name="<?php echo esc_attr( self::MCROP_OLX_OPTION ); ?>[client_secret]" value="" placeholder="<?php echo esc_attr__( 'Leave empty to keep saved value', 'marketplace-connector-ro-pro-for-woocommerce' ); ?>"></td></tr>
                    <tr><th scope="row"><?php echo esc_html__( 'OAuth connection', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></th><td><a class="button" href="<?php echo esc_url( $mcrop_olx_connect_url ); ?>"><?php echo esc_html__( 'Connect with OLX', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></a><p class="description"><?php echo esc_html__( 'Save Client ID and Client Secret first, then connect. Manual token fields below remain available for advanced troubleshooting.', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></p></td></tr>
                    <tr><th scope="row"><label for="mcrop_olx_access_token">Access Token</label></th><td><textarea id="mcrop_olx_access_token" class="large-text" rows="3" name="<?php echo esc_attr( self::MCROP_OLX_OPTION ); ?>[access_token]" placeholder="<?php echo esc_attr__( 'Leave empty to keep saved value', 'marketplace-connector-ro-pro-for-woocommerce' ); ?>"></textarea></td></tr>
                    <tr><th scope="row"><label for="mcrop_olx_refresh_token">Refresh Token</label></th><td><textarea id="mcrop_olx_refresh_token" class="large-text" rows="3" name="<?php echo esc_attr( self::MCROP_OLX_OPTION ); ?>[refresh_token]" placeholder="<?php echo esc_attr__( 'Leave empty to keep saved value', 'marketplace-connector-ro-pro-for-woocommerce' ); ?>"></textarea></td></tr>
                    <tr><th scope="row"><label for="mcrop_olx_currency">Currency</label></th><td><input id="mcrop_olx_currency" name="<?php echo esc_attr( self::MCROP_OLX_OPTION ); ?>[currency]" value="<?php echo esc_attr( $mcrop_olx_options['currency'] ); ?>" placeholder="<?php echo esc_attr( $mcrop_olx_market_config['currency'] ); ?>"></td></tr>
                    <tr><th scope="row">Advertiser type</th><td><select name="<?php echo esc_attr( self::MCROP_OLX_OPTION ); ?>[advertiser_type]"><option value="business" <?php selected( $mcrop_olx_options['advertiser_type'], 'business' ); ?>>business</option><option value="private" <?php selected( $mcrop_olx_options['advertiser_type'], 'private' ); ?>>private</option></select></td></tr>
                    <tr><th scope="row"><label for="mcrop_olx_contact_name">Contact name</label></th><td><input id="mcrop_olx_contact_name" class="regular-text" name="<?php echo esc_attr( self::MCROP_OLX_OPTION ); ?>[contact_name]" value="<?php echo esc_attr( $mcrop_olx_options['contact_name'] ); ?>"></td></tr>
                    <tr><th scope="row"><label for="mcrop_olx_contact_phone">Contact phone</label></th><td><input id="mcrop_olx_contact_phone" class="regular-text" name="<?php echo esc_attr( self::MCROP_OLX_OPTION ); ?>[contact_phone]" value="<?php echo esc_attr( $mcrop_olx_options['contact_phone'] ); ?>"></td></tr>
                    <tr><th scope="row"><label for="mcrop_olx_city_id">Default city ID</label></th><td><input id="mcrop_olx_city_id" type="number" name="<?php echo esc_attr( self::MCROP_OLX_OPTION ); ?>[city_id]" value="<?php echo esc_attr( $mcrop_olx_options['city_id'] ); ?>"></td></tr>
                    <tr><th scope="row"><label for="mcrop_olx_district_id">Default district ID</label></th><td><input id="mcrop_olx_district_id" type="number" name="<?php echo esc_attr( self::MCROP_OLX_OPTION ); ?>[district_id]" value="<?php echo esc_attr( $mcrop_olx_options['district_id'] ); ?>"></td></tr>
                    <tr><th scope="row">PRO automation</th><td>
                        <label><input type="checkbox" name="<?php echo esc_attr( self::MCROP_OLX_OPTION ); ?>[pro_auto_sync_on_save]" value="1" <?php checked( $mcrop_olx_options['pro_auto_sync_on_save'], '1' ); ?>> <?php echo esc_html__( 'Auto-sync product to OLX after published product save/update.', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></label><br>
                        <label><input type="checkbox" name="<?php echo esc_attr( self::MCROP_OLX_OPTION ); ?>[pro_stock_status_sync]" value="1" <?php checked( $mcrop_olx_options['pro_stock_status_sync'], '1' ); ?>> <?php echo esc_html__( 'Re-sync linked advert when WooCommerce stock status changes.', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></label><br>
                        <label><input type="checkbox" name="<?php echo esc_attr( self::MCROP_OLX_OPTION ); ?>[pro_cron_sync]" value="1" <?php checked( $mcrop_olx_options['pro_cron_sync'], '1' ); ?>> <?php echo esc_html__( 'Run hourly cron resync for already-linked adverts.', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></label><br>
                        <label><?php echo esc_html__( 'Cron batch limit', 'marketplace-connector-ro-pro-for-woocommerce' ); ?> <input type="number" min="1" max="200" name="<?php echo esc_attr( self::MCROP_OLX_OPTION ); ?>[pro_cron_limit]" value="<?php echo esc_attr( $mcrop_olx_options['pro_cron_limit'] ); ?>" class="small-text"></label>
                    </td></tr>
                    <tr><th scope="row"><?php echo esc_html__( 'Uninstall cleanup', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></th><td><label><input type="checkbox" name="<?php echo esc_attr( self::MCROP_OLX_OPTION ); ?>[cleanup_data]" value="1" <?php checked( $mcrop_olx_options['cleanup_data'], '1' ); ?>> <?php echo esc_html__( 'Remove plugin options, category mappings and OLX advert meta on uninstall.', 'marketplace-connector-ro-pro-for-woocommerce' ); ?></label></td></tr>
                </table>
                <?php submit_button( esc_html__( 'Save settings', 'marketplace-connector-ro-pro-for-woocommerce' ) ); ?>
            </form>
        </div>
        <?php
    }
}
