<?php
/**
 * Plugin Name: Marketplace Connector RO PRO for WooCommerce
 * Plugin URI: https://factorydirect.digital/woo/
 * Description: Automated and manual WooCommerce product synchronization with the OLX.ro Partner API v2 for Romania.
 * Version: 1.0.0
 * Author: Factory Direct Multimedia
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: marketplace-connector-ro-pro-for-woocommerce
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * WC requires at least: 7.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'MCROP_OLX_PRO_VERSION', '1.0.0' );
define( 'MCROP_OLX_LITE_FILE', __FILE__ );
define( 'MCROP_OLX_LITE_PATH', plugin_dir_path( __FILE__ ) );
define( 'MCROP_OLX_LITE_URL', plugin_dir_url( __FILE__ ) );
define( 'MCROP_OLX_PRO', true );

require_once MCROP_OLX_LITE_PATH . 'includes/class-eur-olx-api-client.php';
require_once MCROP_OLX_LITE_PATH . 'includes/class-eur-olx-settings.php';
require_once MCROP_OLX_LITE_PATH . 'includes/class-eur-olx-category-map.php';
require_once MCROP_OLX_LITE_PATH . 'includes/class-eur-olx-product-sync.php';
require_once MCROP_OLX_LITE_PATH . 'includes/class-eur-olx-plugin.php';
require_once MCROP_OLX_LITE_PATH . 'includes/class-mcrop-olx-pro-automation.php';

/**
 * Bootstrap plugin. Global function is prefixed for WordPress.org compatibility.
 *
 * @return MCROP_OLX_Plugin
 */
function mcrop_olx_lite() {
    return MCROP_OLX_Plugin::mcrop_olx_instance();
}

add_action( 'plugins_loaded', 'mcrop_olx_lite' );
