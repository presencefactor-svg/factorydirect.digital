<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

$options = get_option( 'mcpt_olx_options', array() );
if ( ! is_array( $options ) || empty( $options['cleanup_data'] ) || '1' !== $options['cleanup_data'] ) {
    return;
}

delete_option( 'mcpt_olx_options' );
delete_option( 'mcpt_olx_category_map' );
delete_option( 'mcpt_olx_last_oauth_debug' );
delete_transient( 'mcpt_olx_pt_category_suggestions' );

$meta_keys = array( '_mcpt_olx_advert_id', '_mcpt_olx_status', '_mcpt_olx_last_error' );
foreach ( $meta_keys as $meta_key ) {
    delete_post_meta_by_key( $meta_key );
}
wp_clear_scheduled_hook( 'mcpt_olx_pro_cron_sync' );
