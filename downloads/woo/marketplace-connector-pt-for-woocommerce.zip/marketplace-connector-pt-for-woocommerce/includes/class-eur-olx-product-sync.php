<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCPT_OLX_Product_Sync {
    const MCPT_OLX_ADVERT_ID_META = '_mcpt_olx_advert_id';
    const MCPT_OLX_STATUS_META    = '_mcpt_olx_status';
    const MCPT_OLX_LAST_ERROR_META= '_mcpt_olx_last_error';
    const MCPT_OLX_SYNC_NONCE     = 'mcpt_olx_sync_product_nonce_action';

    private $mcpt_olx_settings;
    private $mcpt_olx_category_map;
    private $mcpt_olx_api_client;

    public function __construct( MCPT_OLX_Settings $mcpt_olx_settings, MCPT_OLX_Category_Map $mcpt_olx_category_map ) {
        $this->mcpt_olx_settings     = $mcpt_olx_settings;
        $this->mcpt_olx_category_map = $mcpt_olx_category_map;
        $this->mcpt_olx_api_client   = new MCPT_OLX_API_Client( $mcpt_olx_settings );
    }

    public function mcpt_olx_register_hooks() {
        add_action( 'add_meta_boxes_product', array( $this, 'mcpt_olx_add_product_metabox' ) );
        add_action( 'admin_post_mcpt_olx_sync_product', array( $this, 'mcpt_olx_handle_manual_sync' ) );
        add_filter( 'bulk_actions-edit-product', array( $this, 'mcpt_olx_register_bulk_actions' ) );
        add_filter( 'handle_bulk_actions-edit-product', array( $this, 'mcpt_olx_handle_bulk_actions' ), 10, 3 );
    }

    public function mcpt_olx_add_product_metabox() {
        add_meta_box(
            'mcpt_olx_product_sync',
            esc_html__( 'Marketplace Connector PT Sync', 'marketplace-connector-pt-for-woocommerce' ),
            array( $this, 'mcpt_olx_render_product_metabox' ),
            'product',
            'side',
            'default'
        );
    }

    public function mcpt_olx_render_product_metabox( $mcpt_olx_post ) {
        if ( ! current_user_can( 'edit_product', $mcpt_olx_post->ID ) ) {
            return;
        }
        $mcpt_olx_advert_id = get_post_meta( $mcpt_olx_post->ID, self::MCPT_OLX_ADVERT_ID_META, true );
        $mcpt_olx_status    = get_post_meta( $mcpt_olx_post->ID, self::MCPT_OLX_STATUS_META, true );
        $mcpt_olx_error     = get_post_meta( $mcpt_olx_post->ID, self::MCPT_OLX_LAST_ERROR_META, true );
        $mcpt_olx_url       = wp_nonce_url(
            admin_url( 'admin-post.php?action=mcpt_olx_sync_product&product_id=' . absint( $mcpt_olx_post->ID ) ),
            self::MCPT_OLX_SYNC_NONCE,
            'mcpt_olx_nonce'
        );
        echo '<p><strong>' . esc_html__( 'Advert ID:', 'marketplace-connector-pt-for-woocommerce' ) . '</strong> ' . esc_html( $mcpt_olx_advert_id ? $mcpt_olx_advert_id : '-' ) . '</p>';
        echo '<p><strong>' . esc_html__( 'Status:', 'marketplace-connector-pt-for-woocommerce' ) . '</strong> ' . esc_html( $mcpt_olx_status ? $mcpt_olx_status : '-' ) . '</p>';
        if ( $mcpt_olx_error ) {
            echo '<p class="description" style="color:#b32d2e;">' . esc_html( $mcpt_olx_error ) . '</p>';
        }
        echo '<p><a class="button button-primary" href="' . esc_url( $mcpt_olx_url ) . '">' . esc_html__( 'Sync to OLX', 'marketplace-connector-pt-for-woocommerce' ) . '</a></p>';
    }

    public function mcpt_olx_handle_manual_sync() {
        $mcpt_olx_product_id = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0;
        if ( ! $mcpt_olx_product_id || ! current_user_can( 'edit_product', $mcpt_olx_product_id ) ) {
            wp_die( esc_html__( 'You do not have permission to sync this product.', 'marketplace-connector-pt-for-woocommerce' ) );
        }
        check_admin_referer( self::MCPT_OLX_SYNC_NONCE, 'mcpt_olx_nonce' );

        $mcpt_olx_result = $this->mcpt_olx_sync_product( $mcpt_olx_product_id );
        $mcpt_olx_args   = is_wp_error( $mcpt_olx_result )
            ? array( 'mcpt_olx_error' => rawurlencode( $mcpt_olx_result->get_error_message() ) )
            : array( 'mcpt_olx_message' => rawurlencode( esc_html__( 'Product synced to OLX.pt.', 'marketplace-connector-pt-for-woocommerce' ) ) );

        wp_safe_redirect( add_query_arg( $mcpt_olx_args, get_edit_post_link( $mcpt_olx_product_id, 'url' ) ) );
        exit;
    }

    public function mcpt_olx_register_bulk_actions( $mcpt_olx_actions ) {
        $mcpt_olx_actions['mcpt_olx_bulk_sync'] = esc_html__( 'Sync to Marketplace Connector PT', 'marketplace-connector-pt-for-woocommerce' );
        return $mcpt_olx_actions;
    }

    public function mcpt_olx_handle_bulk_actions( $mcpt_olx_redirect, $mcpt_olx_action, $mcpt_olx_product_ids ) {
        if ( 'mcpt_olx_bulk_sync' !== $mcpt_olx_action ) {
            return $mcpt_olx_redirect;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return $mcpt_olx_redirect;
        }
        // WordPress core verifies the bulk action nonce before this filter is called.
        $mcpt_olx_success = 0;
        $mcpt_olx_failed  = 0;
        foreach ( array_map( 'absint', (array) $mcpt_olx_product_ids ) as $mcpt_olx_product_id ) {
            $mcpt_olx_result = $this->mcpt_olx_sync_product( $mcpt_olx_product_id );
            is_wp_error( $mcpt_olx_result ) ? $mcpt_olx_failed++ : $mcpt_olx_success++;
        }
        return add_query_arg( array( 'mcpt_olx_success' => $mcpt_olx_success, 'mcpt_olx_failed' => $mcpt_olx_failed ), $mcpt_olx_redirect );
    }

    public function mcpt_olx_sync_product( $mcpt_olx_product_id ) {
        if ( ! function_exists( 'wc_get_product' ) ) {
            return new WP_Error( 'mcpt_olx_missing_wc', esc_html__( 'WooCommerce is not active.', 'marketplace-connector-pt-for-woocommerce' ) );
        }

        $mcpt_olx_product = wc_get_product( absint( $mcpt_olx_product_id ) );
        if ( ! $mcpt_olx_product ) {
            return new WP_Error( 'mcpt_olx_missing_product', esc_html__( 'Product not found.', 'marketplace-connector-pt-for-woocommerce' ) );
        }

        $mcpt_olx_payload = $this->mcpt_olx_build_advert_payload( $mcpt_olx_product );
        if ( is_wp_error( $mcpt_olx_payload ) ) {
            return $mcpt_olx_payload;
        }

        /** Hook for PRO/custom payload changes: variations, custom attributes, GPS, delivery, safety regulations. */
        $mcpt_olx_payload = apply_filters( 'mcpt_olx_advert_payload', $mcpt_olx_payload, $mcpt_olx_product );
        do_action( 'mcpt_olx_before_manual_sync', $mcpt_olx_product->get_id(), $mcpt_olx_payload );

        $mcpt_olx_existing_advert_id = get_post_meta( $mcpt_olx_product->get_id(), self::MCPT_OLX_ADVERT_ID_META, true );
        $mcpt_olx_response = $mcpt_olx_existing_advert_id ? $this->mcpt_olx_api_client->mcpt_olx_update_v2_advert( $mcpt_olx_existing_advert_id, $mcpt_olx_payload ) : $this->mcpt_olx_api_client->mcpt_olx_post_v2_advert( $mcpt_olx_payload );
        if ( is_wp_error( $mcpt_olx_response ) ) {
            update_post_meta( $mcpt_olx_product->get_id(), self::MCPT_OLX_LAST_ERROR_META, sanitize_text_field( $mcpt_olx_response->get_error_message() ) );
            return $mcpt_olx_response;
        }

        if ( isset( $mcpt_olx_response['id'] ) ) {
            update_post_meta( $mcpt_olx_product->get_id(), self::MCPT_OLX_ADVERT_ID_META, absint( $mcpt_olx_response['id'] ) );
        }
        if ( isset( $mcpt_olx_response['status'] ) ) {
            update_post_meta( $mcpt_olx_product->get_id(), self::MCPT_OLX_STATUS_META, sanitize_text_field( $mcpt_olx_response['status'] ) );
        }
        delete_post_meta( $mcpt_olx_product->get_id(), self::MCPT_OLX_LAST_ERROR_META );
        do_action( 'mcpt_olx_after_manual_sync', $mcpt_olx_product->get_id(), $mcpt_olx_response );

        return $mcpt_olx_response;
    }

    private function mcpt_olx_build_advert_payload( WC_Product $mcpt_olx_product ) {
        $mcpt_olx_options     = $this->mcpt_olx_settings->mcpt_olx_get_options();
        $mcpt_olx_market      = $this->mcpt_olx_settings->mcpt_olx_get_market_config( $mcpt_olx_options['market'] );
        $mcpt_olx_category_id = $this->mcpt_olx_category_map->mcpt_olx_get_olx_category_id_for_product( $mcpt_olx_product->get_id() );

        if ( ! $mcpt_olx_category_id ) {
            return new WP_Error( 'mcpt_olx_missing_category', esc_html__( 'Missing OLX category mapping for this product.', 'marketplace-connector-pt-for-woocommerce' ) );
        }
        if ( empty( $mcpt_olx_options['city_id'] ) || empty( $mcpt_olx_options['contact_name'] ) ) {
            return new WP_Error( 'mcpt_olx_missing_required_settings', esc_html__( 'Missing default city ID or contact name in Marketplace Connector PT settings.', 'marketplace-connector-pt-for-woocommerce' ) );
        }

        $mcpt_olx_title = sanitize_text_field( wp_strip_all_tags( $mcpt_olx_product->get_name() ) );
        $mcpt_olx_desc  = wp_kses_post( $mcpt_olx_product->get_description() ? $mcpt_olx_product->get_description() : $mcpt_olx_product->get_short_description() );
        $mcpt_olx_price = (float) wc_get_price_to_display( $mcpt_olx_product );
        $mcpt_olx_currency = $mcpt_olx_options['currency'] ? $mcpt_olx_options['currency'] : $mcpt_olx_market['currency'];

        $mcpt_olx_images = array();
        $mcpt_olx_image_ids = array_filter( array_unique( array_merge( array( $mcpt_olx_product->get_image_id() ), $mcpt_olx_product->get_gallery_image_ids() ) ) );
        foreach ( array_slice( $mcpt_olx_image_ids, 0, 8 ) as $mcpt_olx_image_id ) {
            $mcpt_olx_image_url = wp_get_attachment_url( absint( $mcpt_olx_image_id ) );
            if ( $mcpt_olx_image_url && $this->mcpt_olx_is_public_image_url( $mcpt_olx_image_url ) ) {
                $mcpt_olx_images[] = array( 'url' => esc_url_raw( $mcpt_olx_image_url ) );
            }
        }

        $mcpt_olx_payload = array(
            'title'           => $mcpt_olx_title,
            'description'     => $mcpt_olx_desc,
            'category_id'     => absint( $mcpt_olx_category_id ),
            'advertiser_type' => sanitize_text_field( $mcpt_olx_options['advertiser_type'] ),
            'external_id'     => (string) $mcpt_olx_product->get_id(),
            'contact'         => array(
                'name'  => sanitize_text_field( $mcpt_olx_options['contact_name'] ),
                'phone' => sanitize_text_field( $mcpt_olx_options['contact_phone'] ),
            ),
            'location'        => array_filter(
                array(
                    'city_id'     => absint( $mcpt_olx_options['city_id'] ),
                    'district_id' => ! empty( $mcpt_olx_options['district_id'] ) ? absint( $mcpt_olx_options['district_id'] ) : null,
                )
            ),
            'images'          => $mcpt_olx_images,
            'price'           => array(
                'value'      => $mcpt_olx_price,
                'currency'   => sanitize_text_field( $mcpt_olx_currency ),
                'negotiable' => false,
                'trade'      => false,
                'budget'     => false,
            ),
            'attributes'      => $this->mcpt_olx_category_map->mcpt_olx_get_attributes_for_product( $mcpt_olx_product->get_id() ),
        );

        return $mcpt_olx_payload;
    }

    private function mcpt_olx_is_public_image_url( $mcpt_olx_image_url ) {
        $mcpt_olx_host = wp_parse_url( $mcpt_olx_image_url, PHP_URL_HOST );
        if ( ! $mcpt_olx_host ) {
            return false;
        }
        $mcpt_olx_host = strtolower( $mcpt_olx_host );
        if ( 'localhost' === $mcpt_olx_host || '.local' === substr( $mcpt_olx_host, -6 ) || '.test' === substr( $mcpt_olx_host, -5 ) ) {
            return false;
        }
        if ( filter_var( $mcpt_olx_host, FILTER_VALIDATE_IP ) ) {
            return ! preg_match( '/^(127\.|10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[0-1])\.)/', $mcpt_olx_host );
        }
        return true;
    }
}
