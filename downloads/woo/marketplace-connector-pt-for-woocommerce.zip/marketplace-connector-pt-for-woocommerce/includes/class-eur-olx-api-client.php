<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCPT_OLX_API_Client {
    private $mcpt_olx_settings;

    public function __construct( MCPT_OLX_Settings $mcpt_olx_settings ) {
        $this->mcpt_olx_settings = $mcpt_olx_settings;
    }

    public function mcpt_olx_request( $mcpt_olx_method, $mcpt_olx_path, $mcpt_olx_body = null ) {
        $mcpt_olx_options = $this->mcpt_olx_settings->mcpt_olx_get_options();
        if ( ( empty( $mcpt_olx_options['access_token'] ) && ! empty( $mcpt_olx_options['refresh_token'] ) ) || ( ! empty( $mcpt_olx_options['token_expires_at'] ) && absint( $mcpt_olx_options['token_expires_at'] ) < time() + 120 ) ) {
            $mcpt_olx_refreshed = $this->mcpt_olx_refresh_access_token();
            if ( ! is_wp_error( $mcpt_olx_refreshed ) ) {
                $mcpt_olx_options = $this->mcpt_olx_settings->mcpt_olx_get_options();
            }
        }

        $mcpt_olx_market = $this->mcpt_olx_settings->mcpt_olx_get_market_config( $mcpt_olx_options['market'] );
        $mcpt_olx_token  = trim( (string) $mcpt_olx_options['access_token'] );

        if ( '' === $mcpt_olx_token ) {
            return new WP_Error( 'mcpt_olx_missing_token', esc_html__( 'Missing OAuth access token.', 'marketplace-connector-pt-for-woocommerce' ) );
        }

        $mcpt_olx_url = trailingslashit( $mcpt_olx_market['base_url'] ) . ltrim( $mcpt_olx_path, '/' );
        $mcpt_olx_args = array(
            'method'  => strtoupper( sanitize_key( $mcpt_olx_method ) ),
            'timeout' => 45,
            'headers' => array(
                'Accept'        => 'application/json',
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $mcpt_olx_token,
                'Version'       => '2.0',
            ),
        );

        if ( null !== $mcpt_olx_body ) {
            $mcpt_olx_args['body'] = wp_json_encode( $mcpt_olx_body );
        }

        $mcpt_olx_args = apply_filters( 'mcpt_olx_api_request_args', $mcpt_olx_args, $mcpt_olx_path, $mcpt_olx_body );
        $mcpt_olx_response = wp_remote_request( esc_url_raw( $mcpt_olx_url ), $mcpt_olx_args );
        return $this->mcpt_olx_parse_response( $mcpt_olx_response );
    }

    public function mcpt_olx_post_v2_advert( array $mcpt_olx_payload ) {
        return $this->mcpt_olx_request( 'POST', '/adverts', $mcpt_olx_payload );
    }

    public function mcpt_olx_update_v2_advert( $mcpt_olx_advert_id, array $mcpt_olx_payload ) {
        return $this->mcpt_olx_request( 'PUT', '/adverts/' . absint( $mcpt_olx_advert_id ), $mcpt_olx_payload );
    }

    public function mcpt_olx_refresh_access_token() {
        $mcpt_olx_options = $this->mcpt_olx_settings->mcpt_olx_get_options();
        if ( empty( $mcpt_olx_options['client_id'] ) || empty( $mcpt_olx_options['client_secret'] ) || empty( $mcpt_olx_options['refresh_token'] ) ) {
            return new WP_Error( 'mcpt_olx_refresh_missing_credentials', esc_html__( 'Missing OAuth refresh credentials.', 'marketplace-connector-pt-for-woocommerce' ) );
        }

        $mcpt_olx_market = $this->mcpt_olx_settings->mcpt_olx_get_market_config( $mcpt_olx_options['market'] );
        $mcpt_olx_response = wp_remote_post(
            esc_url_raw( $mcpt_olx_market['token_url'] ),
            array(
                'timeout' => 45,
                'headers' => array( 'Accept' => 'application/json' ),
                'body'    => array(
                    'grant_type'    => 'refresh_token',
                    'client_id'     => $mcpt_olx_options['client_id'],
                    'client_secret' => $mcpt_olx_options['client_secret'],
                    'refresh_token' => $mcpt_olx_options['refresh_token'],
                ),
            )
        );

        $mcpt_olx_json = $this->mcpt_olx_parse_response( $mcpt_olx_response );
        if ( is_wp_error( $mcpt_olx_json ) ) {
            return $mcpt_olx_json;
        }
        $this->mcpt_olx_settings->mcpt_olx_save_tokens_from_response( $mcpt_olx_json );
        return $mcpt_olx_json;
    }

    private function mcpt_olx_parse_response( $mcpt_olx_response ) {
        if ( is_wp_error( $mcpt_olx_response ) ) {
            return $mcpt_olx_response;
        }
        $mcpt_olx_code = (int) wp_remote_retrieve_response_code( $mcpt_olx_response );
        $mcpt_olx_raw  = (string) wp_remote_retrieve_body( $mcpt_olx_response );
        $mcpt_olx_json = json_decode( $mcpt_olx_raw, true );
        if ( $mcpt_olx_code < 200 || $mcpt_olx_code >= 300 ) {
            return new WP_Error(
                'mcpt_olx_api_error',
                sprintf(
                    /* translators: 1: HTTP status code, 2: response body */
                    esc_html__( 'OLX API error %1$d: %2$s', 'marketplace-connector-pt-for-woocommerce' ),
                    $mcpt_olx_code,
                    is_array( $mcpt_olx_json ) ? wp_json_encode( $mcpt_olx_json ) : $mcpt_olx_raw
                )
            );
        }
        if ( is_array( $mcpt_olx_json ) && array_key_exists( 'data', $mcpt_olx_json ) ) {
            return is_array( $mcpt_olx_json['data'] ) ? $mcpt_olx_json['data'] : array( 'data' => $mcpt_olx_json['data'] );
        }
        return is_array( $mcpt_olx_json ) ? $mcpt_olx_json : array( 'raw' => $mcpt_olx_raw );
    }
}
