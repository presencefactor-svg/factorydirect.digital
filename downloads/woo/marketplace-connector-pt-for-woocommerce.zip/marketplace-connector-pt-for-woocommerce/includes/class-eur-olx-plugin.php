<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class MCPT_OLX_Plugin {
    private static $mcpt_olx_instance = null;

    private $mcpt_olx_settings;
    private $mcpt_olx_category_map;
    private $mcpt_olx_product_sync;

    public static function mcpt_olx_instance() {
        if ( null === self::$mcpt_olx_instance ) {
            self::$mcpt_olx_instance = new self();
        }
        return self::$mcpt_olx_instance;
    }

    private function __construct() {
        $this->mcpt_olx_settings     = new MCPT_OLX_Settings();
        $this->mcpt_olx_category_map = new MCPT_OLX_Category_Map();
        $this->mcpt_olx_product_sync = new MCPT_OLX_Product_Sync( $this->mcpt_olx_settings, $this->mcpt_olx_category_map );

        add_action( 'admin_menu', array( $this, 'mcpt_olx_admin_menu' ) );
        add_action( 'admin_init', array( $this->mcpt_olx_settings, 'mcpt_olx_register_settings' ) );
        add_action( 'admin_init', array( $this->mcpt_olx_category_map, 'mcpt_olx_handle_category_map_save' ) );
        add_action( 'admin_post_mcpt_olx_oauth_start', array( $this->mcpt_olx_settings, 'mcpt_olx_handle_oauth_start' ) );
        add_action( 'admin_post_mcpt_olx_oauth_callback', array( $this->mcpt_olx_settings, 'mcpt_olx_handle_oauth_callback' ) );

        $this->mcpt_olx_product_sync->mcpt_olx_register_hooks();

        /**
         * Extension hook: keep this free plugin manual-only; add automation in add-ons if needed.
         */
        do_action( 'mcpt_olx_lite_loaded', $this );
    }

    public function mcpt_olx_admin_menu() {
        add_menu_page(
            esc_html__( 'Marketplace Connector PT for WooCommerce', 'marketplace-connector-pt-for-woocommerce' ),
            esc_html__( 'Marketplace Connector PT for WooCommerce', 'marketplace-connector-pt-for-woocommerce' ),
            'manage_woocommerce',
            'mcpt_olx-settings',
            array( $this->mcpt_olx_settings, 'mcpt_olx_render_settings_page' ),
            'dashicons-store',
            56
        );

        add_submenu_page(
            'mcpt_olx-settings',
            esc_html__( 'Category Mapping', 'marketplace-connector-pt-for-woocommerce' ),
            esc_html__( 'Category Mapping', 'marketplace-connector-pt-for-woocommerce' ),
            'manage_woocommerce',
            'mcpt_olx-category-map',
            array( $this->mcpt_olx_category_map, 'mcpt_olx_render_category_map_page' )
        );
    }

    public function mcpt_olx_get_product_sync() {
        return $this->mcpt_olx_product_sync;
    }

}
