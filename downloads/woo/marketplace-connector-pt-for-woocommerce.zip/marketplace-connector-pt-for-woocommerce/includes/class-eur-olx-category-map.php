<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCPT_OLX_Category_Map {
    const MCPT_OLX_CATEGORY_MAP_OPTION = 'mcpt_olx_category_map';
    const MCPT_OLX_CATEGORY_MAP_NONCE = 'mcpt_olx_category_map_nonce_action';

    public function mcpt_olx_get_map() {
        $mcpt_olx_map = get_option( self::MCPT_OLX_CATEGORY_MAP_OPTION, array() );
        return is_array( $mcpt_olx_map ) ? $mcpt_olx_map : array();
    }

    public function mcpt_olx_get_mapping_for_product( $mcpt_olx_product_id ) {
        $mcpt_olx_map   = $this->mcpt_olx_get_map();
        $mcpt_olx_terms = wp_get_post_terms( absint( $mcpt_olx_product_id ), 'product_cat' );
        if ( is_wp_error( $mcpt_olx_terms ) ) {
            return array();
        }
        foreach ( $mcpt_olx_terms as $mcpt_olx_term ) {
            $mcpt_olx_term_id = (string) absint( $mcpt_olx_term->term_id );
            if ( empty( $mcpt_olx_map[ $mcpt_olx_term_id ] ) ) {
                continue;
            }
            if ( is_array( $mcpt_olx_map[ $mcpt_olx_term_id ] ) ) {
                return $mcpt_olx_map[ $mcpt_olx_term_id ];
            }
            return array( 'category_id' => absint( $mcpt_olx_map[ $mcpt_olx_term_id ] ) );
        }
        return array();
    }

    public function mcpt_olx_get_olx_category_id_for_product( $mcpt_olx_product_id ) {
        $mcpt_olx_mapping = $this->mcpt_olx_get_mapping_for_product( $mcpt_olx_product_id );
        return ! empty( $mcpt_olx_mapping['category_id'] ) ? absint( $mcpt_olx_mapping['category_id'] ) : '';
    }

    public function mcpt_olx_get_attributes_for_product( $mcpt_olx_product_id ) {
        $mcpt_olx_mapping    = $this->mcpt_olx_get_mapping_for_product( $mcpt_olx_product_id );
        $mcpt_olx_attributes = array();
        $mcpt_olx_state      = ! empty( $mcpt_olx_mapping['state'] ) ? sanitize_key( $mcpt_olx_mapping['state'] ) : 'new';
        if ( $mcpt_olx_state ) {
            $mcpt_olx_attributes[] = array( 'code' => 'state', 'value' => $mcpt_olx_state );
        }
        if ( ! empty( $mcpt_olx_mapping['attributes'] ) && is_array( $mcpt_olx_mapping['attributes'] ) ) {
            foreach ( $mcpt_olx_mapping['attributes'] as $mcpt_olx_attribute ) {
                if ( empty( $mcpt_olx_attribute['code'] ) || ! isset( $mcpt_olx_attribute['value'] ) ) {
                    continue;
                }
                $mcpt_olx_code  = sanitize_key( $mcpt_olx_attribute['code'] );
                $mcpt_olx_value = sanitize_text_field( (string) $mcpt_olx_attribute['value'] );
                if ( $mcpt_olx_code && '' !== $mcpt_olx_value ) {
                    $mcpt_olx_attributes[] = array( 'code' => $mcpt_olx_code, 'value' => $mcpt_olx_value );
                }
            }
        }
        return $this->mcpt_olx_dedupe_attributes( $mcpt_olx_attributes );
    }

    public function mcpt_olx_handle_category_map_save() {
        if ( empty( $_POST['mcpt_olx_category_map_submit'] ) ) {
            return;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to save category mapping.', 'marketplace-connector-pt-for-woocommerce' ) );
        }
        check_admin_referer( self::MCPT_OLX_CATEGORY_MAP_NONCE, 'mcpt_olx_category_map_nonce' );

        $mcpt_olx_raw_map = isset( $_POST['mcpt_olx_category_map'] ) && is_array( $_POST['mcpt_olx_category_map'] ) ? map_deep( wp_unslash( $_POST['mcpt_olx_category_map'] ), 'sanitize_text_field' ) : array();
        $mcpt_olx_clean   = array();
        foreach ( $mcpt_olx_raw_map as $mcpt_olx_woo_cat_id => $mcpt_olx_row ) {
            $mcpt_olx_woo_cat_id = absint( $mcpt_olx_woo_cat_id );
            if ( ! $mcpt_olx_woo_cat_id || ! is_array( $mcpt_olx_row ) ) {
                continue;
            }
            $mcpt_olx_olx_cat_id = ! empty( $mcpt_olx_row['category_id'] ) ? absint( $mcpt_olx_row['category_id'] ) : 0;
            if ( ! $mcpt_olx_olx_cat_id ) {
                continue;
            }
            $mcpt_olx_clean[ (string) $mcpt_olx_woo_cat_id ] = array(
                'category_id'   => $mcpt_olx_olx_cat_id,
                'category_path' => isset( $mcpt_olx_row['category_path'] ) ? sanitize_text_field( $mcpt_olx_row['category_path'] ) : '',
                'state'         => isset( $mcpt_olx_row['state'] ) ? sanitize_key( $mcpt_olx_row['state'] ) : 'new',
                'attributes'    => $this->mcpt_olx_parse_attribute_lines( isset( $mcpt_olx_row['attributes'] ) ? (string) $mcpt_olx_row['attributes'] : '' ),
            );
        }
        update_option( self::MCPT_OLX_CATEGORY_MAP_OPTION, $mcpt_olx_clean, false );
        add_settings_error( 'mcpt_olx_category_map', 'mcpt_olx_category_map_saved', esc_html__( 'Category mapping saved.', 'marketplace-connector-pt-for-woocommerce' ), 'updated' );
    }

    public function mcpt_olx_render_category_map_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'marketplace-connector-pt-for-woocommerce' ) );
        }
        $mcpt_olx_map        = $this->mcpt_olx_get_map();
        $mcpt_olx_categories = $this->mcpt_olx_get_pt_category_suggestions();
        $mcpt_olx_terms      = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Marketplace Connector PT Category Mapping', 'marketplace-connector-pt-for-woocommerce' ); ?></h1>
            <p class="description"><?php echo esc_html__( 'Map WooCommerce categories to OLX.pt category IDs and define required category attributes such as condition/state. Category ID fields include live OLX.pt API suggestions when OAuth is connected. Additional attributes use one code=value pair per line, for example brand=Samsung.', 'marketplace-connector-pt-for-woocommerce' ); ?></p>
            <?php if ( ! empty( $mcpt_olx_categories ) ) : ?>
                <datalist id="mcpt_olx_pt_categories">
                    <?php foreach ( $mcpt_olx_categories as $mcpt_olx_category ) : ?>
                        <option value="<?php echo esc_attr( $mcpt_olx_category['id'] ); ?>" label="<?php echo esc_attr( $mcpt_olx_category['name'] ); ?>"></option>
                    <?php endforeach; ?>
                </datalist>
            <?php endif; ?>
            <?php settings_errors( 'mcpt_olx_category_map' ); ?>
            <form method="post">
                <?php wp_nonce_field( self::MCPT_OLX_CATEGORY_MAP_NONCE, 'mcpt_olx_category_map_nonce' ); ?>
                <input type="hidden" name="mcpt_olx_category_map_submit" value="1">
                <table class="widefat striped">
                    <thead><tr><th><?php echo esc_html__( 'WooCommerce category', 'marketplace-connector-pt-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'OLX.pt category ID', 'marketplace-connector-pt-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Category note/path', 'marketplace-connector-pt-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Condition', 'marketplace-connector-pt-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Extra attributes', 'marketplace-connector-pt-for-woocommerce' ); ?></th></tr></thead>
                    <tbody>
                    <?php if ( ! is_wp_error( $mcpt_olx_terms ) ) : ?>
                        <?php foreach ( $mcpt_olx_terms as $mcpt_olx_term ) : ?>
                            <?php
                            $mcpt_olx_row = isset( $mcpt_olx_map[ (string) $mcpt_olx_term->term_id ] ) ? $mcpt_olx_map[ (string) $mcpt_olx_term->term_id ] : array();
                            if ( ! is_array( $mcpt_olx_row ) ) {
                                $mcpt_olx_row = array( 'category_id' => absint( $mcpt_olx_row ) );
                            }
                            $mcpt_olx_value = ! empty( $mcpt_olx_row['category_id'] ) ? absint( $mcpt_olx_row['category_id'] ) : '';
                            $mcpt_olx_state = ! empty( $mcpt_olx_row['state'] ) ? sanitize_key( $mcpt_olx_row['state'] ) : 'new';
                            ?>
                            <tr>
                                <td><?php echo esc_html( $mcpt_olx_term->name ); ?></td>
                                <td><input type="number" min="1" list="mcpt_olx_pt_categories" name="mcpt_olx_category_map[<?php echo esc_attr( $mcpt_olx_term->term_id ); ?>][category_id]" value="<?php echo esc_attr( $mcpt_olx_value ); ?>" class="small-text"></td>
                                <td><input type="text" name="mcpt_olx_category_map[<?php echo esc_attr( $mcpt_olx_term->term_id ); ?>][category_path]" value="<?php echo esc_attr( isset( $mcpt_olx_row['category_path'] ) ? $mcpt_olx_row['category_path'] : '' ); ?>" class="regular-text" placeholder="<?php echo esc_attr__( 'e.g. Home / Lighting', 'marketplace-connector-pt-for-woocommerce' ); ?>"></td>
                                <td><select name="mcpt_olx_category_map[<?php echo esc_attr( $mcpt_olx_term->term_id ); ?>][state]"><option value="new" <?php selected( $mcpt_olx_state, 'new' ); ?>><?php echo esc_html__( 'New', 'marketplace-connector-pt-for-woocommerce' ); ?></option><option value="used" <?php selected( $mcpt_olx_state, 'used' ); ?>><?php echo esc_html__( 'Used', 'marketplace-connector-pt-for-woocommerce' ); ?></option></select></td>
                                <td><textarea rows="3" cols="32" name="mcpt_olx_category_map[<?php echo esc_attr( $mcpt_olx_term->term_id ); ?>][attributes]" placeholder="brand=Samsung&#10;model=A54"><?php echo esc_textarea( $this->mcpt_olx_format_attribute_lines( isset( $mcpt_olx_row['attributes'] ) && is_array( $mcpt_olx_row['attributes'] ) ? $mcpt_olx_row['attributes'] : array() ) ); ?></textarea></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
                <?php submit_button( esc_html__( 'Save mapping', 'marketplace-connector-pt-for-woocommerce' ) ); ?>
            </form>
        </div>
        <?php
    }


    private function mcpt_olx_get_pt_category_suggestions() {
        $mcpt_olx_cached = get_transient( 'mcpt_olx_pt_category_suggestions' );
        if ( is_array( $mcpt_olx_cached ) ) {
            return $mcpt_olx_cached;
        }
        $mcpt_olx_options = get_option( 'mcpt_olx_options', array() );
        if ( empty( $mcpt_olx_options['access_token'] ) ) {
            return array();
        }
        $mcpt_olx_response = wp_remote_get(
            'https://www.olx.pt/api/partner/categories?limit=1000',
            array(
                'timeout' => 20,
                'headers' => array(
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer ' . $mcpt_olx_options['access_token'],
                    'Version'       => '2.0',
                ),
            )
        );
        if ( is_wp_error( $mcpt_olx_response ) || 200 !== (int) wp_remote_retrieve_response_code( $mcpt_olx_response ) ) {
            return array();
        }
        $mcpt_olx_json = json_decode( (string) wp_remote_retrieve_body( $mcpt_olx_response ), true );
        $mcpt_olx_rows = isset( $mcpt_olx_json['data'] ) && is_array( $mcpt_olx_json['data'] ) ? $mcpt_olx_json['data'] : array();
        $mcpt_olx_categories = array();
        foreach ( $mcpt_olx_rows as $mcpt_olx_row ) {
            if ( empty( $mcpt_olx_row['id'] ) || empty( $mcpt_olx_row['name'] ) ) {
                continue;
            }
            $mcpt_olx_categories[] = array(
                'id'   => absint( $mcpt_olx_row['id'] ),
                'name' => sanitize_text_field( (string) $mcpt_olx_row['name'] ),
            );
        }
        set_transient( 'mcpt_olx_pt_category_suggestions', $mcpt_olx_categories, DAY_IN_SECONDS );
        return $mcpt_olx_categories;
    }

    private function mcpt_olx_parse_attribute_lines( $mcpt_olx_raw ) {
        $mcpt_olx_attributes = array();
        foreach ( preg_split( '/\r\n|\r|\n/', (string) $mcpt_olx_raw ) as $mcpt_olx_line ) {
            $mcpt_olx_line = trim( $mcpt_olx_line );
            if ( '' === $mcpt_olx_line || false === strpos( $mcpt_olx_line, '=' ) ) {
                continue;
            }
            list( $mcpt_olx_code, $mcpt_olx_value ) = array_map( 'trim', explode( '=', $mcpt_olx_line, 2 ) );
            $mcpt_olx_code  = sanitize_key( $mcpt_olx_code );
            $mcpt_olx_value = sanitize_text_field( $mcpt_olx_value );
            if ( $mcpt_olx_code && '' !== $mcpt_olx_value ) {
                $mcpt_olx_attributes[] = array( 'code' => $mcpt_olx_code, 'value' => $mcpt_olx_value );
            }
        }
        return $this->mcpt_olx_dedupe_attributes( $mcpt_olx_attributes );
    }

    private function mcpt_olx_format_attribute_lines( array $mcpt_olx_attributes ) {
        $mcpt_olx_lines = array();
        foreach ( $mcpt_olx_attributes as $mcpt_olx_attribute ) {
            if ( ! empty( $mcpt_olx_attribute['code'] ) && isset( $mcpt_olx_attribute['value'] ) ) {
                $mcpt_olx_lines[] = sanitize_key( $mcpt_olx_attribute['code'] ) . '=' . sanitize_text_field( (string) $mcpt_olx_attribute['value'] );
            }
        }
        return implode( "\n", $mcpt_olx_lines );
    }

    private function mcpt_olx_dedupe_attributes( array $mcpt_olx_attributes ) {
        $mcpt_olx_seen = array();
        $mcpt_olx_clean = array();
        foreach ( $mcpt_olx_attributes as $mcpt_olx_attribute ) {
            if ( empty( $mcpt_olx_attribute['code'] ) || ! isset( $mcpt_olx_attribute['value'] ) ) {
                continue;
            }
            $mcpt_olx_code = sanitize_key( $mcpt_olx_attribute['code'] );
            if ( ! $mcpt_olx_code || isset( $mcpt_olx_seen[ $mcpt_olx_code ] ) ) {
                continue;
            }
            $mcpt_olx_seen[ $mcpt_olx_code ] = true;
            $mcpt_olx_clean[] = array( 'code' => $mcpt_olx_code, 'value' => sanitize_text_field( (string) $mcpt_olx_attribute['value'] ) );
        }
        return $mcpt_olx_clean;
    }
}
