<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class MCPLP_OLX_Plugin {
    private static $mcplp_olx_instance = null;

    private $mcplp_olx_settings;
    private $mcplp_olx_category_map;
    private $mcplp_olx_product_sync;

    public static function mcplp_olx_instance() {
        if ( null === self::$mcplp_olx_instance ) {
            self::$mcplp_olx_instance = new self();
        }
        return self::$mcplp_olx_instance;
    }

    private function __construct() {
        $this->mcplp_olx_settings     = new MCPLP_OLX_Settings();
        $this->mcplp_olx_category_map = new MCPLP_OLX_Category_Map();
        $this->mcplp_olx_product_sync = new MCPLP_OLX_Product_Sync( $this->mcplp_olx_settings, $this->mcplp_olx_category_map );

        add_action( 'admin_menu', array( $this, 'mcplp_olx_admin_menu' ) );
        add_action( 'admin_init', array( $this->mcplp_olx_settings, 'mcplp_olx_register_settings' ) );
        add_action( 'admin_init', array( $this->mcplp_olx_category_map, 'mcplp_olx_handle_category_map_save' ) );
        add_action( 'admin_post_mcplp_olx_oauth_start', array( $this->mcplp_olx_settings, 'mcplp_olx_handle_oauth_start' ) );
        add_action( 'admin_post_mcplp_olx_oauth_callback', array( $this->mcplp_olx_settings, 'mcplp_olx_handle_oauth_callback' ) );

        $this->mcplp_olx_product_sync->mcplp_olx_register_hooks();

        /**
         * Extension hook: keep this PRO plugin automation-ready; add automation in add-ons if needed.
         */
        do_action( 'mcplp_olx_lite_loaded', $this );
        new MCPLP_OLX_Pro_Automation( $this->mcplp_olx_settings, $this->mcplp_olx_product_sync );
    }

    public function mcplp_olx_admin_menu() {
        add_menu_page(
            esc_html__( 'Marketplace Connector PL PRO for WooCommerce', 'marketplace-connector-pl-pro-for-woocommerce' ),
            esc_html__( 'Marketplace Connector PL PRO for WooCommerce', 'marketplace-connector-pl-pro-for-woocommerce' ),
            'manage_woocommerce',
            'mcplp_olx-settings',
            array( $this->mcplp_olx_settings, 'mcplp_olx_render_settings_page' ),
            'dashicons-store',
            56
        );

        add_submenu_page(
            'mcplp_olx-settings',
            esc_html__( 'Category Mapping', 'marketplace-connector-pl-pro-for-woocommerce' ),
            esc_html__( 'Category Mapping', 'marketplace-connector-pl-pro-for-woocommerce' ),
            'manage_woocommerce',
            'mcplp_olx-category-map',
            array( $this->mcplp_olx_category_map, 'mcplp_olx_render_category_map_page' )
        );
    }

    public function mcplp_olx_get_product_sync() {
        return $this->mcplp_olx_product_sync;
    }

}
