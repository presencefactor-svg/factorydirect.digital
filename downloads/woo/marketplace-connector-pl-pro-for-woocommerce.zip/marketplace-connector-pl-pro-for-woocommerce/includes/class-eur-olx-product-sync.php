<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCPLP_OLX_Product_Sync {
    const MCPLP_OLX_ADVERT_ID_META = '_mcplp_olx_advert_id';
    const MCPLP_OLX_STATUS_META    = '_mcplp_olx_status';
    const MCPLP_OLX_LAST_ERROR_META= '_mcplp_olx_last_error';
    const MCPLP_OLX_SYNC_NONCE     = 'mcplp_olx_sync_product_nonce_action';

    private $mcplp_olx_settings;
    private $mcplp_olx_category_map;
    private $mcplp_olx_api_client;

    public function __construct( MCPLP_OLX_Settings $mcplp_olx_settings, MCPLP_OLX_Category_Map $mcplp_olx_category_map ) {
        $this->mcplp_olx_settings     = $mcplp_olx_settings;
        $this->mcplp_olx_category_map = $mcplp_olx_category_map;
        $this->mcplp_olx_api_client   = new MCPLP_OLX_API_Client( $mcplp_olx_settings );
    }

    public function mcplp_olx_register_hooks() {
        add_action( 'add_meta_boxes_product', array( $this, 'mcplp_olx_add_product_metabox' ) );
        add_action( 'admin_post_mcplp_olx_sync_product', array( $this, 'mcplp_olx_handle_manual_sync' ) );
        add_filter( 'bulk_actions-edit-product', array( $this, 'mcplp_olx_register_bulk_actions' ) );
        add_filter( 'handle_bulk_actions-edit-product', array( $this, 'mcplp_olx_handle_bulk_actions' ), 10, 3 );
    }

    public function mcplp_olx_add_product_metabox() {
        add_meta_box(
            'mcplp_olx_product_sync',
            esc_html__( 'Marketplace Connector PL PRO Sync', 'marketplace-connector-pl-pro-for-woocommerce' ),
            array( $this, 'mcplp_olx_render_product_metabox' ),
            'product',
            'side',
            'default'
        );
    }

    public function mcplp_olx_render_product_metabox( $mcplp_olx_post ) {
        if ( ! current_user_can( 'edit_product', $mcplp_olx_post->ID ) ) {
            return;
        }
        $mcplp_olx_advert_id = get_post_meta( $mcplp_olx_post->ID, self::MCPLP_OLX_ADVERT_ID_META, true );
        $mcplp_olx_status    = get_post_meta( $mcplp_olx_post->ID, self::MCPLP_OLX_STATUS_META, true );
        $mcplp_olx_error     = get_post_meta( $mcplp_olx_post->ID, self::MCPLP_OLX_LAST_ERROR_META, true );
        $mcplp_olx_url       = wp_nonce_url(
            admin_url( 'admin-post.php?action=mcplp_olx_sync_product&product_id=' . absint( $mcplp_olx_post->ID ) ),
            self::MCPLP_OLX_SYNC_NONCE,
            'mcplp_olx_nonce'
        );
        echo '<p><strong>' . esc_html__( 'Advert ID:', 'marketplace-connector-pl-pro-for-woocommerce' ) . '</strong> ' . esc_html( $mcplp_olx_advert_id ? $mcplp_olx_advert_id : '-' ) . '</p>';
        echo '<p><strong>' . esc_html__( 'Status:', 'marketplace-connector-pl-pro-for-woocommerce' ) . '</strong> ' . esc_html( $mcplp_olx_status ? $mcplp_olx_status : '-' ) . '</p>';
        if ( $mcplp_olx_error ) {
            echo '<p class="description" style="color:#b32d2e;">' . esc_html( $mcplp_olx_error ) . '</p>';
        }
        echo '<p><a class="button button-primary" href="' . esc_url( $mcplp_olx_url ) . '">' . esc_html__( 'Sync to OLX', 'marketplace-connector-pl-pro-for-woocommerce' ) . '</a></p>';
    }

    public function mcplp_olx_handle_manual_sync() {
        $mcplp_olx_product_id = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0;
        if ( ! $mcplp_olx_product_id || ! current_user_can( 'edit_product', $mcplp_olx_product_id ) ) {
            wp_die( esc_html__( 'You do not have permission to sync this product.', 'marketplace-connector-pl-pro-for-woocommerce' ) );
        }
        check_admin_referer( self::MCPLP_OLX_SYNC_NONCE, 'mcplp_olx_nonce' );

        $mcplp_olx_result = $this->mcplp_olx_sync_product( $mcplp_olx_product_id );
        $mcplp_olx_args   = is_wp_error( $mcplp_olx_result )
            ? array( 'mcplp_olx_error' => rawurlencode( $mcplp_olx_result->get_error_message() ) )
            : array( 'mcplp_olx_message' => rawurlencode( esc_html__( 'Product synced to OLX.pl.', 'marketplace-connector-pl-pro-for-woocommerce' ) ) );

        wp_safe_redirect( add_query_arg( $mcplp_olx_args, get_edit_post_link( $mcplp_olx_product_id, 'url' ) ) );
        exit;
    }

    public function mcplp_olx_register_bulk_actions( $mcplp_olx_actions ) {
        $mcplp_olx_actions['mcplp_olx_bulk_sync'] = esc_html__( 'Sync to Marketplace Connector PL PRO', 'marketplace-connector-pl-pro-for-woocommerce' );
        return $mcplp_olx_actions;
    }

    public function mcplp_olx_handle_bulk_actions( $mcplp_olx_redirect, $mcplp_olx_action, $mcplp_olx_product_ids ) {
        if ( 'mcplp_olx_bulk_sync' !== $mcplp_olx_action ) {
            return $mcplp_olx_redirect;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return $mcplp_olx_redirect;
        }
        // WordPress core verifies the bulk action nonce before this filter is called.
        $mcplp_olx_success = 0;
        $mcplp_olx_failed  = 0;
        foreach ( array_map( 'absint', (array) $mcplp_olx_product_ids ) as $mcplp_olx_product_id ) {
            $mcplp_olx_result = $this->mcplp_olx_sync_product( $mcplp_olx_product_id );
            is_wp_error( $mcplp_olx_result ) ? $mcplp_olx_failed++ : $mcplp_olx_success++;
        }
        return add_query_arg( array( 'mcplp_olx_success' => $mcplp_olx_success, 'mcplp_olx_failed' => $mcplp_olx_failed ), $mcplp_olx_redirect );
    }

    public function mcplp_olx_sync_product( $mcplp_olx_product_id ) {
        if ( ! function_exists( 'wc_get_product' ) ) {
            return new WP_Error( 'mcplp_olx_missing_wc', esc_html__( 'WooCommerce is not active.', 'marketplace-connector-pl-pro-for-woocommerce' ) );
        }

        $mcplp_olx_product = wc_get_product( absint( $mcplp_olx_product_id ) );
        if ( ! $mcplp_olx_product ) {
            return new WP_Error( 'mcplp_olx_missing_product', esc_html__( 'Product not found.', 'marketplace-connector-pl-pro-for-woocommerce' ) );
        }

        $mcplp_olx_payload = $this->mcplp_olx_build_advert_payload( $mcplp_olx_product );
        if ( is_wp_error( $mcplp_olx_payload ) ) {
            return $mcplp_olx_payload;
        }

        /** Hook for PRO/custom payload changes: variations, custom attributes, GPS, delivery, safety regulations. */
        $mcplp_olx_payload = apply_filters( 'mcplp_olx_advert_payload', $mcplp_olx_payload, $mcplp_olx_product );
        do_action( 'mcplp_olx_before_manual_sync', $mcplp_olx_product->get_id(), $mcplp_olx_payload );

        $mcplp_olx_existing_advert_id = get_post_meta( $mcplp_olx_product->get_id(), self::MCPLP_OLX_ADVERT_ID_META, true );
        $mcplp_olx_response = $mcplp_olx_existing_advert_id ? $this->mcplp_olx_api_client->mcplp_olx_update_v2_advert( $mcplp_olx_existing_advert_id, $mcplp_olx_payload ) : $this->mcplp_olx_api_client->mcplp_olx_post_v2_advert( $mcplp_olx_payload );
        if ( is_wp_error( $mcplp_olx_response ) ) {
            update_post_meta( $mcplp_olx_product->get_id(), self::MCPLP_OLX_LAST_ERROR_META, sanitize_text_field( $mcplp_olx_response->get_error_message() ) );
            return $mcplp_olx_response;
        }

        if ( isset( $mcplp_olx_response['id'] ) ) {
            update_post_meta( $mcplp_olx_product->get_id(), self::MCPLP_OLX_ADVERT_ID_META, absint( $mcplp_olx_response['id'] ) );
        }
        if ( isset( $mcplp_olx_response['status'] ) ) {
            update_post_meta( $mcplp_olx_product->get_id(), self::MCPLP_OLX_STATUS_META, sanitize_text_field( $mcplp_olx_response['status'] ) );
        }
        delete_post_meta( $mcplp_olx_product->get_id(), self::MCPLP_OLX_LAST_ERROR_META );
        do_action( 'mcplp_olx_after_manual_sync', $mcplp_olx_product->get_id(), $mcplp_olx_response );

        return $mcplp_olx_response;
    }

    private function mcplp_olx_build_advert_payload( WC_Product $mcplp_olx_product ) {
        $mcplp_olx_options     = $this->mcplp_olx_settings->mcplp_olx_get_options();
        $mcplp_olx_market      = $this->mcplp_olx_settings->mcplp_olx_get_market_config( $mcplp_olx_options['market'] );
        $mcplp_olx_category_id = $this->mcplp_olx_category_map->mcplp_olx_get_olx_category_id_for_product( $mcplp_olx_product->get_id() );

        if ( ! $mcplp_olx_category_id ) {
            return new WP_Error( 'mcplp_olx_missing_category', esc_html__( 'Missing OLX category mapping for this product.', 'marketplace-connector-pl-pro-for-woocommerce' ) );
        }
        if ( empty( $mcplp_olx_options['city_id'] ) || empty( $mcplp_olx_options['contact_name'] ) ) {
            return new WP_Error( 'mcplp_olx_missing_required_settings', esc_html__( 'Missing default city ID or contact name in Marketplace Connector PL PRO settings.', 'marketplace-connector-pl-pro-for-woocommerce' ) );
        }

        $mcplp_olx_title = sanitize_text_field( wp_strip_all_tags( $mcplp_olx_product->get_name() ) );
        $mcplp_olx_desc  = wp_kses_post( $mcplp_olx_product->get_description() ? $mcplp_olx_product->get_description() : $mcplp_olx_product->get_short_description() );
        $mcplp_olx_price = (float) wc_get_price_to_display( $mcplp_olx_product );
        $mcplp_olx_currency = $mcplp_olx_options['currency'] ? $mcplp_olx_options['currency'] : $mcplp_olx_market['currency'];

        $mcplp_olx_images = array();
        $mcplp_olx_image_ids = array_filter( array_unique( array_merge( array( $mcplp_olx_product->get_image_id() ), $mcplp_olx_product->get_gallery_image_ids() ) ) );
        foreach ( array_slice( $mcplp_olx_image_ids, 0, 8 ) as $mcplp_olx_image_id ) {
            $mcplp_olx_image_url = wp_get_attachment_url( absint( $mcplp_olx_image_id ) );
            if ( $mcplp_olx_image_url && $this->mcplp_olx_is_public_image_url( $mcplp_olx_image_url ) ) {
                $mcplp_olx_images[] = array( 'url' => esc_url_raw( $mcplp_olx_image_url ) );
            }
        }

        $mcplp_olx_payload = array(
            'title'           => $mcplp_olx_title,
            'description'     => $mcplp_olx_desc,
            'category_id'     => absint( $mcplp_olx_category_id ),
            'advertiser_type' => sanitize_text_field( $mcplp_olx_options['advertiser_type'] ),
            'external_id'     => (string) $mcplp_olx_product->get_id(),
            'contact'         => array(
                'name'  => sanitize_text_field( $mcplp_olx_options['contact_name'] ),
                'phone' => sanitize_text_field( $mcplp_olx_options['contact_phone'] ),
            ),
            'location'        => array_filter(
                array(
                    'city_id'     => absint( $mcplp_olx_options['city_id'] ),
                    'district_id' => ! empty( $mcplp_olx_options['district_id'] ) ? absint( $mcplp_olx_options['district_id'] ) : null,
                )
            ),
            'images'          => $mcplp_olx_images,
            'price'           => array(
                'value'      => $mcplp_olx_price,
                'currency'   => sanitize_text_field( $mcplp_olx_currency ),
                'negotiable' => false,
                'trade'      => false,
                'budget'     => false,
            ),
            'attributes'      => $this->mcplp_olx_category_map->mcplp_olx_get_attributes_for_product( $mcplp_olx_product->get_id() ),
        );

        return $mcplp_olx_payload;
    }

    private function mcplp_olx_is_public_image_url( $mcplp_olx_image_url ) {
        $mcplp_olx_host = wp_parse_url( $mcplp_olx_image_url, PHP_URL_HOST );
        if ( ! $mcplp_olx_host ) {
            return false;
        }
        $mcplp_olx_host = strtolower( $mcplp_olx_host );
        if ( 'localhost' === $mcplp_olx_host || '.local' === substr( $mcplp_olx_host, -6 ) || '.test' === substr( $mcplp_olx_host, -5 ) ) {
            return false;
        }
        if ( filter_var( $mcplp_olx_host, FILTER_VALIDATE_IP ) ) {
            return ! preg_match( '/^(127\.|10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[0-1])\.)/', $mcplp_olx_host );
        }
        return true;
    }
}
