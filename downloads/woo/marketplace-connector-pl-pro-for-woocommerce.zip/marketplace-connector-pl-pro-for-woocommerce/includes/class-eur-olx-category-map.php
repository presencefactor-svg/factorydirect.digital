<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCPLP_OLX_Category_Map {
    const MCPLP_OLX_CATEGORY_MAP_OPTION = 'mcplp_olx_category_map';
    const MCPLP_OLX_CATEGORY_MAP_NONCE = 'mcplp_olx_category_map_nonce_action';

    public function mcplp_olx_get_map() {
        $mcplp_olx_map = get_option( self::MCPLP_OLX_CATEGORY_MAP_OPTION, array() );
        return is_array( $mcplp_olx_map ) ? $mcplp_olx_map : array();
    }

    public function mcplp_olx_get_mapping_for_product( $mcplp_olx_product_id ) {
        $mcplp_olx_map   = $this->mcplp_olx_get_map();
        $mcplp_olx_terms = wp_get_post_terms( absint( $mcplp_olx_product_id ), 'product_cat' );
        if ( is_wp_error( $mcplp_olx_terms ) ) {
            return array();
        }
        foreach ( $mcplp_olx_terms as $mcplp_olx_term ) {
            $mcplp_olx_term_id = (string) absint( $mcplp_olx_term->term_id );
            if ( empty( $mcplp_olx_map[ $mcplp_olx_term_id ] ) ) {
                continue;
            }
            if ( is_array( $mcplp_olx_map[ $mcplp_olx_term_id ] ) ) {
                return $mcplp_olx_map[ $mcplp_olx_term_id ];
            }
            return array( 'category_id' => absint( $mcplp_olx_map[ $mcplp_olx_term_id ] ) );
        }
        return array();
    }

    public function mcplp_olx_get_olx_category_id_for_product( $mcplp_olx_product_id ) {
        $mcplp_olx_mapping = $this->mcplp_olx_get_mapping_for_product( $mcplp_olx_product_id );
        return ! empty( $mcplp_olx_mapping['category_id'] ) ? absint( $mcplp_olx_mapping['category_id'] ) : '';
    }

    public function mcplp_olx_get_attributes_for_product( $mcplp_olx_product_id ) {
        $mcplp_olx_mapping    = $this->mcplp_olx_get_mapping_for_product( $mcplp_olx_product_id );
        $mcplp_olx_attributes = array();
        $mcplp_olx_state      = ! empty( $mcplp_olx_mapping['state'] ) ? sanitize_key( $mcplp_olx_mapping['state'] ) : 'new';
        if ( $mcplp_olx_state ) {
            $mcplp_olx_attributes[] = array( 'code' => 'state', 'value' => $mcplp_olx_state );
        }
        if ( ! empty( $mcplp_olx_mapping['attributes'] ) && is_array( $mcplp_olx_mapping['attributes'] ) ) {
            foreach ( $mcplp_olx_mapping['attributes'] as $mcplp_olx_attribute ) {
                if ( empty( $mcplp_olx_attribute['code'] ) || ! isset( $mcplp_olx_attribute['value'] ) ) {
                    continue;
                }
                $mcplp_olx_code  = sanitize_key( $mcplp_olx_attribute['code'] );
                $mcplp_olx_value = sanitize_text_field( (string) $mcplp_olx_attribute['value'] );
                if ( $mcplp_olx_code && '' !== $mcplp_olx_value ) {
                    $mcplp_olx_attributes[] = array( 'code' => $mcplp_olx_code, 'value' => $mcplp_olx_value );
                }
            }
        }
        return $this->mcplp_olx_dedupe_attributes( $mcplp_olx_attributes );
    }

    public function mcplp_olx_handle_category_map_save() {
        if ( empty( $_POST['mcplp_olx_category_map_submit'] ) ) {
            return;
        }
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to save category mapping.', 'marketplace-connector-pl-pro-for-woocommerce' ) );
        }
        check_admin_referer( self::MCPLP_OLX_CATEGORY_MAP_NONCE, 'mcplp_olx_category_map_nonce' );

        $mcplp_olx_raw_map = isset( $_POST['mcplp_olx_category_map'] ) && is_array( $_POST['mcplp_olx_category_map'] ) ? map_deep( wp_unslash( $_POST['mcplp_olx_category_map'] ), 'sanitize_text_field' ) : array();
        $mcplp_olx_clean   = array();
        foreach ( $mcplp_olx_raw_map as $mcplp_olx_woo_cat_id => $mcplp_olx_row ) {
            $mcplp_olx_woo_cat_id = absint( $mcplp_olx_woo_cat_id );
            if ( ! $mcplp_olx_woo_cat_id || ! is_array( $mcplp_olx_row ) ) {
                continue;
            }
            $mcplp_olx_olx_cat_id = ! empty( $mcplp_olx_row['category_id'] ) ? absint( $mcplp_olx_row['category_id'] ) : 0;
            if ( ! $mcplp_olx_olx_cat_id ) {
                continue;
            }
            $mcplp_olx_clean[ (string) $mcplp_olx_woo_cat_id ] = array(
                'category_id'   => $mcplp_olx_olx_cat_id,
                'category_path' => isset( $mcplp_olx_row['category_path'] ) ? sanitize_text_field( $mcplp_olx_row['category_path'] ) : '',
                'state'         => isset( $mcplp_olx_row['state'] ) ? sanitize_key( $mcplp_olx_row['state'] ) : 'new',
                'attributes'    => $this->mcplp_olx_parse_attribute_lines( isset( $mcplp_olx_row['attributes'] ) ? (string) $mcplp_olx_row['attributes'] : '' ),
            );
        }
        update_option( self::MCPLP_OLX_CATEGORY_MAP_OPTION, $mcplp_olx_clean, false );
        add_settings_error( 'mcplp_olx_category_map', 'mcplp_olx_category_map_saved', esc_html__( 'Category mapping saved.', 'marketplace-connector-pl-pro-for-woocommerce' ), 'updated' );
    }

    public function mcplp_olx_render_category_map_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'marketplace-connector-pl-pro-for-woocommerce' ) );
        }
        $mcplp_olx_map        = $this->mcplp_olx_get_map();
        $mcplp_olx_categories = $this->mcplp_olx_get_pl_category_suggestions();
        $mcplp_olx_terms      = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Marketplace Connector PL PRO Category Mapping', 'marketplace-connector-pl-pro-for-woocommerce' ); ?></h1>
            <p class="description"><?php echo esc_html__( 'Map WooCommerce categories to OLX.pl category IDs and define required category attributes such as condition/state. Category ID fields include live OLX.pl API suggestions when OAuth is connected. Additional attributes use one code=value pair per line, for example brand=Samsung.', 'marketplace-connector-pl-pro-for-woocommerce' ); ?></p>
            <?php if ( ! empty( $mcplp_olx_categories ) ) : ?>
                <datalist id="mcplp_olx_pl_categories">
                    <?php foreach ( $mcplp_olx_categories as $mcplp_olx_category ) : ?>
                        <option value="<?php echo esc_attr( $mcplp_olx_category['id'] ); ?>" label="<?php echo esc_attr( $mcplp_olx_category['name'] ); ?>"></option>
                    <?php endforeach; ?>
                </datalist>
            <?php endif; ?>
            <?php settings_errors( 'mcplp_olx_category_map' ); ?>
            <form method="post">
                <?php wp_nonce_field( self::MCPLP_OLX_CATEGORY_MAP_NONCE, 'mcplp_olx_category_map_nonce' ); ?>
                <input type="hidden" name="mcplp_olx_category_map_submit" value="1">
                <table class="widefat striped">
                    <thead><tr><th><?php echo esc_html__( 'WooCommerce category', 'marketplace-connector-pl-pro-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'OLX.pl category ID', 'marketplace-connector-pl-pro-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Category note/path', 'marketplace-connector-pl-pro-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Condition', 'marketplace-connector-pl-pro-for-woocommerce' ); ?></th><th><?php echo esc_html__( 'Extra attributes', 'marketplace-connector-pl-pro-for-woocommerce' ); ?></th></tr></thead>
                    <tbody>
                    <?php if ( ! is_wp_error( $mcplp_olx_terms ) ) : ?>
                        <?php foreach ( $mcplp_olx_terms as $mcplp_olx_term ) : ?>
                            <?php
                            $mcplp_olx_row = isset( $mcplp_olx_map[ (string) $mcplp_olx_term->term_id ] ) ? $mcplp_olx_map[ (string) $mcplp_olx_term->term_id ] : array();
                            if ( ! is_array( $mcplp_olx_row ) ) {
                                $mcplp_olx_row = array( 'category_id' => absint( $mcplp_olx_row ) );
                            }
                            $mcplp_olx_value = ! empty( $mcplp_olx_row['category_id'] ) ? absint( $mcplp_olx_row['category_id'] ) : '';
                            $mcplp_olx_state = ! empty( $mcplp_olx_row['state'] ) ? sanitize_key( $mcplp_olx_row['state'] ) : 'new';
                            ?>
                            <tr>
                                <td><?php echo esc_html( $mcplp_olx_term->name ); ?></td>
                                <td><input type="number" min="1" list="mcplp_olx_pl_categories" name="mcplp_olx_category_map[<?php echo esc_attr( $mcplp_olx_term->term_id ); ?>][category_id]" value="<?php echo esc_attr( $mcplp_olx_value ); ?>" class="small-text"></td>
                                <td><input type="text" name="mcplp_olx_category_map[<?php echo esc_attr( $mcplp_olx_term->term_id ); ?>][category_path]" value="<?php echo esc_attr( isset( $mcplp_olx_row['category_path'] ) ? $mcplp_olx_row['category_path'] : '' ); ?>" class="regular-text" placeholder="<?php echo esc_attr__( 'e.g. Home / Lighting', 'marketplace-connector-pl-pro-for-woocommerce' ); ?>"></td>
                                <td><select name="mcplp_olx_category_map[<?php echo esc_attr( $mcplp_olx_term->term_id ); ?>][state]"><option value="new" <?php selected( $mcplp_olx_state, 'new' ); ?>><?php echo esc_html__( 'New', 'marketplace-connector-pl-pro-for-woocommerce' ); ?></option><option value="used" <?php selected( $mcplp_olx_state, 'used' ); ?>><?php echo esc_html__( 'Used', 'marketplace-connector-pl-pro-for-woocommerce' ); ?></option></select></td>
                                <td><textarea rows="3" cols="32" name="mcplp_olx_category_map[<?php echo esc_attr( $mcplp_olx_term->term_id ); ?>][attributes]" placeholder="brand=Samsung&#10;model=A54"><?php echo esc_textarea( $this->mcplp_olx_format_attribute_lines( isset( $mcplp_olx_row['attributes'] ) && is_array( $mcplp_olx_row['attributes'] ) ? $mcplp_olx_row['attributes'] : array() ) ); ?></textarea></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
                <?php submit_button( esc_html__( 'Save mapping', 'marketplace-connector-pl-pro-for-woocommerce' ) ); ?>
            </form>
        </div>
        <?php
    }


    private function mcplp_olx_get_pl_category_suggestions() {
        $mcplp_olx_cached = get_transient( 'mcplp_olx_pl_category_suggestions' );
        if ( is_array( $mcplp_olx_cached ) ) {
            return $mcplp_olx_cached;
        }
        $mcplp_olx_options = get_option( 'mcplp_olx_options', array() );
        if ( empty( $mcplp_olx_options['access_token'] ) ) {
            return array();
        }
        $mcplp_olx_response = wp_remote_get(
            'https://www.olx.pl/api/partner/categories?limit=1000',
            array(
                'timeout' => 20,
                'headers' => array(
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer ' . $mcplp_olx_options['access_token'],
                    'Version'       => '2.0',
                ),
            )
        );
        if ( is_wp_error( $mcplp_olx_response ) || 200 !== (int) wp_remote_retrieve_response_code( $mcplp_olx_response ) ) {
            return array();
        }
        $mcplp_olx_json = json_decode( (string) wp_remote_retrieve_body( $mcplp_olx_response ), true );
        $mcplp_olx_rows = isset( $mcplp_olx_json['data'] ) && is_array( $mcplp_olx_json['data'] ) ? $mcplp_olx_json['data'] : array();
        $mcplp_olx_categories = array();
        foreach ( $mcplp_olx_rows as $mcplp_olx_row ) {
            if ( empty( $mcplp_olx_row['id'] ) || empty( $mcplp_olx_row['name'] ) ) {
                continue;
            }
            $mcplp_olx_categories[] = array(
                'id'   => absint( $mcplp_olx_row['id'] ),
                'name' => sanitize_text_field( (string) $mcplp_olx_row['name'] ),
            );
        }
        set_transient( 'mcplp_olx_pl_category_suggestions', $mcplp_olx_categories, DAY_IN_SECONDS );
        return $mcplp_olx_categories;
    }

    private function mcplp_olx_parse_attribute_lines( $mcplp_olx_raw ) {
        $mcplp_olx_attributes = array();
        foreach ( preg_split( '/\r\n|\r|\n/', (string) $mcplp_olx_raw ) as $mcplp_olx_line ) {
            $mcplp_olx_line = trim( $mcplp_olx_line );
            if ( '' === $mcplp_olx_line || false === strpos( $mcplp_olx_line, '=' ) ) {
                continue;
            }
            list( $mcplp_olx_code, $mcplp_olx_value ) = array_map( 'trim', explode( '=', $mcplp_olx_line, 2 ) );
            $mcplp_olx_code  = sanitize_key( $mcplp_olx_code );
            $mcplp_olx_value = sanitize_text_field( $mcplp_olx_value );
            if ( $mcplp_olx_code && '' !== $mcplp_olx_value ) {
                $mcplp_olx_attributes[] = array( 'code' => $mcplp_olx_code, 'value' => $mcplp_olx_value );
            }
        }
        return $this->mcplp_olx_dedupe_attributes( $mcplp_olx_attributes );
    }

    private function mcplp_olx_format_attribute_lines( array $mcplp_olx_attributes ) {
        $mcplp_olx_lines = array();
        foreach ( $mcplp_olx_attributes as $mcplp_olx_attribute ) {
            if ( ! empty( $mcplp_olx_attribute['code'] ) && isset( $mcplp_olx_attribute['value'] ) ) {
                $mcplp_olx_lines[] = sanitize_key( $mcplp_olx_attribute['code'] ) . '=' . sanitize_text_field( (string) $mcplp_olx_attribute['value'] );
            }
        }
        return implode( "\n", $mcplp_olx_lines );
    }

    private function mcplp_olx_dedupe_attributes( array $mcplp_olx_attributes ) {
        $mcplp_olx_seen = array();
        $mcplp_olx_clean = array();
        foreach ( $mcplp_olx_attributes as $mcplp_olx_attribute ) {
            if ( empty( $mcplp_olx_attribute['code'] ) || ! isset( $mcplp_olx_attribute['value'] ) ) {
                continue;
            }
            $mcplp_olx_code = sanitize_key( $mcplp_olx_attribute['code'] );
            if ( ! $mcplp_olx_code || isset( $mcplp_olx_seen[ $mcplp_olx_code ] ) ) {
                continue;
            }
            $mcplp_olx_seen[ $mcplp_olx_code ] = true;
            $mcplp_olx_clean[] = array( 'code' => $mcplp_olx_code, 'value' => sanitize_text_field( (string) $mcplp_olx_attribute['value'] ) );
        }
        return $mcplp_olx_clean;
    }
}
