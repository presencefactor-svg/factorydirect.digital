<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MCPLP_OLX_API_Client {
    private $mcplp_olx_settings;

    public function __construct( MCPLP_OLX_Settings $mcplp_olx_settings ) {
        $this->mcplp_olx_settings = $mcplp_olx_settings;
    }

    public function mcplp_olx_request( $mcplp_olx_method, $mcplp_olx_path, $mcplp_olx_body = null ) {
        $mcplp_olx_options = $this->mcplp_olx_settings->mcplp_olx_get_options();
        if ( ( empty( $mcplp_olx_options['access_token'] ) && ! empty( $mcplp_olx_options['refresh_token'] ) ) || ( ! empty( $mcplp_olx_options['token_expires_at'] ) && absint( $mcplp_olx_options['token_expires_at'] ) < time() + 120 ) ) {
            $mcplp_olx_refreshed = $this->mcplp_olx_refresh_access_token();
            if ( ! is_wp_error( $mcplp_olx_refreshed ) ) {
                $mcplp_olx_options = $this->mcplp_olx_settings->mcplp_olx_get_options();
            }
        }

        $mcplp_olx_market = $this->mcplp_olx_settings->mcplp_olx_get_market_config( $mcplp_olx_options['market'] );
        $mcplp_olx_token  = trim( (string) $mcplp_olx_options['access_token'] );

        if ( '' === $mcplp_olx_token ) {
            return new WP_Error( 'mcplp_olx_missing_token', esc_html__( 'Missing OAuth access token.', 'marketplace-connector-pl-pro-for-woocommerce' ) );
        }

        $mcplp_olx_url = trailingslashit( $mcplp_olx_market['base_url'] ) . ltrim( $mcplp_olx_path, '/' );
        $mcplp_olx_args = array(
            'method'  => strtoupper( sanitize_key( $mcplp_olx_method ) ),
            'timeout' => 45,
            'headers' => array(
                'Accept'        => 'application/json',
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $mcplp_olx_token,
                'Version'       => '2.0',
            ),
        );

        if ( null !== $mcplp_olx_body ) {
            $mcplp_olx_args['body'] = wp_json_encode( $mcplp_olx_body );
        }

        $mcplp_olx_args = apply_filters( 'mcplp_olx_api_request_args', $mcplp_olx_args, $mcplp_olx_path, $mcplp_olx_body );
        $mcplp_olx_response = wp_remote_request( esc_url_raw( $mcplp_olx_url ), $mcplp_olx_args );
        return $this->mcplp_olx_parse_response( $mcplp_olx_response );
    }

    public function mcplp_olx_post_v2_advert( array $mcplp_olx_payload ) {
        return $this->mcplp_olx_request( 'POST', '/adverts', $mcplp_olx_payload );
    }

    public function mcplp_olx_update_v2_advert( $mcplp_olx_advert_id, array $mcplp_olx_payload ) {
        return $this->mcplp_olx_request( 'PUT', '/adverts/' . absint( $mcplp_olx_advert_id ), $mcplp_olx_payload );
    }

    public function mcplp_olx_refresh_access_token() {
        $mcplp_olx_options = $this->mcplp_olx_settings->mcplp_olx_get_options();
        if ( empty( $mcplp_olx_options['client_id'] ) || empty( $mcplp_olx_options['client_secret'] ) || empty( $mcplp_olx_options['refresh_token'] ) ) {
            return new WP_Error( 'mcplp_olx_refresh_missing_credentials', esc_html__( 'Missing OAuth refresh credentials.', 'marketplace-connector-pl-pro-for-woocommerce' ) );
        }

        $mcplp_olx_market = $this->mcplp_olx_settings->mcplp_olx_get_market_config( $mcplp_olx_options['market'] );
        $mcplp_olx_response = wp_remote_post(
            esc_url_raw( $mcplp_olx_market['token_url'] ),
            array(
                'timeout' => 45,
                'headers' => array( 'Accept' => 'application/json' ),
                'body'    => array(
                    'grant_type'    => 'refresh_token',
                    'client_id'     => $mcplp_olx_options['client_id'],
                    'client_secret' => $mcplp_olx_options['client_secret'],
                    'refresh_token' => $mcplp_olx_options['refresh_token'],
                ),
            )
        );

        $mcplp_olx_json = $this->mcplp_olx_parse_response( $mcplp_olx_response );
        if ( is_wp_error( $mcplp_olx_json ) ) {
            return $mcplp_olx_json;
        }
        $this->mcplp_olx_settings->mcplp_olx_save_tokens_from_response( $mcplp_olx_json );
        return $mcplp_olx_json;
    }

    private function mcplp_olx_parse_response( $mcplp_olx_response ) {
        if ( is_wp_error( $mcplp_olx_response ) ) {
            return $mcplp_olx_response;
        }
        $mcplp_olx_code = (int) wp_remote_retrieve_response_code( $mcplp_olx_response );
        $mcplp_olx_raw  = (string) wp_remote_retrieve_body( $mcplp_olx_response );
        $mcplp_olx_json = json_decode( $mcplp_olx_raw, true );
        if ( $mcplp_olx_code < 200 || $mcplp_olx_code >= 300 ) {
            return new WP_Error(
                'mcplp_olx_api_error',
                sprintf(
                    /* translators: 1: HTTP status code, 2: response body */
                    esc_html__( 'OLX API error %1$d: %2$s', 'marketplace-connector-pl-pro-for-woocommerce' ),
                    $mcplp_olx_code,
                    is_array( $mcplp_olx_json ) ? wp_json_encode( $mcplp_olx_json ) : $mcplp_olx_raw
                )
            );
        }
        if ( is_array( $mcplp_olx_json ) && array_key_exists( 'data', $mcplp_olx_json ) ) {
            return is_array( $mcplp_olx_json['data'] ) ? $mcplp_olx_json['data'] : array( 'data' => $mcplp_olx_json['data'] );
        }
        return is_array( $mcplp_olx_json ) ? $mcplp_olx_json : array( 'raw' => $mcplp_olx_raw );
    }
}
