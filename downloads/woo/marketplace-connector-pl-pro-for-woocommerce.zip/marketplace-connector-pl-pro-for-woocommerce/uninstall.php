<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

$options = get_option( 'mcplp_olx_options', array() );
if ( ! is_array( $options ) || empty( $options['cleanup_data'] ) || '1' !== $options['cleanup_data'] ) {
    return;
}

delete_option( 'mcplp_olx_options' );
delete_option( 'mcplp_olx_category_map' );
delete_option( 'mcplp_olx_last_oauth_debug' );
delete_transient( 'mcplp_olx_pl_category_suggestions' );

$meta_keys = array( '_mcplp_olx_advert_id', '_mcplp_olx_status', '_mcplp_olx_last_error' );
foreach ( $meta_keys as $meta_key ) {
    delete_post_meta_by_key( $meta_key );
}
wp_clear_scheduled_hook( 'mcplp_olx_pro_cron_sync' );
